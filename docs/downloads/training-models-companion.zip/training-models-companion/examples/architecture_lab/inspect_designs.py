"""Dependency-free architecture arithmetic and routing demonstration.

No model downloads, training, benchmark claims, or network access.
Run: python inspect_designs.py
"""
from math import isclose


def topk_mixture(scores, expert_outputs, k):
    """Top-k normalized positive scores; outputs all share one vector width."""
    if not 1 <= k <= len(scores) or len(scores) != len(expert_outputs):
        raise ValueError("k and expert count must agree")
    if any(x < 0 for x in scores) or len({len(v) for v in expert_outputs}) != 1:
        raise ValueError("nonnegative scores and equal output widths required")
    selected = sorted(range(len(scores)), key=lambda i: (-scores[i], i))[:k]
    denom = sum(scores[i] for i in selected)
    if denom <= 0:
        raise ValueError("selected scores must have positive sum")
    weights = [scores[i] / denom for i in selected]
    result = [sum(w * expert_outputs[i][j] for i, w in zip(selected, weights))
              for j in range(len(expert_outputs[0]))]
    return selected, weights, result


def weight_bytes(parameters, bits):
    """Ideal packed payload only; excludes scales, mixed dtypes, buffers, cache."""
    return parameters * bits / 8


def gqa_cache_bytes(batch, tokens, layers, kv_heads, key_dim, value_dim, byte_width=2):
    return batch * tokens * layers * kv_heads * (key_dim + value_dim) * byte_width


def mimo_cache_bytes(tokens, pro=False):
    """Illustrative BF16 B=1 efficient rolling cache, without speculative/other states."""
    global_layers, local_layers, global_kv = (10, 60, 8) if pro else (9, 39, 4)
    return (gqa_cache_bytes(1, tokens, global_layers, global_kv, 192, 128)
            + gqa_cache_bytes(1, min(tokens, 128), local_layers, 8, 192, 128))


def self_test():
    chosen, weights, result = topk_mixture([0.50, 0.30, 0.15, 0.05],
                                           [[2, 0], [0, 4], [9, 9], [-9, -9]], 2)
    assert chosen == [0, 1]
    assert all(isclose(x, y) for x, y in zip(weights, [0.625, 0.375]))
    assert all(isclose(x, y) for x, y in zip(result, [1.25, 1.5]))
    assert isclose(sum(weights), 1)
    assert weight_bytes(320_000_000_000, 4) == 160_000_000_000
    assert gqa_cache_bytes(1, 4096, 12, 4, 64, 64) == 48 * 1024**2
    assert mimo_cache_bytes(1048576) == 24_184_750_080
    assert mimo_cache_bytes(1048576, pro=True) == 53_726_412_800


if __name__ == '__main__':
    self_test()
    print('Arithmetic and routing assertions passed; no model training was run.')
    print('Top-2 example:', topk_mixture([.5,.3,.15,.05], [[2,0],[0,4],[9,9],[-9,-9]], 2))
    print('Ideal weight payload only, decimal GB:')
    for name, n in [('MiMo Flash rounded',310_000_000_000),
                    ('MiMo Pro rounded',1_020_000_000_000),
                    ('GLM Flash rounded',320_000_000_000),
                    ('Qwen3.5 A17B rounded',397_000_000_000)]:
        print(name, {str(bits)+'bit': weight_bytes(n,bits)/1e9 for bits in (16,8,4)})
    for tokens in (131072,1048576):
        print('MiMo rolling cache at',tokens,'tokens, GiB:',
              {'Flash': mimo_cache_bytes(tokens)/1024**3,
               'Pro': mimo_cache_bytes(tokens,True)/1024**3})
    print('GLM KDA recurrent matrices only, B=1 FP32, MiB:',34*64*128*128*4/1024**2)
