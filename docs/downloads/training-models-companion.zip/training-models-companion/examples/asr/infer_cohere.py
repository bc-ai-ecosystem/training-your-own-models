"""Separate Transformers 5.4.0+ environment; local, already-authorized Cohere weights.
Native implementation, no trust_remote_code or automatic model download.
"""
import argparse
import json
from pathlib import Path
from prepare_audio import load_audio

def main():
    p=argparse.ArgumentParser();p.add_argument('--model',required=True);p.add_argument('--audio',required=True)
    p.add_argument('--language',default='en');p.add_argument('--device',choices=['cpu','cuda'],default='cpu')
    a=p.parse_args()
    if not Path(a.model).is_dir(): raise ValueError('Use an already-authorized local model snapshot')
    config=json.loads((Path(a.model)/'config.json').read_text())
    if config.get('model_type')!='cohere_asr' or not isinstance(config.get('encoder_config'),dict):
        raise ValueError('Need native-compatible Cohere ASR config/weights; older remote-code snapshots are not interchangeable')
    import torch
    from transformers import AutoProcessor,CohereAsrForConditionalGeneration
    device='cuda:0' if a.device=='cuda' else 'cpu'
    dtype=torch.bfloat16 if a.device=='cuda' else torch.float32
    if a.device=='cuda' and (not torch.cuda.is_available() or not torch.cuda.is_bf16_supported()):
        raise RuntimeError('CUDA BF16 is required for this GPU path')
    processor=AutoProcessor.from_pretrained(a.model,local_files_only=True)
    model=CohereAsrForConditionalGeneration.from_pretrained(a.model,dtype=dtype,local_files_only=True).to(device).eval()
    audio,_=load_audio(a.audio)
    inputs=processor(audio,sampling_rate=16000,language=a.language,return_tensors='pt')
    chunk_index=inputs.pop('audio_chunk_index',None)
    inputs={k:v.to(device=device,dtype=dtype) if v.is_floating_point() else v.to(device) for k,v in inputs.items()}
    with torch.inference_mode(): ids=model.generate(**inputs,max_new_tokens=256)
    print(processor.decode(ids,skip_special_tokens=True,audio_chunk_index=chunk_index,language=a.language))

if __name__=='__main__': main()
