"""Original, dependency-free short-utterance ASR scoring; not a benchmark normalizer."""
import argparse
import json
import unicodedata
from collections import defaultdict
from pathlib import Path


def normalize(text, lexical=False):
    text = unicodedata.normalize('NFC', text)
    if lexical:
        text = text.casefold()
        text = ''.join(' ' if unicodedata.category(c).startswith('P') else c for c in text)
    return ' '.join(text.split())


def edits(reference, hypothesis):
    """Levenshtein substitution/deletion/insertion counts; deterministic tie handling."""
    grid = [[(0, 0, 0)] * (len(hypothesis) + 1) for _ in range(len(reference) + 1)]
    for i in range(1, len(reference) + 1): grid[i][0] = (0, i, 0)
    for j in range(1, len(hypothesis) + 1): grid[0][j] = (0, 0, j)
    for i, a in enumerate(reference, 1):
        for j, b in enumerate(hypothesis, 1):
            if a == b:
                grid[i][j] = grid[i-1][j-1]
            else:
                s, d, n = grid[i-1][j-1]; sub = (s+1, d, n)
                s, d, n = grid[i-1][j]; delete = (s, d+1, n)
                s, d, n = grid[i][j-1]; insert = (s, d, n+1)
                grid[i][j] = min([sub, delete, insert], key=sum)
    return grid[-1][-1]


def score(rows):
    result = {'utterances': len(rows)}
    for lexical in [False, True]:
        mode = 'lexical' if lexical else 'raw'
        for unit in ['word', 'character']:
            totals = [0, 0, 0]; denominator = 0
            for row in rows:
                r = normalize(row['reference'], lexical)
                h = normalize(row['hypothesis'], lexical)
                rt = r.split() if unit == 'word' else list(r.replace(' ', ''))
                ht = h.split() if unit == 'word' else list(h.replace(' ', ''))
                totals = [a+b for a,b in zip(totals, edits(rt, ht))]
                denominator += len(rt)
            result[f'{mode}_{unit}'] = dict(zip(['substitutions','deletions','insertions'], totals))
            result[f'{mode}_{unit}'].update(reference_units=denominator,
                error_rate=sum(totals)/denominator if denominator else None)
    silent = [r for r in rows if not normalize(r['reference'])]
    result['empty_reference_clips'] = len(silent)
    result['empty_reference_false_positives'] = sum(bool(normalize(r['hypothesis'])) for r in silent)
    result['empty_reference_inserted_words'] = sum(len(normalize(r['hypothesis']).split()) for r in silent)
    return result


def report(rows):
    out = {'all': score(rows), 'normalizer': 'NFC; raw preserves case/punctuation; lexical casefolds and replaces Unicode P* with spaces; CER removes whitespace; codepoints, not grapheme clusters'}
    for field in ['language','domain','speaker_id']:
        groups = defaultdict(list)
        for r in rows: groups[str(r.get(field,'unknown'))].append(r)
        out['by_'+field] = {k: score(v) for k,v in sorted(groups.items())}
    return out


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('predictions'); p.add_argument('--out')
    a = p.parse_args(); rows = [json.loads(x) for x in Path(a.predictions).read_text().splitlines() if x.strip()]
    payload = json.dumps(report(rows), ensure_ascii=False, indent=2)
    if a.out: Path(a.out).write_text(payload+'\n')
    print(payload)
