"""Validate consent/splits, convert local WAVs to mono 16 kHz, preserve paired labels."""
import argparse
import hashlib
import json
import math
import re
from pathlib import Path
import numpy as np
from scipy.io import wavfile
from scipy.signal import resample_poly


def load_audio(path, target_rate=16000):
    sr, a = wavfile.read(path)
    original_channels = 1 if a.ndim == 1 else a.shape[1]
    if a.ndim not in (1, 2) or sr <= 0 or not a.size: raise ValueError(f'Invalid WAV: {path}')
    if a.dtype == np.uint8: a = (a.astype(np.float64)-128)/128
    elif np.issubdtype(a.dtype, np.signedinteger):
        a = a.astype(np.float64) / (2 ** (np.iinfo(a.dtype).bits-1))
    elif np.issubdtype(a.dtype, np.floating): a = a.astype(np.float64)
    else: raise ValueError(f'Unsupported PCM dtype: {a.dtype}')
    if not np.isfinite(a).all(): raise ValueError(f'Nonfinite audio: {path}')
    if np.max(np.abs(a)) > 1.001: raise ValueError(f'Out-of-range float audio: {path}')
    if a.ndim == 2: a = a.mean(axis=1)
    original_rate = int(sr)
    if sr != target_rate:
        g = math.gcd(sr, target_rate)
        a = resample_poly(a, target_rate//g, sr//g)
    a = a.astype(np.float32)
    return a, {'original_rate': original_rate, 'original_channels': original_channels,
               'sample_rate': target_rate, 'duration_s': len(a)/target_rate,
               'rms': float(np.sqrt(np.mean(a.astype(np.float64)**2))),
               'peak': float(np.max(np.abs(a)))}


def validate_rows(rows):
    if not rows: raise ValueError('Empty manifest')
    seen_ids = set(); groups = {}; splits = set()
    for r in rows:
        for k in ['id','audio','text','language','speaker_id','session_id','source_id','domain','split','consent','rights']:
            if k not in r: raise ValueError(f'Missing {k}')
        if not isinstance(r['text'], str): raise ValueError('text must be a string')
        if not re.fullmatch(r'[A-Za-z0-9_-]+', r['id']): raise ValueError('Use simple unique IDs')
        if r['id'] in seen_ids: raise ValueError('Duplicate id')
        seen_ids.add(r['id'])
        if r['consent'] is not True or not str(r['rights']).strip(): raise ValueError('Consent and rights record required')
        if r.get('synthetic_fixture'): raise ValueError('Test tones are not speech training data')
        if r['split'] not in ['train','validation','test']: raise ValueError('Unknown split')
        if r['split'] == 'train' and not r['text'].strip(): raise ValueError('Keep silence probes in evaluation for this first project')
        for field in ['speaker_id','session_id','source_id']:
            if not isinstance(r[field], str) or not r[field].strip(): raise ValueError(f'{field} must identify a real group')
            key = (field, r[field])
            if key in groups and groups[key] != r['split']: raise ValueError(f'{field} leakage: {r[field]}')
            groups[key] = r['split']
        splits.add(r['split'])
    if splits != {'train','validation','test'}: raise ValueError('Provide train, validation and test splits')


def prepare(manifest, output, max_seconds=8):
    manifest = Path(manifest).resolve(); output = Path(output).resolve()
    if output.exists(): raise ValueError('Use a new output directory; refusing to mix old and new data')
    rows = [json.loads(s) for s in manifest.read_text().splitlines() if s.strip()]
    validate_rows(rows)
    prepared = []; hashes = {}
    # Validate every input before creating output files.
    for r in rows:
        path = Path(r['audio']); path = path if path.is_absolute() else manifest.parent/path
        path = path.resolve(); raw_hash = hashlib.sha256(path.read_bytes()).hexdigest()
        if raw_hash in hashes: raise ValueError('Duplicate WAV bytes: '+r['id'])
        hashes[raw_hash] = r['id']
        a, stats = load_audio(path)
        if not .2 <= stats['duration_s'] <= max_seconds: raise ValueError('Clip must be 0.2 to max_seconds; align and segment first: '+r['id'])
        if stats['rms'] < 1e-6 and r['text'].strip(): raise ValueError('Silent audio with nonempty label: '+r['id'])
        prepared.append((r, path, raw_hash, stats))
    (output/'audio').mkdir(parents=True)
    by_split = {s: [] for s in ['train','validation','test']}
    for r, path, raw_hash, stats in prepared:
        a, _ = load_audio(path)
        dst = output/'audio'/(r['id']+'.wav')
        pcm = (np.clip(a, -1, 1-1/32768)*32768).round().clip(-32768,32767).astype(np.int16)
        wavfile.write(dst, 16000, pcm)
        nr = dict(r, audio=str(dst), source_audio=str(path), source_sha256=raw_hash,
                  canonical_sha256=hashlib.sha256(dst.read_bytes()).hexdigest(), **stats)
        by_split[r['split']].append(nr)
    for split, group in by_split.items():
        (output/(split+'.jsonl')).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in group))
    summary = {s: {'clips':len(rs),'hours':sum(r['duration_s'] for r in rs)/3600} for s,rs in by_split.items()}
    (output/'data_report.json').write_text(json.dumps(summary,indent=2)+'\n')
    return summary

if __name__ == '__main__':
    p=argparse.ArgumentParser(); p.add_argument('manifest'); p.add_argument('output'); p.add_argument('--max-seconds',type=float,default=8)
    a=p.parse_args(); print(json.dumps(prepare(a.manifest,a.output,a.max_seconds),indent=2))
