"""Local CPU/GPU inference and generation-based evaluation for Qwen3-ASR."""
import argparse
import json
import time
from pathlib import Path
from metrics import report

def main():
    p=argparse.ArgumentParser();p.add_argument('--model',required=True)
    g=p.add_mutually_exclusive_group(required=True);g.add_argument('--audio');g.add_argument('--manifest')
    p.add_argument('--device',choices=['cpu','cuda'],default='cpu');p.add_argument('--language',default='English')
    p.add_argument('--detect-language',action='store_true');p.add_argument('--out',required=True)
    p.add_argument('--max-new-tokens',type=int,default=256)
    a=p.parse_args()
    if not Path(a.model).is_dir(): raise ValueError('Use a local pinned base or saved model directory')
    if Path(a.out).exists(): raise ValueError('Choose a fresh prediction filename')
    import torch
    from qwen_asr import Qwen3ASRModel
    if a.device=='cuda' and (not torch.cuda.is_available() or not torch.cuda.is_bf16_supported()):
        raise RuntimeError('GPU inference target is BF16-capable CUDA')
    wrapper=Qwen3ASRModel.from_pretrained(str(Path(a.model).resolve()),
        dtype=torch.bfloat16 if a.device=='cuda' else torch.float32,
        device_map='cuda:0' if a.device=='cuda' else 'cpu',attn_implementation='sdpa',
        local_files_only=True,max_inference_batch_size=1,max_new_tokens=a.max_new_tokens)
    wrapper.model.eval()
    rows=[json.loads(s) for s in Path(a.manifest).read_text().splitlines() if s.strip()] if a.manifest else [dict(id='local',audio=str(Path(a.audio).resolve()),language=a.language)]
    output=[]
    for r in rows:
        language=None if a.detect_language else r.get('language',a.language)
        started=time.perf_counter()
        result=wrapper.transcribe(audio=str(Path(r['audio']).resolve()),language=language)[0]
        item={k:r[k] for k in ['id','language','domain','speaker_id','duration_s'] if k in r}
        item.update(hypothesis=result.text,detected_language=result.language,elapsed_s=time.perf_counter()-started)
        if 'text' in r: item['reference']=r['text']
        output.append(item);print(json.dumps(item,ensure_ascii=False),flush=True)
    Path(a.out).parent.mkdir(parents=True,exist_ok=True)
    Path(a.out).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in output))
    if a.manifest:
        Path(a.out+'.metrics.json').write_text(json.dumps(report(output),ensure_ascii=False,indent=2)+'\n')

if __name__=='__main__': main()
