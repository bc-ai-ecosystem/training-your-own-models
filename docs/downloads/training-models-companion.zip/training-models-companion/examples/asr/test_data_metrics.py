"""CPU tests use mathematical tones, never claim to contain transcribed speech."""
import copy
import json
import tempfile
import unittest
from pathlib import Path
import numpy as np
from scipy.io import wavfile
from metrics import edits,normalize,score
from prepare_audio import load_audio,prepare,validate_rows


def row(i,split):
    return dict(id=f'clip{i}',audio=f'clip{i}.wav',text='Test label, not actual speech.',
        language='English',speaker_id=f'speaker{i}',session_id=f'session{i}',source_id=f'source{i}',
        domain='test-fixture',split=split,consent=True,rights='original mathematical fixture')

class DataTests(unittest.TestCase):
    def setUp(self): self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
    def tearDown(self): self.temp.cleanup()
    def test_resample_stereo_duration_amplitude(self):
        sr=48000;t=np.arange(sr)/sr;a=.2*np.sin(2*np.pi*440*t)
        wavfile.write(self.root/'s.wav',sr,np.stack([a,a],axis=1).astype(np.float32))
        y,s=load_audio(self.root/'s.wav')
        self.assertEqual(len(y),16000);self.assertEqual(s['original_channels'],2)
        self.assertAlmostEqual(s['duration_s'],1);self.assertLess(abs(s['rms']-.2/2**.5),.002)
    def test_antialias(self):
        sr=48000;t=np.arange(sr)/sr;a=.2*np.sin(2*np.pi*12000*t)
        wavfile.write(self.root/'s.wav',sr,a.astype(np.float32));y,s=load_audio(self.root/'s.wav')
        self.assertLess(float(np.sqrt(np.mean(y[100:-100]**2))),.002)
    def test_pcm16_scale(self):
        wavfile.write(self.root/'s.wav',16000,np.array([-32768,0,16384],dtype=np.int16))
        y,s=load_audio(self.root/'s.wav');np.testing.assert_allclose(y,[-1,0,.5])
    def test_nan_rejected(self):
        wavfile.write(self.root/'s.wav',16000,np.array([np.nan,0],dtype=np.float32))
        with self.assertRaises(ValueError): load_audio(self.root/'s.wav')
    def test_leakage_and_consent(self):
        rows=[row(i,s) for i,s in enumerate(['train','validation','test'])];validate_rows(rows)
        bad=copy.deepcopy(rows);bad[1]['speaker_id']=bad[0]['speaker_id']
        with self.assertRaises(ValueError):validate_rows(bad)
        bad=copy.deepcopy(rows);bad[1]['consent']=False
        with self.assertRaises(ValueError):validate_rows(bad)
        bad=copy.deepcopy(rows);bad[0]['synthetic_fixture']=True
        with self.assertRaises(ValueError):validate_rows(bad)
    def test_prepare_pipeline(self):
        # Test the file pipeline only. Temporary tone files are deleted after this test.
        rows=[row(i,s) for i,s in enumerate(['train','validation','test'])]
        for i in range(3):
            t=np.arange(16000)/16000
            wavfile.write(self.root/f'clip{i}.wav',16000,(.1*np.sin(2*np.pi*(300+50*i)*t)).astype(np.float32))
        m=self.root/'manifest.jsonl';m.write_text(''.join(json.dumps(r)+'\n' for r in rows))
        result=prepare(m,self.root/'ready');self.assertEqual(result['test']['clips'],1)
        r=json.loads((self.root/'ready/train.jsonl').read_text());self.assertEqual(r['sample_rate'],16000)
        self.assertTrue(Path(r['audio']).is_file());self.assertEqual(len(r['source_sha256']),64)
        with self.assertRaises(ValueError):prepare(m,self.root/'ready')

class MetricTests(unittest.TestCase):
    def test_sub_delete_insert(self):
        self.assertEqual(edits('a b c'.split(),'a x c'.split()),(1,0,0))
        self.assertEqual(edits('a b c'.split(),'a c'.split()),(0,1,0))
        self.assertEqual(edits('a b'.split(),'a b c'.split()),(0,0,1))
    def test_case_punctuation(self):
        r=score([{'reference':'Hello, world!','hypothesis':'hello world'}])
        self.assertEqual(r['raw_word']['error_rate'],1.0)
        self.assertEqual(r['lexical_word']['error_rate'],0.0)
    def test_empty_reference(self):
        r=score([{'reference':'','hypothesis':'invented words'}])
        self.assertIsNone(r['raw_word']['error_rate'])
        self.assertEqual(r['empty_reference_false_positives'],1)
        self.assertEqual(r['empty_reference_inserted_words'],2)
    def test_cer_and_unicode(self):
        r=score([{'reference':'你好世界','hypothesis':'你好世间'}]);self.assertEqual(r['raw_character']['error_rate'],.25)
        self.assertEqual(normalize('cafe\u0301'),normalize('café'))
    def test_wer_can_exceed_one(self):
        r=score([{'reference':'one','hypothesis':'one two three'}]);self.assertEqual(r['raw_word']['error_rate'],2.)

if __name__=='__main__':unittest.main(verbosity=2)
