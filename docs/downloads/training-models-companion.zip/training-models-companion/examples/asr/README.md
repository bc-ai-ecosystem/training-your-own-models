# Current ASR companion

Read `../../training-your-own-models.md` for the complete project. Work in this directory (`examples/asr` inside the extracted companion). Use a separate Python 3.12 environment. The pinned current Qwen backend requires Transformers 4.57.6; do not combine it with the separate native Cohere 5.4 environment.

## Contents

- `prepare_audio.py`: local WAV conversion, consent/group/split checks and SHA-256 provenance
- `fetch_qwen_model.py`: explicit user-run download of pinned Qwen3-ASR-0.6B weights
- `train_qwen_asr.py`: original bounded frozen-audio-tower adaptation; prints total/trainable counts, requires verified prepared audio and the pinned base provenance
- `infer_qwen_asr.py`: CPU/GPU transcription or generation-based validation/test from a saved local model
- `metrics.py`: dependency-free transparent WER/CER implementation with empty-reference reporting
- `infer_cohere.py`: optional local native-compatible Cohere inference in a separate environment; no access-gate acceptance or model download
- `test_data_metrics.py`: 11 executed CPU tests using temporary mathematical tones, never represented as speech training data

## Verification boundary

All scripts compile; 11 data/metric CPU tests passed on Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0. An independent review also checked the edit-distance implementation. PyTorch/Transformers/Qwen-ASR/SoundFile were unavailable. Neural loading, training, inference, checkpoint reloading and GPU memory were not executed. `requirements-qwen.txt` is a source-reviewed API target, not an empirically solved lockfile.

## Data required

You provide real, consented WAV recordings and verbatim labels. Paths in the source manifest are relative to the source manifest's directory. The strict starter requires separate speaker, session and source groups in train/validation/test, therefore at least three independent consenting speaker groups. It is not a one-speaker personalization evaluation. The book shows all required fields. The input directory and weights are never uploaded by these scripts.

## Artifact lifecycle

The download writes `book_provenance.json`; preparation writes audio hashes. Training verifies both, accepts only the pinned sub-1B base, and records run metadata. It saves full inference snapshots under `step-000100`, `step-000200` and `final` for the example 200-step command. Select a snapshot using validation, then evaluate it on untouched test. Full optimizer/RNG state is intentionally not saved; exact resume is not implemented.

## Cohere checkpoint format

Use a snapshot whose configuration and weight keys match the native `CohereAsrForConditionalGeneration` implementation, including its native `encoder_config`. Older remote-code layouts must not be passed off as interchangeable. The source-reviewed v5.4 docs include a converted revision example; current cards advertise native support. A real local load test is still required. This companion neither converts nor downloads gated weights.
