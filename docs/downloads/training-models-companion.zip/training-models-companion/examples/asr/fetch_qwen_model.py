"""Explicit user-run weight download. No credentials, upload, or training."""
import json
from pathlib import Path
from huggingface_hub import snapshot_download
MODEL='Qwen/Qwen3-ASR-0.6B'
REVISION='5eb144179a02acc5e5ba31e748d22b0cf3e303b0'
if __name__ == '__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('output');a=p.parse_args()
    dst=Path(a.output).resolve()
    snapshot_download(MODEL,revision=REVISION,local_dir=dst,
        allow_patterns=['*.json','*.safetensors','*.txt','*.jinja','*.model','README.md','LICENSE*'])
    (dst/'book_provenance.json').write_text(json.dumps({'model':MODEL,'revision':REVISION},indent=2)+'\n')
    print(dst)
