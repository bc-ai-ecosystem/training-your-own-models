"""Original bounded adaptation loop for the pinned Qwen3-ASR backend.
Source/API-reviewed only: no neural runtime or GPU validation has been performed.
Uses FP32 master weights and AdamW states, BF16 autocast, frozen audio tower.
"""
import argparse
import contextlib
import importlib.metadata
import hashlib
import json
import math
import random
import time
from pathlib import Path
from prepare_audio import load_audio


def encode_example(processor, row, torch, max_tokens):
    if hashlib.sha256(Path(row['audio']).read_bytes()).hexdigest()!=row['canonical_sha256']:
        raise ValueError('Audio changed since preparation: '+row['id'])
    audio, stats = load_audio(row['audio'])
    if not .2 <= stats['duration_s'] <= 8: raise ValueError('This project requires pre-aligned clips <=8 seconds')
    messages=[{'role':'system','content':''},
              {'role':'user','content':[{'type':'audio','audio':None}]}]
    prefix=processor.apply_chat_template([messages], add_generation_prompt=True, tokenize=False)[0]
    # Preserve transcript orthography. The language header is a model-specific target.
    target='language '+row['language']+'<asr_text>'+row['text']
    eos=processor.tokenizer.eos_token
    if not eos: raise ValueError('Missing EOS token')
    kwargs=dict(audio=[audio],sampling_rate=16000,return_tensors='pt',padding=False,truncation=False)
    x=processor(text=[prefix+target+eos],**kwargs)
    p=processor(text=[prefix],**kwargs)
    n=p['input_ids'].shape[1]
    if not torch.equal(x['input_ids'][0,:n],p['input_ids'][0]):
        raise ValueError('Prompt/target token boundary changed; inspect tokenizer before training')
    if x['input_ids'].shape[1]>max_tokens: raise ValueError('Token budget exceeded; segment/review label, never truncate paired audio blindly')
    labels=x['input_ids'].clone(); labels[:,:n]=-100
    labels[x['attention_mask']==0]=-100
    x['labels']=labels
    count=int((labels[:,1:]!=-100).sum())
    if count<2: raise ValueError('No supervised target')
    return x,count


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--model',required=True,help='Local pinned model directory')
    p.add_argument('--train',required=True);p.add_argument('--out',required=True)
    p.add_argument('--steps',type=int,default=32);p.add_argument('--accumulate',type=int,default=8)
    p.add_argument('--lr',type=float,default=1e-5);p.add_argument('--seed',type=int,default=42)
    p.add_argument('--save-every',type=int,default=16);p.add_argument('--max-tokens',type=int,default=512)
    p.add_argument('--cpu-smoke',action='store_true',help='FP32 debugging only; not a recommended training budget')
    a=p.parse_args()
    if min(a.steps,a.accumulate,a.save_every,a.max_tokens)<=0: raise ValueError('Counts must be positive')
    if not math.isfinite(a.lr) or a.lr<=0: raise ValueError('Learning rate must be finite and positive')
    if not Path(a.model).is_dir(): raise ValueError('Fetch pinned weights first; model must be local')
    out=Path(a.out)
    if out.exists(): raise ValueError('Use a fresh output directory')
    rows=[json.loads(s) for s in Path(a.train).read_text().splitlines() if s.strip()]
    if not rows: raise ValueError('Empty training set')
    config=json.loads((Path(a.model)/'config.json').read_text())
    if config.get('model_type')!='qwen3_asr': raise ValueError('Expected Qwen3-ASR model type')
    provenance_path=Path(a.model)/'book_provenance.json'
    if not provenance_path.is_file(): raise ValueError('Use the pinned base downloaded by fetch_qwen_model.py; this starter does not resume')
    provenance=json.loads(provenance_path.read_text())
    if provenance!={'model':'Qwen/Qwen3-ASR-0.6B','revision':'5eb144179a02acc5e5ba31e748d22b0cf3e303b0'}:
        raise ValueError('Wrong model provenance for this project')
    for r in rows:
        expected=r.get('canonical_sha256')
        if not isinstance(expected,str) or len(expected)!=64: raise ValueError('Use the prepared manifest with canonical audio hashes')
        if hashlib.sha256(Path(r['audio']).read_bytes()).hexdigest()!=expected: raise ValueError('Prepared audio changed: '+r.get('id','unknown'))
    if any(r.get('split')!='train' or r.get('consent') is not True or r.get('synthetic_fixture') for r in rows):
        raise ValueError('Only consented, prepared train examples are allowed')
    import torch
    from qwen_asr import Qwen3ASRModel
    if importlib.metadata.version('transformers')!='4.57.6': raise RuntimeError('Use the isolated pinned Qwen environment')
    if a.cpu_smoke: device='cpu'
    else:
        if not torch.cuda.is_available() or not torch.cuda.is_bf16_supported():
            raise RuntimeError('GPU recipe requires a BF16-capable CUDA GPU; use --cpu-smoke only for debugging')
        device='cuda:0'
    random.seed(a.seed);torch.manual_seed(a.seed)
    if device.startswith('cuda'): torch.cuda.manual_seed_all(a.seed)
    wrapper=Qwen3ASRModel.from_pretrained(str(Path(a.model).resolve()),dtype=torch.float32,
        device_map=None,attn_implementation='sdpa',local_files_only=True,max_inference_batch_size=1)
    model=wrapper.model.to(device);processor=wrapper.processor
    supported=set(wrapper.get_supported_languages())
    if any(r['language'] not in supported for r in rows): raise ValueError('Use exact supported Qwen language names')
    audio_tower=model.thinker.audio_tower
    for q in audio_tower.parameters(): q.requires_grad_(False)
    model.thinker.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant':False})
    model.thinker.config.use_cache=False
    trainable=[q for q in model.parameters() if q.requires_grad]
    total_n=sum(q.numel() for q in model.parameters()); train_n=sum(q.numel() for q in trainable)
    if total_n>1_000_000_000: raise ValueError('This recipe is bounded to <=1B total unique parameters')
    print(json.dumps({'total_parameters':total_n,'trainable_parameters':train_n}),flush=True)
    optimizer=torch.optim.AdamW(trainable,lr=a.lr,weight_decay=.01,foreach=False)
    out.mkdir(parents=True)
    run=dict(vars(a),total_parameters=total_n,trainable_parameters=train_n,
        frozen='thinker.audio_tower',optimizer='AdamW FP32 states; FP32 parameters; BF16 CUDA autocast',
        packages={k:importlib.metadata.version(k) for k in ['torch','transformers','qwen-asr','numpy','scipy']},
        base_model=str(Path(a.model).resolve()),provenance=provenance,train_manifest_sha256=hashlib.sha256(Path(a.train).read_bytes()).hexdigest())
    (out/'run.json').write_text(json.dumps(run,indent=2)+'\n')
    order=list(range(len(rows)));random.shuffle(order);position=0
    def next_row():
        nonlocal position
        if position==len(order): random.shuffle(order);position=0
        r=rows[order[position]];position+=1;return r
    def save(name):
        dst=out/name
        model.save_pretrained(dst,safe_serialization=True)
        processor.save_pretrained(dst)
        (dst/'book_run.json').write_text(json.dumps(run,indent=2)+'\n')
    if device.startswith('cuda'): torch.cuda.reset_peak_memory_stats()
    started=time.perf_counter();model.train();audio_tower.eval()
    with (out/'train_log.jsonl').open('w') as log:
        for step in range(1,a.steps+1):
            batches=[encode_example(processor,next_row(),torch,a.max_tokens) for _ in range(a.accumulate)]
            denominator=sum(n for _,n in batches);optimizer.zero_grad(set_to_none=True);sum_loss=0.
            warmup=max(1,math.ceil(.05*a.steps))
            lr=a.lr*min(step/warmup,max(0.,(a.steps-step+1)/max(1,a.steps-warmup)))
            for group in optimizer.param_groups: group['lr']=lr
            for batch,n in batches:
                batch={k:v.to(device) for k,v in batch.items()}
                ctx=torch.autocast('cuda',dtype=torch.bfloat16) if device.startswith('cuda') else contextlib.nullcontext()
                with ctx:
                    # The outer inference wrapper has no training forward. Call its documented thinker.
                    loss=model.thinker(**batch,use_cache=False).loss
                if not torch.isfinite(loss): raise FloatingPointError('Nonfinite loss; stop and inspect data/precision')
                (loss*(n/denominator)).backward();sum_loss+=float(loss.detach())*n
            grad_norm=torch.nn.utils.clip_grad_norm_(trainable,1.0,error_if_nonfinite=True)
            optimizer.step()
            event={'step':step,'target_tokens':denominator,'train_nll':sum_loss/denominator,
                'lr':lr,'grad_norm_before_clip':float(grad_norm),'elapsed_s':time.perf_counter()-started}
            if device.startswith('cuda'):
                event.update(peak_allocated_gib=torch.cuda.max_memory_allocated()/2**30,
                             peak_reserved_gib=torch.cuda.max_memory_reserved()/2**30)
            log.write(json.dumps(event)+'\n');log.flush();print(json.dumps(event),flush=True)
            if step%a.save_every==0: save(f'step-{step:06d}')
    save('final')
    print('Saved full inference model and processor. Optimizer/RNG state is not saved; this example does not claim exact resume.')

if __name__=='__main__': main()
