#!/usr/bin/env python3
"""Guarded v0.36.0 Sana trainer correction for this one-GPU teaching workflow.
When neither final validation nor upload is requested, avoid an unused second
FP32 pipeline allocation after saving the adapter. Evaluate in a fresh process.
"""
import argparse
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('source_checkout',type=Path)
a=p.parse_args()
f=a.source_checkout/'examples/dreambooth/train_dreambooth_lora_sana.py'
s=f.read_text()
old='        # Final inference\n        # Load previous pipeline\n'
new=('        # Book: do not allocate an unused second pipeline.\n'
     '        if args.validation_prompt is None and not args.push_to_hub:\n'
     '            accelerator.end_training()\n'
     '            return\n'
     '        # Final inference\n'
     '        # Load previous pipeline\n')
if s.count(new)==1:
    print('Sana final-reload patch already present')
elif s.count(old)==1 and 'check_min_version("0.36.0")' in s:
    f.write_text(s.replace(old,new))
    print('Patched unused Sana final reload; retain patch with source SHA')
else:
    raise SystemExit('Unexpected source; verify Diffusers v0.36.0 instead of patching blindly')
