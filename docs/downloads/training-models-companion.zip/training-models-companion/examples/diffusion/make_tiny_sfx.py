#!/usr/bin/env python3
"""Original synthetic sound effects for the book. No pretrained model or network.
The generated files are mono PCM16 WAV, 16 kHz, 8192 samples (0.512 s).
This is a signal-learning experiment, not a realistic music or speech corpus.
"""
import argparse
import csv
import hashlib
from pathlib import Path
import wave
import numpy as np

SR, LENGTH = 16000, 8192
CLASSES = ("thump", "ping", "hiss")

def write_wav(path, x):
    samples = np.round(np.clip(x, -1, 1) * 32767).astype("<i2")
    with wave.open(str(path), "wb") as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(SR)
        f.writeframes(samples.tobytes())

def make_one(rng, label):
    t = np.arange(LENGTH, dtype=np.float64) / SR
    onset = rng.uniform(0.005, 0.035)
    u = np.maximum(t - onset, 0)
    gate = (t >= onset).astype(float)
    if label == "thump":
        f = rng.uniform(60, 150)
        # Falling pitch and a short attack, like a deliberately simple drum hit.
        phase = 2 * np.pi * (f * u + 35 * (1 - np.exp(-25 * u)) / 25)
        x = np.sin(phase) * np.exp(-u / rng.uniform(.035, .09))
    elif label == "ping":
        f = rng.uniform(400, 1200)
        phase = rng.uniform(0, 2 * np.pi)
        x = (np.sin(2*np.pi*f*u + phase) + .22*np.sin(2*np.pi*2.31*f*u))
        x *= np.exp(-u / rng.uniform(.07, .18))
    else:
        x = rng.normal(size=LENGTH)
        # High-pass by first difference; scale is normalized below.
        x = np.concatenate(([0.0], np.diff(x)))
        x *= np.exp(-u / rng.uniform(.05, .15))
    x *= gate * np.minimum(u / .003, 1.0)
    x[-160:] *= np.linspace(1, 0, 160)
    x -= x.mean()
    x *= rng.uniform(.35, .8) / max(np.max(np.abs(x)), 1e-8)
    return x

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--out", type=Path, default=Path("data/tiny_sfx"))
    p.add_argument("--per-class", type=int, default=800)
    p.add_argument("--seed", type=int, default=123)
    a = p.parse_args()
    if a.per_class < 10:
        p.error("Use at least 10 files per class to retain all three splits")
    if (a.out / "manifest.csv").exists():
        p.error("manifest already exists; use a new output directory")
    a.out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(a.seed)
    rows = []
    for label in CLASSES:
        folder = a.out / label
        folder.mkdir(exist_ok=True)
        order = rng.permutation(a.per_class)
        splits = {}
        n_train, n_val = int(.8*a.per_class), int(.1*a.per_class)
        for j, i in enumerate(order):
            splits[int(i)] = "train" if j < n_train else ("val" if j < n_train+n_val else "test")
        for i in range(a.per_class):
            path = folder / f"{label}_{i:04d}.wav"
            write_wav(path, make_one(rng, label))
            rows.append(dict(path=str(path.relative_to(a.out)), label=label,
                             split=splits[i], group=f"{label}_{i:04d}",
                             source=f"synthetic_book_generator_seed_{a.seed}",
                             rights="generated_locally_no_recorded_people",
                             sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    with (a.out / "manifest.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)
    print(f"Wrote {len(rows)} files to {a.out}; sample rate={SR}, samples={LENGTH}")

if __name__ == "__main__":
    main()
