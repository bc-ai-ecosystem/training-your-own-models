"""Standard-library integrity helpers for the tiny audio training example.
No PyTorch import: these safety checks can be tested without a training runtime.
"""
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import uuid

SCHEDULE = "cosine_s0.008_beta_clip0.999"

def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def verified_audio_bytes(root, row):
    root = Path(root).resolve()
    relative = Path(row["path"])
    path = (root / relative).resolve()
    if relative.is_absolute() or not path.is_relative_to(root):
        raise ValueError(f"Audio path must stay inside the data root: {row['path']}")
    data = path.read_bytes()
    actual = hashlib.sha256(data).hexdigest()
    if actual != row.get("sha256"):
        raise ValueError(f"Audio SHA-256 mismatch: {path}; restore the file or create a deliberate new dataset")
    return data

def verified_manifest(root):
    """Validate every file, including the currently unused split."""
    root = Path(root)
    raw = (root / "manifest.csv").read_bytes()
    rows = list(csv.DictReader(io.StringIO(raw.decode("utf-8"))))
    if not rows:
        raise ValueError("Empty audio manifest")
    groups, paths = {}, set()
    for row in rows:
        if row["split"] not in ("train", "val", "test"):
            raise ValueError(f"Unknown data split: {row['split']}")
        if row["path"] in paths:
            raise ValueError(f"Repeated file in manifest: {row['path']}")
        paths.add(row["path"])
        if row["group"] in groups and groups[row["group"]] != row["split"]:
            raise ValueError("Group leakage between dataset splits")
        groups[row["group"]] = row["split"]
        verified_audio_bytes(root, row)
    return rows, hashlib.sha256(raw).hexdigest()

def jsonable_args(args):
    return {key: str(value) if isinstance(value, Path) else value
            for key, value in vars(args).items()}

def check_output_directory(out, resume):
    out = Path(out)
    if resume:
        if not out.is_dir() or not (out / "run.json").is_file():
            raise ValueError("Resume requires the original output directory and its run.json")
        if Path(resume).resolve().parent != out.resolve():
            raise ValueError("Resume checkpoint must belong to the selected original output directory")
    elif out.exists() and (not out.is_dir() or any(out.iterdir())):
        raise ValueError("Refusing a nonempty --out without --resume; use a new directory")

def validate_resume(checkpoint, run_metadata, current, target_steps):
    if checkpoint.get("run_id") != run_metadata.get("run_id"):
        raise ValueError("Checkpoint and output directory belong to different runs")
    saved = checkpoint.get("material_config")
    if not isinstance(saved, dict) or saved != run_metadata.get("material_config"):
        raise ValueError("Missing or inconsistent checkpoint/run material configuration")
    differences = [key for key in sorted(set(saved) | set(current)) if saved.get(key) != current.get(key)]
    if differences:
        raise ValueError("Resume changed material configuration: " + ", ".join(differences)
                         + "; keep it fixed or start a deliberate new experiment")
    if target_steps <= checkpoint["step"]:
        raise ValueError("--steps must be greater than the resumed checkpoint step")

def create_run_metadata(out, args, material_config):
    metadata = {"format_version": 1, "run_id": uuid.uuid4().hex,
                "created_utc": datetime.now(timezone.utc).isoformat(),
                "material_config": material_config, "initial_request": jsonable_args(args)}
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    # Exclusive creation protects even an unexpected concurrent writer.
    with (out / "run.json").open("x") as f:
        json.dump(metadata, f, indent=2)
    return metadata

def record_invocation(out, args, run_id, start_step, effective_lrs):
    invocation_id = uuid.uuid4().hex
    record = {"invocation_id": invocation_id, "run_id": run_id,
              "started_utc": datetime.now(timezone.utc).isoformat(),
              "start_step": start_step, "effective_optimizer_lrs": effective_lrs,
              "request": jsonable_args(args)}
    with (Path(out) / "invocations.jsonl").open("a") as f:
        f.write(json.dumps(record) + "\n")
    return invocation_id
