#!/usr/bin/env python3
"""Make original, simple paper-card illustrations for the image LoRA exercise.
This tiny procedural corpus is for learning the pipeline, not a broad style model.
"""
import argparse
import json
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw

COLORS={"red":(188,67,58),"blue":(55,113,156),"yellow":(224,176,66),"green":(75,134,98)}
OBJECTS=("house","mug","flower","balloon")

def card(rng,kind,color,size=1024):
    pixels=np.clip(np.array([244,235,216])+rng.normal(0,2,(size,size,1)),0,255).astype(np.uint8)
    im=Image.fromarray(pixels,'RGB')
    native_draw=ImageDraw.Draw(im)
    scale=size/512
    class ScaledDraw:
        def __getattr__(self,name):
            def draw(coords,*args,**kwargs):
                if isinstance(coords[0],(tuple,list)):
                    coords=[(int(round(px*scale)),int(round(py*scale))) for px,py in coords]
                else:
                    coords=[int(round(value*scale)) for value in coords]
                if 'width' in kwargs: kwargs['width']=max(1,int(round(kwargs['width']*scale)))
                return getattr(native_draw,name)(coords,*args,**kwargs)
            return draw
    d=ScaledDraw()
    x,y=int(rng.integers(-35,36)),int(rng.integers(-25,26))
    fill=COLORS[color]; ink=(49,43,39)
    def poly(points,c): d.polygon([(px+x,py+y) for px,py in points],fill=c,outline=ink,width=5)
    def ell(box,c): d.ellipse((box[0]+x,box[1]+y,box[2]+x,box[3]+y),fill=c,outline=ink,width=5)
    if kind=='house':
        poly([(150,240),(360,240),(360,395),(150,395)],fill)
        poly([(128,241),(255,117),(382,241)],(157,82,54))
        poly([(232,300),(290,300),(290,395),(232,395)],(230,214,183))
        poly([(177,270),(217,270),(217,314),(177,314)],(219,230,222))
    elif kind=='mug':
        ell((310,210,403,327),fill); ell((332,234,377,302),(244,235,216))
        poly([(145,205),(333,205),(316,366),(167,366)],fill)
        ell((145,178,333,228),(224,209,186)); ell((159,189,319,220),(95,69,49))
    elif kind=='flower':
        d.line([(255+x,267+y),(255+x,416+y)],fill=(70,111,69),width=15)
        poly([(252,361),(193,314),(187,354),(252,391)],(75,134,98))
        for dx,dy in ((0,-76),(72,-24),(45,61),(-45,61),(-72,-24)):
            ell((218+dx,195+dy,294+dx,281+dy),fill)
        ell((226,207,286,267),(221,174,62))
    else:
        d.line([(254+x,302+y),(241+x,351+y),(267+x,397+y)],fill=ink,width=4)
        ell((171,120,338,308),fill)
        poly([(254,298),(243,318),(266,317)],fill)
        ell((196,151,216,195),(239,230,211))
    # Border and handmade stitch marks, all generated rather than copied artwork.
    d.rectangle((24,24,487,487),outline=(129,112,89),width=2)
    for xx in range(44,472,24):
        d.line((xx,37,xx+10,37),fill=ink,width=2)
        d.line((xx,474,xx+10,474),fill=ink,width=2)
    return im

def main():
    p=argparse.ArgumentParser(); p.add_argument('--out',type=Path,default=Path('data/papercards'))
    p.add_argument('--size',type=int,choices=(512,1024),default=1024)
    p.add_argument('--per-object',type=int,default=60); p.add_argument('--seed',type=int,default=451)
    a=p.parse_args()
    if a.per_object<10: p.error('Use at least 10 per object')
    if a.out.exists(): p.error('Output already exists; choose a new directory')
    rng=np.random.default_rng(a.seed); records={k:[] for k in ('train','val','test')}
    for split in records: (a.out/split).mkdir(parents=True)
    for kind in OBJECTS:
        order=rng.permutation(a.per_object)
        for j,i in enumerate(order):
            split='train' if j<int(.8*a.per_object) else ('val' if j<int(.9*a.per_object) else 'test')
            color=list(COLORS)[int(rng.integers(4))]; name=f'{kind}_{i:04d}.png'
            card(rng,kind,color,a.size).save(a.out/split/name)
            records[split].append(dict(file_name=name,text=f'a {color} {kind}, rivetpaper style, centered on cream paper',group=f'{kind}-{i}'))
    for split,rows in records.items():
        (a.out/split/'metadata.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
    (a.out/'provenance.json').write_text(json.dumps({'source':'original procedural book example','seed':a.seed,'size':a.size,'people':'none','external_artwork':'none'},indent=2))
    print({k:len(v) for k,v in records.items()})
if __name__=='__main__': main()
