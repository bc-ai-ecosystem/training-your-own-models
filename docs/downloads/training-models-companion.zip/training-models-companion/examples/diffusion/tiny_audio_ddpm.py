#!/usr/bin/env python3
"""Educational class-conditioned waveform DDPM. Original book implementation.
Requires Python 3.11, torch 2.7.1, numpy 1.26.4. GPU recipe is unbenchmarked.
Only load checkpoints you created/trust; this script uses weights_only=True.
"""
import argparse
import copy
import io
import json
import math
from pathlib import Path
import time
import wave
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from audio_run_integrity import (SCHEDULE, check_output_directory, create_run_metadata,
    record_invocation, sha256_file, validate_resume, verified_audio_bytes, verified_manifest)

SR, LENGTH = 16000, 8192
CLASSES = ("thump", "ping", "hiss")
NULL_LABEL = len(CLASSES)

def read_dataset(root, split, all_rows=None):
    root = Path(root)
    if all_rows is None:
        all_rows, _ = verified_manifest(root)
    rows = [r for r in all_rows if r["split"] == split]
    if not rows:
        raise ValueError(f"Empty {split} split")
    xs, ys = [], []
    for row in rows:
        path = root / row["path"]
        # Read exactly the bytes whose hash is verified, avoiding a separate file reopen.
        with wave.open(io.BytesIO(verified_audio_bytes(root, row)), "rb") as f:
            if (f.getnchannels(), f.getsampwidth(), f.getframerate(), f.getnframes()) != (1, 2, SR, LENGTH):
                raise ValueError(f"{path}: requires mono PCM16, {SR} Hz, {LENGTH} samples")
            x = np.frombuffer(f.readframes(LENGTH), dtype="<i2").astype(np.float32)/32768
        if np.max(np.abs(x)) >= .999:
            raise ValueError(f"{path}: clipped or near-full-scale audio")
        xs.append(torch.from_numpy(x).unsqueeze(0))
        ys.append(CLASSES.index(row["label"]))
    return torch.stack(xs), torch.tensor(ys, dtype=torch.long)

class ResBlock(nn.Module):
    def __init__(self, cin, cout, emb=128, dilation=1):
        super().__init__()
        self.n1 = nn.GroupNorm(8, cin)
        self.c1 = nn.Conv1d(cin, cout, 3, padding=dilation, dilation=dilation)
        self.emb = nn.Linear(emb, 2*cout)
        self.n2 = nn.GroupNorm(8, cout)
        self.c2 = nn.Conv1d(cout, cout, 3, padding=1)
        self.skip = nn.Conv1d(cin, cout, 1) if cin != cout else nn.Identity()
    def forward(self, x, e):
        h = self.c1(F.silu(self.n1(x)))
        scale, shift = self.emb(F.silu(e)).unsqueeze(-1).chunk(2, dim=1)
        h = self.n2(h)*(1+scale)+shift
        return (self.skip(x)+self.c2(F.silu(h)))/math.sqrt(2)

class TinyUNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.temb = nn.Sequential(nn.Linear(128,128), nn.SiLU(), nn.Linear(128,128))
        self.label = nn.Embedding(len(CLASSES)+1,128)
        self.input = nn.Conv1d(1,32,3,padding=1)
        self.r0, self.r1, self.r2 = ResBlock(32,32), ResBlock(64,64), ResBlock(128,128)
        self.d1 = nn.Conv1d(32,64,8,stride=4,padding=2)
        self.d2 = nn.Conv1d(64,128,8,stride=4,padding=2)
        self.d3 = nn.Conv1d(128,128,8,stride=4,padding=2)
        self.mid = nn.ModuleList([ResBlock(128,128,dilation=d) for d in (1,2,4,8)])
        self.u2, self.u1, self.u0 = ResBlock(256,128), ResBlock(192,64), ResBlock(96,32)
        self.outnorm, self.output = nn.GroupNorm(8,32), nn.Conv1d(32,1,3,padding=1)
    def forward(self, x, t, label):
        f = torch.exp(-math.log(10000)*torch.arange(64, device=x.device)/63)
        angles = t.float()[:,None]*f[None,:]
        e = self.temb(torch.cat((angles.sin(),angles.cos()),dim=1))+self.label(label)
        s0 = self.r0(self.input(x),e)
        s1 = self.r1(self.d1(s0),e)
        s2 = self.r2(self.d2(s1),e)
        h = self.d3(s2)
        for block in self.mid:
            h = block(h,e)
        h = self.u2(torch.cat((F.interpolate(h,size=s2.shape[-1],mode="nearest"),s2),dim=1),e)
        h = self.u1(torch.cat((F.interpolate(h,size=s1.shape[-1],mode="nearest"),s1),dim=1),e)
        h = self.u0(torch.cat((F.interpolate(h,size=s0.shape[-1],mode="nearest"),s0),dim=1),e)
        return self.output(F.silu(self.outnorm(h)))

class Diffusion:
    def __init__(self, steps, device):
        # Cosine cumulative signal power, then per-step beta. Compute in float64.
        grid = torch.linspace(0,steps,steps+1,dtype=torch.float64)
        abar = torch.cos(((grid/steps+.008)/1.008)*math.pi/2).square()
        abar = abar/abar[0]
        self.beta = (1-abar[1:]/abar[:-1]).clamp(max=.999).float().to(device)
        self.alpha = 1-self.beta
        self.abar = torch.cumprod(self.alpha,dim=0)
        self.prev = F.pad(self.abar[:-1],(1,0),value=1)
        self.steps = steps
    def q_sample(self,x,t,noise):
        a = self.abar[t,None,None]
        return a.sqrt()*x+(1-a).sqrt()*noise

@torch.no_grad()
def validate(model, diff, xs, ys, device, batch=4, batches=8):
    model.eval()
    gen = torch.Generator(device=device).manual_seed(9876)
    total, count = 0., 0
    indices = torch.linspace(0, len(xs)-1, min(len(xs),batch*batches)).long()
    for start in range(0,len(indices),batch):
        idx = indices[start:start+batch]
        x, y = xs[idx].to(device), ys[idx].to(device)
        t = torch.randint(diff.steps,(len(x),),generator=gen,device=device)
        noise = torch.randn(x.shape,generator=gen,device=device)
        loss = F.mse_loss(model(diff.q_sample(x,t,noise),t,y),noise)
        total += loss.item()*len(x); count += len(x)
    return total/count

@torch.no_grad()
def sample(model,diff,label,n,device,seed,cfg):
    model.eval()
    gen = torch.Generator(device=device).manual_seed(seed)
    x = torch.randn((n,1,LENGTH),generator=gen,device=device)
    y = torch.full((n,),label,device=device,dtype=torch.long)
    null = torch.full_like(y,NULL_LABEL)
    for i in reversed(range(diff.steps)):
        t = torch.full((n,),i,device=device,dtype=torch.long)
        eps = model(x,t,y)
        if cfg != 1:
            uncond = model(x,t,null)
            eps = uncond+cfg*(eps-uncond)
        a, prev, b = diff.abar[i], diff.prev[i], diff.beta[i]
        x0 = ((x-(1-a).sqrt()*eps)/a.sqrt()).clamp(-1,1)
        mean = b*prev.sqrt()/(1-a)*x0+(1-prev)*diff.alpha[i].sqrt()/(1-a)*x
        if i:
            variance = b*(1-prev)/(1-a)
            x = mean+variance.sqrt()*torch.randn(x.shape,generator=gen,device=device)
        else:
            x = mean
    return x.cpu().numpy()[:,0,:]

def save_wav(path,x):
    with wave.open(str(path),"wb") as f:
        f.setnchannels(1); f.setsampwidth(2); f.setframerate(SR)
        # No per-sample loudness normalization: preserve amplitude for evaluation.
        f.writeframes(np.round(np.clip(x,-1,1)*32767).astype("<i2").tobytes())

def train(a):
    check_output_directory(a.out, a.resume)
    device=torch.device(a.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable; install matching driver/PyTorch or use --device cpu for a tiny smoke test")
    if device.type not in ("cpu", "cuda"):
        raise ValueError("This teaching trainer supports CPU or CUDA only")
    if device.type == "cuda":
        device=torch.device("cuda",device.index if device.index is not None else torch.cuda.current_device())
    rows,manifest_sha=verified_manifest(a.data)
    material={"batch":a.batch,"accum":a.accum,"learning_rate":a.lr,"seed":a.seed,
              "device":str(device),"diffusion_steps":a.diffusion_steps,"schedule":SCHEDULE,
              "sample_rate":SR,"length":LENGTH,"classes":list(CLASSES),"precision":"float32",
              "optimizer":"AdamW","weight_decay":1e-4,"ema_decay":.999,
              "condition_dropout":.1,"gradient_clip":1.,
              "source_sha256":sha256_file(__file__),
              "integrity_source_sha256":sha256_file(Path(__file__).with_name("audio_run_integrity.py")),
              "data_manifest_sha256":manifest_sha,"torch_version":str(torch.__version__),
              "numpy_version":str(np.__version__),"torch_cuda_version":torch.version.cuda}
    checkpoint=None
    if a.resume:
        metadata=json.loads((a.out/"run.json").read_text())
        checkpoint=torch.load(a.resume,map_location="cpu",weights_only=True)
        validate_resume(checkpoint,metadata,material,a.steps)
        existing=[int(path.stem.split("-")[1]) for path in a.out.glob("step-*.pt")]
        if existing and checkpoint["step"] != max(existing):
            raise ValueError("Resume the latest saved checkpoint; earlier checkpoints are for evaluation")
    torch.manual_seed(a.seed)
    xs,ys=read_dataset(a.data,"train",rows); vx,vy=read_dataset(a.data,"val",rows)
    model=TinyUNet().to(device)
    ema=copy.deepcopy(model).eval().requires_grad_(False)
    opt=torch.optim.AdamW(model.parameters(),lr=a.lr,weight_decay=1e-4)
    diff=Diffusion(a.diffusion_steps,device)
    sampler_gen=torch.Generator().manual_seed(a.seed+1)
    start=0
    if checkpoint is not None:
        ck=checkpoint
        model.load_state_dict(ck["model"]); ema.load_state_dict(ck["ema"])
        opt.load_state_dict(ck["optimizer"]); start=ck["step"]
        if any(group["lr"] != a.lr for group in opt.param_groups):
            raise ValueError("Restored optimizer learning rate differs from the validated run configuration")
        sampler_gen.set_state(ck["sampler_rng"]); torch.set_rng_state(ck["cpu_rng"])
        if device.type=="cuda" and ck["cuda_rng"] is not None:
            torch.cuda.set_rng_state_all(ck["cuda_rng"])
    else:
        metadata=create_run_metadata(a.out,a,material)
    invocation_id=record_invocation(a.out,a,metadata["run_id"],start,
                                    [group["lr"] for group in opt.param_groups])
    print(json.dumps({"parameters":sum(p.numel() for p in model.parameters()),"train":len(xs),"val":len(vx),"device":str(device),"batch":a.batch,"accum":a.accum}))
    if device.type=="cuda": torch.cuda.reset_peak_memory_stats()
    start_time=time.perf_counter()
    logfile=a.out/"metrics.jsonl"
    for step in range(start+1,a.steps+1):
        model.train(); opt.zero_grad(set_to_none=True); running=0.
        for _ in range(a.accum):
            idx=torch.randint(len(xs),(a.batch,),generator=sampler_gen)
            x,y=xs[idx].to(device),ys[idx].to(device)
            t=torch.randint(diff.steps,(a.batch,),device=device)
            noise=torch.randn_like(x)
            y=torch.where(torch.rand(a.batch,device=device)<.1,NULL_LABEL,y)
            pred=model(diff.q_sample(x,t,noise),t,y)
            loss=F.mse_loss(pred,noise)
            if not torch.isfinite(loss): raise RuntimeError("Non-finite loss; inspect data and learning rate")
            (loss/a.accum).backward(); running+=loss.detach().item()/a.accum
        torch.nn.utils.clip_grad_norm_(model.parameters(),1.0,error_if_nonfinite=True)
        opt.step()
        with torch.no_grad():
            for ep,p in zip(ema.parameters(),model.parameters()): ep.lerp_(p,.001)
        if step%a.log_every==0 or step==a.steps:
            record={"invocation_id":invocation_id,"step":step,"train_mse":running,"val_mse_ema":validate(ema,diff,vx,vy,device,a.batch),"seconds":time.perf_counter()-start_time}
            if device.type=="cuda":
                record.update(peak_allocated_gib=torch.cuda.max_memory_allocated()/2**30,peak_reserved_gib=torch.cuda.max_memory_reserved()/2**30)
            with logfile.open("a") as f: f.write(json.dumps(record)+"\n")
            print(json.dumps(record),flush=True)
        if step%a.save_every==0 or step==a.steps:
            ck={"model":model.state_dict(),"ema":ema.state_dict(),"optimizer":opt.state_dict(),
                "step":step,"diffusion_steps":a.diffusion_steps,"sample_rate":SR,"length":LENGTH,
                "classes":CLASSES,"schedule":SCHEDULE,"run_id":metadata["run_id"],
                "material_config":material,"source_sha256":material["source_sha256"],
                "data_manifest_sha256":manifest_sha,"sampler_rng":sampler_gen.get_state(),
                "cpu_rng":torch.get_rng_state(),
                "cuda_rng":torch.cuda.get_rng_state_all() if device.type=="cuda" else None}
            destination=a.out/f"step-{step}.pt"
            if destination.exists():
                raise ValueError(f"Refusing to overwrite a checkpoint: {destination}")
            temporary=a.out/f"step-{step}-{invocation_id}.tmp"
            torch.save(ck,temporary)
            temporary.replace(destination)

def main():
    p=argparse.ArgumentParser()
    sub=p.add_subparsers(dest="command",required=True)
    t=sub.add_parser("train")
    t.add_argument("--data",type=Path,required=True); t.add_argument("--out",type=Path,default=Path("runs/audio"))
    t.add_argument("--steps",type=int,default=10000); t.add_argument("--batch",type=int,default=4)
    t.add_argument("--accum",type=int,default=1); t.add_argument("--lr",type=float,default=2e-4)
    t.add_argument("--diffusion-steps",type=int,default=256); t.add_argument("--seed",type=int,default=123)
    t.add_argument("--device",default="cuda"); t.add_argument("--resume",type=Path)
    t.add_argument("--log-every",type=int,default=100); t.add_argument("--save-every",type=int,default=1000)
    s=sub.add_parser("sample")
    s.add_argument("--checkpoint",type=Path,required=True); s.add_argument("--out",type=Path,default=Path("samples/audio"))
    s.add_argument("--class-name",choices=CLASSES,default="ping"); s.add_argument("--n",type=int,default=8)
    s.add_argument("--cfg",type=float,default=1.0); s.add_argument("--seed",type=int,default=17)
    s.add_argument("--device",default="cuda")
    e=sub.add_parser("evaluate")
    e.add_argument("--checkpoint",type=Path,required=True); e.add_argument("--data",type=Path,required=True)
    e.add_argument("--split",choices=("val","test"),default="val"); e.add_argument("--device",default="cuda")
    a=p.parse_args()
    if a.command=="train":
        if min(a.steps,a.batch,a.accum,a.diffusion_steps,a.log_every,a.save_every)<=0: p.error("Counts must be positive")
        if not math.isfinite(a.lr) or a.lr <= 0: p.error("Learning rate must be finite and positive")
        train(a); return
    ck=torch.load(a.checkpoint,map_location="cpu",weights_only=True)
    if (ck["sample_rate"],ck["length"],tuple(ck["classes"]),ck["schedule"]) != (SR,LENGTH,CLASSES,SCHEDULE):
        raise ValueError("Checkpoint data representation/classes/schedule differ from this implementation")
    device=torch.device(a.device); model=TinyUNet().to(device); model.load_state_dict(ck["ema"])
    diff=Diffusion(ck["diffusion_steps"],device)
    if a.command=="evaluate":
        xs,ys=read_dataset(a.data,a.split)
        print(json.dumps({"split":a.split,"n":len(xs),"fixed_noise_mse":validate(model,diff,xs,ys,device,batches=math.ceil(len(xs)/4))}))
        return
    a.out.mkdir(parents=True,exist_ok=True)
    waves=sample(model,diff,CLASSES.index(a.class_name),a.n,device,a.seed,a.cfg)
    for i,x in enumerate(waves): save_wav(a.out/f"{a.class_name}-seed{a.seed}-{i}.wav",x)
    (a.out/f"{a.class_name}-seed{a.seed}.json").write_text(json.dumps({k:str(v) if isinstance(v,Path) else v for k,v in vars(a).items()},indent=2))
    print(f"Saved {len(waves)} generated sounds; listen at low volume first")

if __name__=="__main__": main()
