#!/usr/bin/env python3
"""Generate fixed held-out caption/seed cases and an unscored human-review CSV.
Loads the pipeline once. Does not fabricate perceptual scores or use references
as model inputs. Inference mechanics are shared with sample_image_lora.py.
"""
import argparse
import csv
import json
from pathlib import Path
from sample_image_lora import build_pipeline,generate_and_save

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--base',required=True);p.add_argument('--lora')
    p.add_argument('--base-info',type=Path,default=Path('base_revision.json'))
    p.add_argument('--metadata',type=Path,required=True);p.add_argument('--split',choices=('val','test'),required=True)
    p.add_argument('--out',type=Path,required=True);p.add_argument('--limit',type=int,default=8)
    p.add_argument('--seeds',default='17,29');p.add_argument('--device',choices=('cuda','cpu'),default='cuda')
    a=p.parse_args()
    if a.limit<1: p.error('--limit must be positive')
    if a.out.exists() and any(a.out.iterdir()): p.error('Evaluation output must be new or empty')
    rows=[json.loads(line) for line in a.metadata.read_text().splitlines() if line.strip()]
    if not rows: p.error('Empty evaluation metadata')
    n=min(a.limit,len(rows))
    indices=[round(i*(len(rows)-1)/(n-1)) for i in range(n)] if n>1 else [0]
    selected=[rows[i] for i in indices];seeds=[int(x) for x in a.seeds.split(',')]
    for row in selected:
        if not (a.metadata.parent/row['file_name']).is_file(): p.error('Missing reference image')
    pipe,info=build_pipeline(a.base,a.lora,a.device,a.base_info)
    a.out.mkdir(parents=True,exist_ok=True)
    cases=[]
    for index,row in zip(indices,selected):
        for seed in seeds:
            output=a.out/f'case-{index:04d}-seed-{seed}.png'
            generate_and_save(pipe,info,row['text'],seed,output)
            cases.append({'split':a.split,'metadata_row':index,'prompt':row['text'],'seed':seed,
                'reference_image':str((a.metadata.parent/row['file_name']).resolve()),
                'generated_image':str(output.resolve()),'content_1_to_5':'','style_1_to_5':'',
                'control_notes':'','diversity_notes':'','memorization_review':''})
    with (a.out/'cases.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(cases[0]));w.writeheader();w.writerows(cases)
    (a.out/'evaluation.json').write_text(json.dumps(info|{'metadata':str(a.metadata.resolve()),
        'split':a.split,'selected_rows':indices,'seeds':seeds,'scores':'human review required'},indent=2))
    print(f'Wrote {len(cases)} cases; review cases.csv against reference and training images')
if __name__=='__main__': main()
