#!/usr/bin/env python3
"""Sana BF16 baseline/adapter inference; Diffusers v0.36.0 APIs.
CUDA uses mixed component precision/offload; CPU uses float32 and may be slow.
Neural-network execution is untested in the book-authoring environment.
"""
import argparse
import json
from pathlib import Path
import torch
from diffusers import SanaPipeline
from image_run_manifest import base_identity, validate_adapter_base

def build_pipeline(base,lora,device,base_info):
    if device=='cuda' and not torch.cuda.is_available():
        raise ValueError('CUDA unavailable; fix it or explicitly choose CPU')
    if device=='cuda' and not torch.cuda.is_bf16_supported():
        raise ValueError('This BF16 recipe requires a CUDA GPU with BF16 support')
    identity=base_identity(base,base_info)
    if lora: validate_adapter_base(lora,identity)
    dtype=torch.bfloat16 if device=='cuda' else torch.float32
    pipe=SanaPipeline.from_pretrained(base,variant='bf16',torch_dtype=dtype)
    pipe.vae.to(dtype=torch.float32)
    if lora: pipe.load_lora_weights(lora)
    counts={name:sum(p.numel() for p in getattr(pipe,name).parameters())
            for name in ('transformer','text_encoder','vae')}
    print(json.dumps({'component_parameters':counts,'total_component_parameters':sum(counts.values())}))
    if device=='cuda': pipe.enable_model_cpu_offload()
    else: pipe.to('cpu')
    info={'base_identity':identity,'adapter':str(lora) if lora else None,'device':device,
          'transformer_and_text_dtype':str(dtype),'autoencoder_dtype':'torch.float32',
          'max_sequence_length':128,'complex_human_instruction':None,
          'component_parameters':counts,'scheduler_class':type(pipe.scheduler).__name__,
          'scheduler_config':dict(pipe.scheduler.config)}
    return pipe,info

def generate_and_save(pipe,info,prompt,seed,out,cfg=4.5,steps=20):
    out=Path(out)
    if out.exists() or out.with_suffix('.json').exists():
        raise ValueError('Output already exists; choose a fresh filename')
    image=pipe(prompt,height=1024,width=1024,num_inference_steps=steps,
               guidance_scale=cfg,max_sequence_length=128,
               complex_human_instruction=None,clean_caption=False,
               generator=torch.Generator(device=info['device']).manual_seed(seed)).images[0]
    out.parent.mkdir(parents=True,exist_ok=True); image.save(out)
    out.with_suffix('.json').write_text(json.dumps(info|{'prompt':prompt,'seed':seed,
        'steps':steps,'cfg':cfg,'height':1024,'width':1024,'out':str(out)},indent=2))

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--base',required=True);p.add_argument('--lora')
    p.add_argument('--base-info',type=Path,default=Path('base_revision.json'))
    p.add_argument('--prompt',required=True);p.add_argument('--seed',type=int,default=17)
    p.add_argument('--out',type=Path,default=Path('sample.png'))
    p.add_argument('--device',choices=('cuda','cpu'),default='cuda')
    p.add_argument('--cfg',type=float,default=4.5);p.add_argument('--steps',type=int,default=20)
    a=p.parse_args()
    if a.out.exists() or a.out.with_suffix('.json').exists(): p.error('Output exists; choose a fresh filename')
    pipe,info=build_pipeline(a.base,a.lora,a.device,a.base_info)
    generate_and_save(pipe,info,a.prompt,a.seed,a.out,a.cfg,a.steps)
if __name__=='__main__': main()
