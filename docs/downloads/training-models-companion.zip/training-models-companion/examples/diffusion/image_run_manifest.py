"""Bind a Sana teaching adapter to its pinned base, source and caption dataset.
The cached Hub snapshot revision is treated as immutable. Configuration and
training data are hashed; multi-gigabyte base weights are not rehashed each call.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

MODEL_REPO='Efficient-Large-Model/Sana_1600M_1024px_BF16_diffusers'
MANIFEST='book_run_manifest.json'

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def base_identity(base,base_info):
    base=Path(base).resolve()
    info=json.loads(Path(base_info).read_text())
    if info.get('repo') != MODEL_REPO:
        raise ValueError('This recipe expects the documented Sana 1.6B BF16 repository')
    if base.name != info.get('revision'):
        raise ValueError('BASE must be the recorded immutable Hub snapshot directory (retain its revision folder name)')
    paths=[base/'model_index.json',base/'transformer/config.json',base/'text_encoder/config.json',
           base/'vae/config.json',base/'scheduler/scheduler_config.json']
    configs={str(path.relative_to(base)):sha(path) for path in paths}
    return {'repo':info['repo'],'revision':info['revision'],'configuration_sha256':configs}

def dataset_identity(data):
    data=Path(data).resolve(); meta=data/'metadata.jsonl'
    rows=[json.loads(line) for line in meta.read_text().splitlines() if line.strip()]
    if not rows: raise ValueError('Empty caption dataset')
    hashes={}
    for row in rows:
        path=(data/row['file_name']).resolve()
        if not path.is_relative_to(data): raise ValueError('Image path escapes data root')
        if row['file_name'] in hashes: raise ValueError('Repeated filename in metadata')
        hashes[row['file_name']]=sha(path)
    return {'metadata_sha256':sha(meta),'image_sha256':hashes}

def validate_adapter_base(lora,identity):
    folder=Path(lora)
    manifest=folder/MANIFEST
    if not manifest.is_file() and folder.name.startswith('checkpoint-'):
        manifest=folder.parent/MANIFEST
    if not manifest.is_file():
        raise ValueError('Missing adapter base manifest; retain book_run_manifest.json beside the adapter')
    saved=json.loads(manifest.read_text())
    if saved['material']['base'] != identity:
        raise ValueError('Adapter/base revision or model configuration mismatch')
    return saved

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--base',type=Path,required=True);p.add_argument('--base-info',type=Path,required=True)
    p.add_argument('--data',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--trainer',type=Path,required=True);p.add_argument('--wrapper',type=Path,required=True)
    p.add_argument('--steps',type=int,required=True);p.add_argument('--warmup',type=int,required=True)
    p.add_argument('--resume',default='')
    a=p.parse_args()
    material={'base':base_identity(a.base,a.base_info),'data':dataset_identity(a.data),
              'trainer_sha256':sha(a.trainer),'wrapper_sha256':sha(a.wrapper),
              'settings':{'variant':'bf16','resolution':1024,'batch':1,'accumulation':4,
                          'rank':8,'lora_alpha':8,'learning_rate':1e-4,'optimizer':'AdamW',
                          'scheduler':'constant_with_warmup','warmup':a.warmup,'seed':17,
                          'max_sequence_length':128,'complex_human_instruction':None,
                          'offload':True,'cache_latents':False,'gradient_checkpointing':True}}
    destination=a.out/MANIFEST
    if a.resume:
        saved=json.loads(destination.read_text())
        if saved['material'] != material:
            raise ValueError('Resume changed base/data/trainer/settings; use a deliberate new experiment')
        checkpoints=[x for x in a.out.glob('checkpoint-*') if x.is_dir()]
        if a.resume=='latest':
            if not checkpoints: raise ValueError('No saved checkpoint to resume')
            selected=max(checkpoints,key=lambda path:int(path.name.split('-')[1]))
        elif not (a.out/Path(a.resume).name).is_dir():
            raise ValueError('Requested resume checkpoint does not exist in this output directory')
        else:
            selected=a.out/Path(a.resume).name
        if a.steps <= int(selected.name.split('-')[1]):
            raise ValueError('Target steps must exceed the resumed checkpoint step')
    else:
        a.out.mkdir(parents=True,exist_ok=True)
        with destination.open('x') as f:
            json.dump({'created_utc':datetime.now(timezone.utc).isoformat(),'material':material},f,indent=2)
    with (a.out/'book_invocations.jsonl').open('a') as f:
        f.write(json.dumps({'utc':datetime.now(timezone.utc).isoformat(),'steps':a.steps,'resume':a.resume})+'\n')
    print('Verified pinned base, source, data and training settings')

if __name__=='__main__': main()
