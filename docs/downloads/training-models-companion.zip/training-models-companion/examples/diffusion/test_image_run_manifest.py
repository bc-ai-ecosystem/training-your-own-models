"""Standard-library identity tests; no neural-network runtime required."""
import json
from pathlib import Path
import tempfile
import unittest
from image_run_manifest import MODEL_REPO,MANIFEST,base_identity,dataset_identity,validate_adapter_base

class ImageIdentityTests(unittest.TestCase):
    def test_base_and_adapter_binding(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); revision='a'*40;base=root/revision;base.mkdir()
            for name in ('model_index.json','transformer/config.json','text_encoder/config.json',
                         'vae/config.json','scheduler/scheduler_config.json'):
                path=base/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text('{}')
            info=root/'base_revision.json';info.write_text(json.dumps({'repo':MODEL_REPO,'revision':revision}))
            identity=base_identity(base,info)
            adapter=root/'adapter';adapter.mkdir()
            (adapter/MANIFEST).write_text(json.dumps({'material':{'base':identity}}))
            validate_adapter_base(adapter,identity)
            checkpoint=adapter/'checkpoint-250';checkpoint.mkdir()
            validate_adapter_base(checkpoint,identity)
            (base/'transformer/config.json').write_text('{"changed":true}')
            with self.assertRaisesRegex(ValueError,'mismatch'):
                validate_adapter_base(adapter,base_identity(base,info))
            info.write_text(json.dumps({'repo':MODEL_REPO,'revision':'b'*40}))
            with self.assertRaisesRegex(ValueError,'snapshot'):base_identity(base,info)

    def test_data_content_changes_identity(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);image=root/'x.png';image.write_bytes(b'fixture')
            (root/'metadata.jsonl').write_text(json.dumps({'file_name':'x.png','text':'a test'})+'\n')
            original=dataset_identity(root);image.write_bytes(b'changed')
            self.assertNotEqual(original,dataset_identity(root))
            (root/'metadata.jsonl').write_text(json.dumps({'file_name':'../escape','text':'test'})+'\n')
            with self.assertRaisesRegex(ValueError,'escapes'):dataset_identity(root)

if __name__=='__main__':unittest.main()
