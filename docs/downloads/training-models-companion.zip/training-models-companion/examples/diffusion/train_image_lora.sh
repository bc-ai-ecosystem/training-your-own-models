#!/usr/bin/env bash
set -euo pipefail
# Sana 1.6B BF16 LoRA, using the inspected Diffusers v0.36.0 trainer.
: "${BASE:?Set BASE to the local, revision-pinned Sana BF16 snapshot}"
: "${DATA:?Set DATA to the data root containing train/metadata.jsonl}"
: "${DIFFUSERS_SRC:?Set DIFFUSERS_SRC to the v0.36.0 source checkout}"
OUT=${OUT:-runs/papercard-lora}
STEPS=${STEPS:-1000}
WARMUP=${WARMUP:-100}
EXTRA=()
if [[ -n "${RESUME:-}" ]]; then
  EXTRA+=(--resume_from_checkpoint "$RESUME")
elif [[ -d "$OUT" && -n "$(ls -A "$OUT")" ]]; then
  echo 'Refusing nonempty output directory without RESUME' >&2
  exit 1
fi
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python "$SCRIPT_DIR/image_run_manifest.py" \
  --base "$BASE" --base-info "${BASE_INFO:-$PWD/base_revision.json}" \
  --data "$DATA/train" --out "$OUT" \
  --trainer "$DIFFUSERS_SRC/examples/dreambooth/train_dreambooth_lora_sana.py" \
  --wrapper "${BASH_SOURCE[0]}" --steps "$STEPS" --warmup "$WARMUP" --resume "${RESUME:-}"
accelerate launch --num_processes=1 --num_machines=1 --mixed_precision=bf16 \
  "$DIFFUSERS_SRC/examples/dreambooth/train_dreambooth_lora_sana.py" \
  --pretrained_model_name_or_path="$BASE" --variant=bf16 \
  --dataset_name="$DATA/train" --image_column=image --caption_column=text \
  --instance_prompt='rivetpaper style' --max_sequence_length=128 \
  --resolution=1024 --center_crop --repeats=1 \
  --train_batch_size=1 --gradient_accumulation_steps=4 \
  --gradient_checkpointing --offload --rank=8 --lora_alpha=8 \
  --mixed_precision=bf16 --learning_rate=1e-4 --optimizer=AdamW \
  --lr_scheduler=constant_with_warmup --lr_warmup_steps="$WARMUP" \
  --max_train_steps="$STEPS" --max_grad_norm=1 --dataloader_num_workers=0 \
  --checkpointing_steps=250 --checkpoints_total_limit=4 \
  --report_to=tensorboard --seed=17 --output_dir="$OUT" "${EXTRA[@]}"
