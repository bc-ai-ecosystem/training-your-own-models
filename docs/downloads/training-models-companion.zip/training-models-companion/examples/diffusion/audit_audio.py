#!/usr/bin/env python3
"""Signal checks and spectral-neighbor screen. Not a perceptual quality metric.
Needs only numpy + scipy. Use PCM16 mono WAV at 16 kHz, 8192 samples.
"""
import argparse
import csv
from pathlib import Path
import wave
import numpy as np
from scipy.signal import stft

def read(path):
    with wave.open(str(path),'rb') as f:
        if (f.getnchannels(),f.getsampwidth(),f.getframerate(),f.getnframes()) != (1,2,16000,8192):
            raise ValueError(f'Unexpected format: {path}')
        return np.frombuffer(f.readframes(8192),dtype='<i2').astype(np.float32)/32768

def feature(x):
    _,_,z=stft(x,fs=16000,nperseg=256,noverlap=128,boundary=None)
    v=np.log1p(100*np.abs(z)).reshape(-1)
    return v/max(np.linalg.norm(v),1e-8)

def main():
    p=argparse.ArgumentParser(); p.add_argument('--data',type=Path,required=True)
    p.add_argument('--samples',type=Path,required=True); a=p.parse_args()
    with (a.data/'manifest.csv').open() as f:
        train=[r for r in csv.DictReader(f) if r['split']=='train']
    feats=np.stack([feature(read(a.data/r['path'])) for r in train])
    print('file,rms,peak,dc,near_full_scale_fraction,nearest_train,spectral_cosine')
    for path in sorted(a.samples.glob('*.wav')):
        x=read(path); sim=feats@feature(x); j=int(sim.argmax())
        print(f'{path.name},{np.sqrt(np.mean(x*x)):.6f},{abs(x).max():.6f},{x.mean():.6f},{np.mean(abs(x)>.99):.6f},{train[j]["path"]},{sim[j]:.6f}')
    print('High similarity flags a listening comparison; periodic sounds can match naturally.')
if __name__=='__main__': main()
