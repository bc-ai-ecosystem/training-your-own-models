"""CPU/stdlib-only tests; does not claim PyTorch runtime validation."""
import argparse
import copy
import csv
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from audio_run_integrity import (check_output_directory, create_run_metadata,
    record_invocation, validate_resume, verified_manifest)

class IntegrityTests(unittest.TestCase):
    def test_wav_tamper_and_paths(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); wav=root/'sound.wav'; wav.write_bytes(b'fixture bytes')
            row={'path':'sound.wav','split':'train','group':'g','sha256':hashlib.sha256(wav.read_bytes()).hexdigest()}
            with (root/'manifest.csv').open('w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(row)); w.writeheader(); w.writerow(row)
            self.assertEqual(len(verified_manifest(root)[0]),1)
            wav.write_bytes(b'changed audio')
            with self.assertRaisesRegex(ValueError,'SHA-256 mismatch'): verified_manifest(root)

    def test_material_config_immutability_and_allowed_step_extension(self):
        config={'batch':4,'accum':1,'learning_rate':.0002,'seed':123,'device':'cuda:0',
                'schedule':'cosine','source_sha256':'abc','data_manifest_sha256':'def'}
        run={'run_id':'r','material_config':config}
        ck={'run_id':'r','material_config':copy.deepcopy(config),'step':200}
        validate_resume(ck,run,copy.deepcopy(config),10000)
        for key in config:
            current=copy.deepcopy(config); current[key]='changed'
            with self.subTest(key=key),self.assertRaisesRegex(ValueError,'material configuration'):
                validate_resume(ck,run,current,10000)
        with self.assertRaisesRegex(ValueError,'greater'): validate_resume(ck,run,config,200)
        other=copy.deepcopy(ck); other['run_id']='other'
        with self.assertRaisesRegex(ValueError,'different runs'): validate_resume(other,run,config,10000)

    def test_output_protection_and_preserved_metadata(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)/'run'
            args=argparse.Namespace(out=out,steps=200,log_every=50,save_every=200)
            check_output_directory(out,None)
            meta=create_run_metadata(out,args,{'learning_rate':.0002})
            before=(out/'run.json').read_bytes()
            with self.assertRaisesRegex(ValueError,'nonempty'): check_output_directory(out,None)
            ck=out/'step-200.pt'; ck.write_bytes(b'fixture')
            check_output_directory(out,ck)
            args.steps=10000; args.log_every=100; args.save_every=1000
            invocation=record_invocation(out,args,meta['run_id'],200,[.0002])
            self.assertEqual(before,(out/'run.json').read_bytes())
            record=json.loads((out/'invocations.jsonl').read_text())
            self.assertEqual(record['effective_optimizer_lrs'],[.0002])
            self.assertEqual(record['request']['steps'],10000)
            self.assertEqual(record['invocation_id'],invocation)
            with self.assertRaises(FileExistsError): create_run_metadata(out,args,{})

if __name__=='__main__': unittest.main()
