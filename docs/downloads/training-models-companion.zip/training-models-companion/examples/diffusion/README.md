# Diffusion teaching examples

Read `../../training-your-own-models.md` in the book source for the ordered projects and parameter explanations. Run commands from this directory, or copy this directory as a unit to a fresh work directory.

## Included files

- `make_image_cards.py`: original native-1024 procedural PNG illustrations and JSONL captions
- `check_image_data.py`: validates captions, groups, readable images, orientation and exact pixel duplicates
- `requirements-image.txt`: pinned candidate image environment; install the torch/torchvision pair separately as in the chapter
- `patch_image_trainer.py`: guarded Sana v0.36.0 correction that skips an unused final second-pipeline allocation
- `image_run_manifest.py`: binds adapter to the pinned base/configuration, data hashes and trainer settings
- `test_image_run_manifest.py`: standard-library base/data identity regression tests
- `evaluate_image_grid.py`: fixed held-out caption/seed samples and an unscored human-review CSV
- `train_image_lora.sh`: local Sana 1.6B BF16 LoRA recipe using Diffusers v0.36.0, with offload and no latent-position cache
- `sample_image_lora.py`: trained Sana adapter inference on CUDA/BF16 with FP32 DC-AE and model offload, or all-FP32 CPU; also generates the unchanged baseline
- `make_tiny_sfx.py`: original synthetic thumps, pings and hisses in PCM16 WAV format
- `tiny_audio_ddpm.py`: full small class-conditioned waveform model; train, resume, evaluate and sample on CPU or CUDA
- `audio_run_integrity.py`: validates file hashes, immutable resume settings and output ownership
- `test_audio_run_integrity.py`: standard-library resume/data/output regression tests
- `audit_audio.py`: signal-integrity and nearest-spectral-neighbor review aid

## Verification status

Generators, image data validation and audio diagnostic smoke tests were run. All Python files were syntax-checked; the shell script passed `bash -n`. PyTorch runtime, dependency installation, model downloads, neural-network training/inference and GPU memory were not executed or measured in the authoring environment. These are inspectable educational scripts with explicit smoke tests, not claimed benchmarked training results.

Keep the image and audio environments separate. Scripts do not upload training data, model weights or telemetry to a hosted experiment tracker. Model/library downloads require internet access; inspect model licenses and access terms before downloading.

For CPU-only tiny-audio experiments, the official CPU wheel can replace the CUDA wheel:

```bash
python -m pip install torch==2.7.1 --index-url https://download.pytorch.org/whl/cpu
```

Training a useful model on CPU will usually be slow; a CPU smoke test is enough to validate file/shape/checkpoint mechanics before moving to the intended GPU.

Resume retains the original run metadata and writes per-invocation settings separately. Material settings and verified audio bytes must remain unchanged; total steps and logging/saving cadence can change. Run the standard-library checks with `python -m unittest discover -s . -p test_audio_run_integrity.py -v`. They do not execute PyTorch.

The image manifest is required for adapter inference. Retain the pinned Hub snapshot directory name, base_revision.json and book_run_manifest.json. Base weight files are assumed immutable; model configs and training data are hashed. GPU inference checks BF16 support before loading.
