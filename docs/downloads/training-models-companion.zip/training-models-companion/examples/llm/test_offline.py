"""Standard-library unit tests only. These do not validate any model's quality."""
import unittest
import json
import tempfile
from pathlib import Path
from score_tools import parse_call, score
from train_small_lm import check_splits, validate_resume


class OfflineTests(unittest.TestCase):
    def test_valid_call(self):
        self.assertEqual(parse_call('<tool_call>{"name":"lookup_part","arguments":{"part_id":"P-123"}}</tool_call>'),
                         {"name": "lookup_part", "arguments": {"part_id": "P-123"}})

    def test_no_call(self):
        self.assertIsNone(parse_call("What is the part ID?"))

    def test_bad_schema(self):
        with self.assertRaises(ValueError):
            parse_call('<tool_call>{"name":"delete_part","arguments":{"part_id":"P-123"}}</tool_call>')

    def test_incomplete_call(self):
        with self.assertRaises(ValueError):
            parse_call('<tool_call>{"name":')

    def test_extra_delimiters(self):
        valid = '<tool_call>{"name":"lookup_part","arguments":{"part_id":"P-123"}}</tool_call>'
        for suffix in ('<tool_call>{', '</tool_call>', '<tool_call>', '<tool_callx>'):
            with self.subTest(suffix=suffix), self.assertRaises(ValueError):
                parse_call(valid + suffix)

    def test_duplicate_json_keys(self):
        with self.assertRaises(ValueError):
            parse_call('<tool_call>{"name":"lookup_part","name":"lookup_part","arguments":{"part_id":"P-123"}}</tool_call>')

    def test_nonobject_root(self):
        with self.assertRaises(ValueError):
            parse_call('<tool_call>["name", "arguments"]</tool_call>')

    def test_leak(self):
        with self.assertRaises(ValueError):
            check_splits([{"source_id": "same"}], [{"source_id": "same"}])

    def test_score_is_not_model_result(self):
        gold = {"x": {"expected_call": None}}
        predictions = {"x": {"text": "What is the part ID?"}}
        self.assertEqual(score(gold, predictions)["decision_correct"], 1)

    def resume_fixture(self, root):
        checkpoint = root / "checkpoint-2"
        checkpoint.mkdir()
        for name in ("optimizer.pt", "scheduler.pt", "rng_state.pth", "adapter_model.safetensors"):
            (checkpoint / name).write_text("unit test placeholder, not a real checkpoint")
        (checkpoint / "trainer_state.json").write_text(json.dumps({"global_step": 2}))
        manifest = {"manifest_version": 2, "configuration": {"steps": 10, "accum": 8},
                    "data_hashes": {"train": "abc", "eval": "def"},
                    "packages": {"torch": "test-only"}, "recipe_sha256": "source"}
        (root / "run_manifest.json").write_text(json.dumps(manifest))
        return checkpoint, manifest

    def test_resume_preserves_manifest(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            checkpoint, manifest = self.resume_fixture(root)
            before = (root / "run_manifest.json").read_bytes()
            self.assertEqual(validate_resume(root, checkpoint, manifest)[1], 2)
            self.assertEqual((root / "run_manifest.json").read_bytes(), before)

    def test_resume_rejects_configuration_drift(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            checkpoint, manifest = self.resume_fixture(root)
            manifest["configuration"]["steps"] = 20
            with self.assertRaises(ValueError):
                validate_resume(root, checkpoint, manifest)

    def test_resume_rejects_data_drift(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            checkpoint, manifest = self.resume_fixture(root)
            manifest["data_hashes"]["train"] = "changed"
            with self.assertRaises(ValueError):
                validate_resume(root, checkpoint, manifest)

    def test_resume_rejects_other_run(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            checkpoint, manifest = self.resume_fixture(root)
            with self.assertRaises(ValueError):
                validate_resume(root / "other-run", checkpoint, manifest)

    def test_resume_rejects_incomplete_checkpoint(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            checkpoint, manifest = self.resume_fixture(root)
            (checkpoint / "optimizer.pt").unlink()
            with self.assertRaises(ValueError):
                validate_resume(root, checkpoint, manifest)


if __name__ == "__main__":
    unittest.main()
