# Small language model training examples

This is original educational code, reviewed against official library source on 2026-10-02. It is **not a GPU-tested environment lock or a quality benchmark**. No model weights were downloaded, no dependencies installed, and no GPU training run was performed while preparing this book. Python syntax and fourteen standard-library unit tests were checked. The JSONL files are fictional fixtures for plumbing checks, much too small to justify performance claims.

## Files

- `make_data.py` creates the supplied original JSONL fixtures
- `train_small_lm.py` performs full fine-tuning, BF16 LoRA, or NF4 QLoRA; it also offers a plain-text continued-pretraining objective
- `generate_eval.py` generates baseline or adapted completions without running any tool
- `score_tools.py` tests the toy tool schema and call selection, without executing the predicted call
- `test_offline.py` tests the parser and source-overlap guard, not a language model

## Environment

The intended environment is Linux, Python 3.12, one NVIDIA CUDA GPU with BF16 support and approximately 24GB VRAM. RTX 3090/4090-class cards are examples; measure actual available memory. Install only if you have permission to modify your machine. These commands are instructions for your environment, not a record of an installation here.

```bash
python3.12 -m venv .venv-llm
source .venv-llm/bin/activate
# CUDA 12.6 build is an example from the official PyTorch version page.
# Your NVIDIA driver and GPU must support the selected runtime.
python -m pip install torch==2.12.1 --index-url https://download.pytorch.org/whl/cu126
python -m pip install -r requirements-reviewed.txt
python -m pip check
python -m pip freeze > environment-resolved.txt
nvidia-smi
```

Use the official PyTorch installer/version page to choose a different supported build if necessary. Save the actual resolved lock. Version pins in `requirements-reviewed.txt` identify inspected releases; compatibility on your exact GPU/driver still requires the smoke test.

## Start with a no-training inspection

Run commands from this directory. This stage downloads tokenizer/config files but not weights. It refuses template boundaries that cannot be masked safely, overlapping source IDs, and over-length targets.

```bash
python -m unittest test_offline.py
python train_small_lm.py --train data/style_train.jsonl --eval data/style_valid.jsonl --out runs/inspect --inspect-only
```

## Three-step memory and save check

```bash
CUDA_VISIBLE_DEVICES=0 python train_small_lm.py --train data/style_train.jsonl --eval data/style_valid.jsonl --out runs/style-lora-smoke --mode lora --steps 3
CUDA_VISIBLE_DEVICES=0 python train_small_lm.py --train data/style_train.jsonl --eval data/style_valid.jsonl --out runs/style-full-smoke --mode full --steps 3
```

Compare `run_manifest.json`, `run_results.json`, the first printed masked target, and GPU memory. Three optimizer updates establish only that this path ran. Replace fixtures with an authorized, deduplicated, held-out dataset before extending training. `--steps` counts optimizer updates, `--accum` microbatches per update; it does not count epochs.

## Tool-call plumbing check

```bash
CUDA_VISIBLE_DEVICES=0 python train_small_lm.py --train data/tools_train.jsonl --eval data/tools_valid.jsonl --out runs/tool-lora-smoke --mode lora --steps 3 --max-length 1024
CUDA_VISIBLE_DEVICES=0 python generate_eval.py --input data/tools_test.jsonl --output tools-baseline.jsonl
CUDA_VISIBLE_DEVICES=0 python generate_eval.py --input data/tools_test.jsonl --output tools-adapted.jsonl --run runs/tool-lora-smoke
python score_tools.py data/tools_test.jsonl tools-baseline.jsonl
python score_tools.py data/tools_test.jsonl tools-adapted.jsonl
```

Greedy decoding here is a fixed, non-thinking diagnostic, not Qwen's recommended general sampling recipe. Compare both models with the same settings. No-call correctness still requires reading the prose: silence, a hallucinated answer and a useful clarification all produce no parsed call. Add a held-out interactive mock executor to assess the whole task, then sandbox and validate any real execution separately.

## QLoRA and larger allowed models

```bash
CUDA_VISIBLE_DEVICES=0 python train_small_lm.py --train data/style_train.jsonl --eval data/style_valid.jsonl --out runs/style-qlora-smoke --mode qlora --steps 3
```

The default checkpoint is pinned to `Qwen/Qwen3-0.6B` commit `c1899de289a04d12100db370d81485cdf75e47ca`, as returned by its official Hub metadata when inspected. For `Qwen/Qwen3-1.7B`, read the official model repository's commit history or `HfApi().model_info("Qwen/Qwen3-1.7B").sha` and pass the 40-character SHA with `--revision`. Record it; do not use a guessed hash or `main` in the finished run record. Full-update mode enforces 1B unique parameters, while adapter modes enforce a 3B total scope. This deliberately supports Qwen3 text templates only. Other families need their own template and masking validation, not just a new model name.

## Continued pretraining

Use `--task cpt`, `--train data/cpt_train.jsonl`, and `--eval data/cpt_valid.jsonl`. For a real domain-adaptation experiment, prefer the appropriate base checkpoint, pass its verified revision, and lower the learning rate according to validation. The fixture merely exercises an all-token language-modeling loss. It does not add useful expertise. Do not casually train an instruction model on raw prose and expect its dialogue behavior to survive.

## End-to-end GPU and CPU inference on an unseen input

```bash
python generate_eval.py --run runs/style-lora-smoke --device cuda \
  --prompt "Write a concise update using only these facts: 19 checks passed; one failed; no retry is scheduled." \
  --output fresh-gpu.jsonl --max-new-tokens 96
python generate_eval.py --run runs/style-lora-smoke --device cpu \
  --prompt "Write a concise update using only these facts: 19 checks passed; one failed; no retry is scheduled." \
  --output fresh-cpu.jsonl --max-new-tokens 96
```

The script reads the base ID and immutable revision from the manifest. Full-update runs load `final/` directly; adapter runs load that exact original base and then `PeftModel.from_pretrained(..., final/)`. It loads the saved tokenizer/template, tokenizes the unseen prompt, moves input tensors to the selected device, calls `eval()` and `inference_mode()`, generates a bounded completion, slices off prompt token IDs and decodes only new tokens. CPU uses FP32 and may be slow; CUDA uses BF16. No CPU/GPU timings or quality equivalence were measured here. CPU needs enough RAM for the complete floating-point model, not just the adapter file.

For a QLoRA run, CUDA reloads its NF4 base. The portable CPU route loads the original FP32 base plus the adapter instead of assuming CUDA quantization kernels work on CPU. That changes numerical behavior relative to the quantized training base; re-evaluate it. An alternative is a separately reviewed CPU quantized export/runtime with a conversion script that explicitly supports your architecture. Do not rename a safetensors file to GGUF or assume every adapter can be merged into every quantization format.

For a domain-CPT/base run, use `--raw` with a fresh prefix such as `--prompt "Fictional Northstar manual. A bin identifies"`. A raw base model is a text continuer; an instruction template alone does not make it an assistant. For the tool project, pass `--input data/tools_test.jsonl --device cpu` or `--device cuda` so the exact tool schemas are included in the template; validate the generated call before any execution. None of these examples executes a tool.

## Saving and resuming

Each run stores a local manifest, loss-only validation metrics, and measured allocated/reserved VRAM peaks. `final/` is a full checkpoint for full mode, but an adapter plus tokenizer for LoRA/QLoRA. Keep the base-model commit with every adapter. Checkpoints include optimizer/scheduler state. To resume, pass the same run directory and `--resume runs/name/checkpoint-N`, with unchanged data, recipe, package versions and settings. The code validates these before any write, requires a complete checkpoint immediately inside that run, preserves run_manifest.json, and writes separate resume event/result files. The three-step run uses a three-step learning-rate schedule: extending it later is a new experiment, not an equivalent uninterrupted long run.

## Verification limits and issues to watch

- No CUDA training, model reload, tokenizer-prefix inspection or end-to-end generation has been run here
- Full mode explicitly uses FP32 parameters and ordinary FP32 AdamW state plus BF16 autocast; it is not a 4-bit full update
- `foreach=False`, microbatch 1, checkpointing and short sequences reduce avoidable peaks; none is a fit guarantee
- Quantization metadata, FP32 unquantized modules, activations and runtime workspaces make actual QLoRA memory exceed `0.5 × parameter_count`
- The code reports loss; model quality requires the separate held-out task tests described in the chapter
