"""Offline structural scoring only. Never executes a predicted call.

Usage: python score_tools.py data/tools_test.jsonl predictions.jsonl
Predictions: one {"source_id": "...", "text": "raw generated completion"} per test row.
This reports call syntax/routing/arguments. Human/interactive checks are separate.
"""
import json
import re
import sys


def read(path):
    with open(path, encoding="utf-8") as f:
        rows = [json.loads(line) for line in f if line.strip()]
    by_id = {row["source_id"]: row for row in rows}
    if len(by_id) != len(rows):
        raise ValueError("Duplicate source_id")
    return by_id


def parse_call(text):
    if not isinstance(text, str):
        raise ValueError("Completion must be text")
    calls = list(re.finditer(r"<tool_call>\s*(.*?)\s*</tool_call>", text, flags=re.S))
    if not calls:
        if "<tool_call" in text or "</tool_call" in text:
            raise ValueError("Malformed tool delimiters")
        return None
    if len(calls) != 1:
        raise ValueError("This toy task permits exactly one call")
    match = calls[0]
    outside = text[:match.start()] + text[match.end():]
    if "<tool_call" in outside or "</tool_call" in outside:
        raise ValueError("Extra or incomplete tool delimiters outside the call")
    def unique_object(pairs):
        obj = {}
        for key, value in pairs:
            if key in obj:
                raise ValueError(f"Duplicate JSON key: {key}")
            obj[key] = value
        return obj
    obj = json.loads(match.group(1), object_pairs_hook=unique_object)
    if not isinstance(obj, dict):
        raise ValueError("Call JSON root must be an object")
    if set(obj) != {"name", "arguments"}:
        raise ValueError("Unexpected top-level keys")
    if obj["name"] != "lookup_part" or not isinstance(obj["arguments"], dict):
        raise ValueError("Unknown tool or non-object arguments")
    args = obj["arguments"]
    if set(args) != {"part_id"} or not isinstance(args["part_id"], str):
        raise ValueError("Arguments fail the toy schema")
    if not re.fullmatch(r"P-[0-9]{3}", args["part_id"]):
        raise ValueError("Invalid part ID")
    return obj


def score(gold, predictions):
    if set(gold) != set(predictions):
        raise ValueError("Missing or extra prediction IDs")
    result = {"examples": len(gold), "schema_valid": 0, "decision_correct": 0,
              "exact_call_correct": 0, "expected_calls": 0, "unnecessary_calls": 0,
              "expected_no_call": 0}
    failures = []
    for key, row in gold.items():
        expected = row["expected_call"]
        result["expected_calls"] += expected is not None
        result["expected_no_call"] += expected is None
        try:
            actual = parse_call(predictions[key]["text"])
        except (ValueError, TypeError, json.JSONDecodeError) as e:
            failures.append({"source_id": key, "error": str(e)})
            continue
        result["schema_valid"] += 1
        result["decision_correct"] += (actual is None) == (expected is None)
        result["exact_call_correct"] += expected is not None and actual == expected
        result["unnecessary_calls"] += expected is None and actual is not None
        if actual != expected:
            failures.append({"source_id": key, "expected": expected, "actual": actual})
    result["failures"] = failures
    return result


if __name__ == "__main__":
    print(json.dumps(score(read(sys.argv[1]), read(sys.argv[2])), indent=2))
