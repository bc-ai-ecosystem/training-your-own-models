"""Generate raw completions for review; does not execute tools or score prose.

--run points to train_small_lm.py output. Omit it for the frozen base baseline.
Input rows contain source_id, messages (ending before the target), optional tools.
"""
import argparse
import json
from pathlib import Path
from train_small_lm import DEFAULT_MODEL, DEFAULT_REVISION, read_jsonl


def main():
    p = argparse.ArgumentParser()
    source = p.add_mutually_exclusive_group(required=True)
    source.add_argument("--input")
    source.add_argument("--prompt", help="A fresh unseen input, with no target response")
    p.add_argument("--output", required=True)
    p.add_argument("--run")
    p.add_argument("--base-model", help="Override the untuned baseline model only")
    p.add_argument("--base-revision", help="Exact 40-character commit for --base-model")
    p.add_argument("--device", choices=["cuda", "cpu"], default="cuda")
    p.add_argument("--raw", action="store_true", help="Raw text continuation, for a CPT/base model")
    p.add_argument("--max-new-tokens", type=int, default=128)
    a = p.parse_args()
    if bool(a.base_model) != bool(a.base_revision) or (a.base_revision and len(a.base_revision) != 40):
        p.error("Provide --base-model and its exact 40-character --base-revision together")
    if a.run and a.base_model:
        p.error("An adapted run uses its saved base identity; do not also specify --base-model")
    if Path(a.output).exists():
        p.error("Use a new output filename to preserve earlier predictions")
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    from peft import PeftModel
    if a.device == "cuda" and (not torch.cuda.is_available() or not torch.cuda.is_bf16_supported()):
        raise RuntimeError("The reviewed recipe targets a BF16-capable CUDA GPU")
    model_id, revision, mode = DEFAULT_MODEL, DEFAULT_REVISION, "baseline"
    if a.base_model:
        model_id, revision = a.base_model, a.base_revision
    final = None
    if a.run:
        manifest = json.loads((Path(a.run) / "run_manifest.json").read_text())
        model_id, revision = manifest["model"], manifest["revision"]
        mode = manifest["arguments"]["mode"]
        final = Path(a.run) / "final"
    tokenizer = AutoTokenizer.from_pretrained(
        str(final) if final else model_id,
        **({} if final else {"revision": revision}), trust_remote_code=False,
    )
    dtype = torch.bfloat16 if a.device == "cuda" else torch.float32
    kwargs = {"dtype": dtype, "attn_implementation": "sdpa", "trust_remote_code": False}
    if mode == "full":
        model = AutoModelForCausalLM.from_pretrained(str(final), **kwargs).to(a.device)
    else:
        kwargs["revision"] = revision
        use_quantized_base = mode == "qlora" and a.device == "cuda"
        if use_quantized_base:
            kwargs.update(device_map={"": 0}, quantization_config=BitsAndBytesConfig(
                load_in_4bit=True, bnb_4bit_quant_type="nf4",
                bnb_4bit_compute_dtype=torch.bfloat16, bnb_4bit_use_double_quant=True))
        model = AutoModelForCausalLM.from_pretrained(model_id, **kwargs)
        if not use_quantized_base:
            model.to(a.device)
        if final:
            model = PeftModel.from_pretrained(model, str(final))
    model.eval()
    model.config.use_cache = True
    if mode == "qlora" and a.device == "cpu":
        print("CPU route loads the original FP32 base plus adapter, not the CUDA NF4 base. Re-evaluate outputs.")
    if a.prompt:
        rows = [{"source_id": "fresh-input", "text": a.prompt,
                 "messages": [{"role": "user", "content": a.prompt}]}]
    else:
        rows = read_jsonl(a.input)
    with open(a.output, "w", encoding="utf-8") as f:
        for row in rows:
            if a.raw:
                text = row["text"]
            else:
                messages = row["messages"]
                # Teacher targets in style records are held out from the prompt.
                if messages[-1]["role"] == "assistant":
                    messages = messages[:-1]
                text = tokenizer.apply_chat_template(messages, tools=row.get("tools"),
                        tokenize=False, add_generation_prompt=True, enable_thinking=False)
            inputs = tokenizer(text, add_special_tokens=False, return_tensors="pt").to(a.device)
            with torch.inference_mode():
                result = model.generate(**inputs, max_new_tokens=a.max_new_tokens,
                    do_sample=False, pad_token_id=tokenizer.pad_token_id,
                    eos_token_id=tokenizer.eos_token_id)
            completion = tokenizer.decode(result[0, inputs["input_ids"].shape[1]:], skip_special_tokens=True)
            f.write(json.dumps({"source_id": row["source_id"], "text": completion,
                               "decode": "greedy raw continuation" if a.raw else "greedy non-thinking diagnostic",
                               "mode": mode, "device": a.device, "dtype": str(dtype)}, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
