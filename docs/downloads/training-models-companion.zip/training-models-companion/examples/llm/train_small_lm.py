"""Original teaching recipe. API-reviewed; NOT GPU-tested by the book authors.

Supports Qwen3 text-only checkpoints and explicit completion masks.
No model upload, tracking service, real tools, or remote-code execution.
Run --inspect-only before training. All inputs are local JSONL files.
"""
import argparse
import hashlib
import importlib.metadata as md
import json
import re
from pathlib import Path

DEFAULT_MODEL = "Qwen/Qwen3-0.6B"
DEFAULT_REVISION = "c1899de289a04d12100db370d81485cdf75e47ca"


def validate_resume(output, checkpoint, proposed):
    """Read-only preflight. Reject drift before loading weights or writing files."""
    output, checkpoint = Path(output).resolve(), Path(checkpoint).resolve()
    if checkpoint.parent != output or not re.fullmatch(r"checkpoint-[0-9]+", checkpoint.name):
        raise ValueError("Resume checkpoint must be checkpoint-N immediately inside this run directory")
    required = ["trainer_state.json", "optimizer.pt", "scheduler.pt", "rng_state.pth"]
    if not checkpoint.is_dir() or any(not (checkpoint / f).is_file() for f in required):
        raise ValueError("Incomplete resume checkpoint: need trainer, optimizer, scheduler and RNG state")
    if not any((checkpoint / f).is_file() for f in (
        "model.safetensors", "model.safetensors.index.json", "adapter_model.safetensors"
    )):
        raise ValueError("Resume checkpoint lacks model or adapter weights")
    manifest_file = output / "run_manifest.json"
    if not manifest_file.is_file():
        raise ValueError("Resume requires the original run_manifest.json")
    original = json.loads(manifest_file.read_text(encoding="utf-8"))
    for key in ("manifest_version", "configuration", "data_hashes", "packages", "recipe_sha256"):
        if original.get(key) != proposed.get(key):
            raise ValueError(f"Resume provenance mismatch: {key}. Start a new experiment instead.")
    state = json.loads((checkpoint / "trainer_state.json").read_text(encoding="utf-8"))
    step = state.get("global_step")
    if not isinstance(step, int) or step != int(checkpoint.name.split("-")[-1]):
        raise ValueError("Checkpoint directory and trainer global_step disagree")
    if not 0 <= step <= proposed["configuration"]["steps"]:
        raise ValueError("Checkpoint step lies outside the original training schedule")
    return original, step


def read_jsonl(path):
    with open(path, encoding="utf-8") as f:
        rows = [json.loads(line) for line in f if line.strip()]
    if not rows:
        raise ValueError(f"Empty data file: {path}")
    return rows


def check_splits(train_rows, eval_rows):
    # source_id groups all paraphrases/turns originating from one conversation.
    left = {row["source_id"] for row in train_rows}
    right = {row["source_id"] for row in eval_rows}
    overlap = left & right
    if overlap:
        raise ValueError(f"Source leakage between splits: {sorted(overlap)}")


def encode_rows(rows, tokenizer, max_length, task):
    encoded = []
    for row in rows:
        if task == "cpt":
            # Keep documents separate in this pedagogical recipe. A production
            # packer needs explicit document-boundary and attention semantics.
            ids = tokenizer(row["text"], add_special_tokens=False)["input_ids"]
            ids += [tokenizer.eos_token_id]
            labels = ids.copy()
        else:
            messages = row["messages"]
            if not messages or messages[-1]["role"] != "assistant":
                raise ValueError("Each SFT record must end with one target assistant turn")
            kwargs = {"tools": row.get("tools"), "enable_thinking": False}
            prompt = tokenizer.apply_chat_template(
                messages[:-1], tokenize=False, add_generation_prompt=True, **kwargs
            )
            full = tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=False, **kwargs
            )
            if not full.startswith(prompt):
                raise ValueError("Template changed earlier context: inspect the rendered example")
            ids = tokenizer(full, add_special_tokens=False)["input_ids"]
            prefix_ids = tokenizer(prompt, add_special_tokens=False)["input_ids"]
            if ids[:len(prefix_ids)] != prefix_ids:
                raise ValueError("Tokenization crosses the prompt boundary; do not guess the mask")
            labels = [-100] * len(prefix_ids) + ids[len(prefix_ids):]
        if len(ids) > max_length:
            raise ValueError(
                f"{row['source_id']}: {len(ids)} tokens exceeds {max_length}. "
                "Shorten/restructure data explicitly; this script never silently truncates targets."
            )
        if len(ids) < 2 or not any(x != -100 for x in labels[1:]):
            raise ValueError(f"{row['source_id']}: no next-token targets")
        encoded.append({"input_ids": ids, "attention_mask": [1] * len(ids), "labels": labels})
    return encoded


class PadCollator:
    def __init__(self, tokenizer, torch):
        self.pad_id = tokenizer.pad_token_id
        self.torch = torch

    def __call__(self, examples):
        width = max(len(row["input_ids"]) for row in examples)
        batch = {"input_ids": [], "attention_mask": [], "labels": []}
        for row in examples:
            padding = width - len(row["input_ids"])
            batch["input_ids"].append(row["input_ids"] + [self.pad_id] * padding)
            batch["attention_mask"].append(row["attention_mask"] + [0] * padding)
            batch["labels"].append(row["labels"] + [-100] * padding)
        return {key: self.torch.tensor(value, dtype=self.torch.long) for key, value in batch.items()}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--train", required=True)
    p.add_argument("--eval", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--model", default=DEFAULT_MODEL)
    p.add_argument("--revision", default=None)
    p.add_argument("--mode", choices=["full", "lora", "qlora"], default="lora")
    p.add_argument("--task", choices=["sft", "cpt"], default="sft")
    p.add_argument("--max-length", type=int, default=512)
    p.add_argument("--steps", type=int, default=3)
    p.add_argument("--accum", type=int, default=8)
    p.add_argument("--lr", type=float, default=None)
    p.add_argument("--rank", type=int, default=8)
    p.add_argument("--seed", type=int, default=17)
    p.add_argument("--inspect-only", action="store_true")
    p.add_argument("--resume", default=None)
    a = p.parse_args()
    if a.steps < 1 or a.accum < 1 or a.max_length < 2 or a.rank < 1:
        p.error("steps, accum, rank must be positive and max-length at least 2")
    revision = a.revision or (DEFAULT_REVISION if a.model == DEFAULT_MODEL else None)
    if revision is None or len(revision) != 40:
        p.error("Provide the exact 40-character Hub commit SHA with --revision for this model")
    if a.resume and a.inspect_only:
        p.error("--resume and --inspect-only are separate operations")
    output = Path(a.out)
    package_names = ["torch", "transformers", "accelerate", "peft"]
    if a.mode == "qlora":
        package_names.append("bitsandbytes")
    preflight = {
        "manifest_version": 2,
        "configuration": {key: getattr(a, key) for key in (
            "model", "mode", "task", "max_length", "steps", "accum", "lr", "rank", "seed")},
        "data_hashes": {kind: hashlib.sha256(Path(path).read_bytes()).hexdigest()
                        for kind, path in (("train", a.train), ("eval", a.eval))},
        "packages": {name: md.version(name) for name in package_names},
        "recipe_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    preflight["configuration"]["revision"] = revision
    resumed_step = None
    if a.resume:
        _, resumed_step = validate_resume(output, a.resume, preflight)
    elif not a.inspect_only and output.exists() and any(output.iterdir()):
        raise RuntimeError("Use a fresh output directory, or --resume an existing checkpoint")
    import torch
    from transformers import AutoConfig, AutoModelForCausalLM, AutoTokenizer
    from transformers import BitsAndBytesConfig, Trainer, TrainingArguments, set_seed

    set_seed(a.seed)
    tokenizer = AutoTokenizer.from_pretrained(a.model, revision=revision, trust_remote_code=False)
    tokenizer.padding_side = "right"
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    config = AutoConfig.from_pretrained(a.model, revision=revision, trust_remote_code=False)
    if config.model_type != "qwen3":
        raise ValueError("This teaching script supports the reviewed Qwen3 text template only")
    raw_train, raw_eval = read_jsonl(a.train), read_jsonl(a.eval)
    check_splits(raw_train, raw_eval)
    train = encode_rows(raw_train, tokenizer, a.max_length, a.task)
    evaluation = encode_rows(raw_eval, tokenizer, a.max_length, a.task)
    print("Input including role and stop markers:\n", tokenizer.decode(train[0]["input_ids"]))
    print("Supervised target only:\n", tokenizer.decode([x for x in train[0]["labels"] if x != -100]))
    print(json.dumps({"train_examples": len(train), "eval_examples": len(evaluation),
                      "max_tokens": max(len(x["input_ids"]) for x in train + evaluation),
                      "train_target_tokens_one_pass": sum(sum(t != -100 for t in x["labels"][1:])
                                                          for x in train)}, indent=2))
    if a.inspect_only:
        return
    if not torch.cuda.is_available() or not torch.cuda.is_bf16_supported():
        raise RuntimeError("This recipe requires a CUDA GPU with BF16 support; inspect-only is CPU-safe")
    if torch.cuda.device_count() != 1:
        raise RuntimeError("Expose one GPU, e.g. CUDA_VISIBLE_DEVICES=0")
    output.mkdir(parents=True, exist_ok=True)
    load_kwargs = dict(revision=revision, trust_remote_code=False, attn_implementation="sdpa")
    if a.mode == "qlora":
        load_kwargs.update(
            dtype=torch.bfloat16,
            device_map={"": 0},
            quantization_config=BitsAndBytesConfig(
                load_in_4bit=True, bnb_4bit_quant_type="nf4",
                bnb_4bit_compute_dtype=torch.bfloat16, bnb_4bit_use_double_quant=True,
            ),
        )
    else:
        # Full mode deliberately uses FP32 parameters/gradients/Adam states.
        # BF16 autocast below is a separate compute setting.
        load_kwargs["dtype"] = torch.float32 if a.mode == "full" else torch.bfloat16
    model = AutoModelForCausalLM.from_pretrained(a.model, **load_kwargs)
    if a.mode != "qlora":
        unique_count = sum(p.numel() for p in model.parameters())
        if unique_count > 3_000_000_000 or (a.mode == "full" and unique_count > 1_000_000_000):
            raise ValueError("Book scope: at most 3B total; practical full updates at most 1B")
    model.config.use_cache = False
    if a.mode != "full":
        from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
        if a.mode == "qlora":
            model = prepare_model_for_kbit_training(
                model, use_gradient_checkpointing=True,
                gradient_checkpointing_kwargs={"use_reentrant": False},
            )
        model = get_peft_model(model, LoraConfig(
            task_type="CAUSAL_LM", target_modules="all-linear", r=a.rank,
            lora_alpha=2*a.rank, lora_dropout=0.05, bias="none",
        ))
        total, trainable = model.get_nb_trainable_parameters()[1], model.get_nb_trainable_parameters()[0]
        if total > 3_000_000_000:
            raise ValueError("Counted total exceeds the book's 3B scope")
    else:
        total = trainable = sum(p.numel() for p in model.parameters())
    print({"total_parameters": total, "trainable_parameters": trainable})
    lr = a.lr or (1e-5 if a.mode == "full" else 1e-4)
    interval = max(1, min(20, a.steps))
    args = TrainingArguments(
        output_dir=str(output), per_device_train_batch_size=1, per_device_eval_batch_size=1,
        gradient_accumulation_steps=a.accum, max_steps=a.steps, learning_rate=lr,
        weight_decay=0.01,
        bf16=True, fp16=False, gradient_checkpointing=True,
        gradient_checkpointing_kwargs={"use_reentrant": False},
        lr_scheduler_type="linear", warmup_steps=0 if a.steps < 20 else max(1, a.steps//20),
        max_grad_norm=1.0, logging_steps=1, eval_strategy="steps", eval_steps=interval,
        save_strategy="steps", save_steps=interval, save_total_limit=2,
        report_to="none", push_to_hub=False, seed=a.seed, data_seed=a.seed,
        dataloader_num_workers=0, prediction_loss_only=True, label_names=["labels"],
    )
    trainer = Trainer(
        model=model, args=args, train_dataset=train, eval_dataset=evaluation,
        data_collator=PadCollator(tokenizer, torch), processing_class=tokenizer,
        optimizer_cls_and_kwargs=(torch.optim.AdamW, {
            "lr": lr, "betas": (0.9, 0.999), "eps": 1e-8,
            "foreach": False,
        }),
    )
    manifest = {
        **preflight,
        "model": a.model, "revision": revision, "arguments": vars(a),
        "cuda_runtime": torch.version.cuda, "gpu": torch.cuda.get_device_name(0),
        "source_sha256": {f: hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in (a.train, a.eval)},
        "total_parameters": total, "trainable_parameters": trainable,
        "verification": "This manifest describes this run; the book did not GPU-test the recipe.",
    }
    # The original manifest is immutable across resumes. A resume event records
    # its device separately and cannot silently replace the original provenance.
    if a.resume:
        import time
        event = f"resume-{resumed_step}-{time.time_ns()}"
        (output / f"{event}-manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        baseline = None  # Trainer loads resumed weights inside train(), not yet.
    else:
        event = "run"
        (output / "run_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        baseline = trainer.evaluate()
    torch.cuda.synchronize()
    torch.cuda.reset_peak_memory_stats()
    trainer.train(resume_from_checkpoint=a.resume)
    after = trainer.evaluate()
    torch.cuda.synchronize()
    results = {"before": baseline, "after": after,
               "peak_allocated_GiB": torch.cuda.max_memory_allocated()/2**30,
               "peak_reserved_GiB": torch.cuda.max_memory_reserved()/2**30}
    (output / f"{event}_results.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    trainer.save_model(str(output / "final"))
    tokenizer.save_pretrained(output / "final")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
