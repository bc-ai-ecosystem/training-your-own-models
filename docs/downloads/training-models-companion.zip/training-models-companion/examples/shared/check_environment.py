"""Read-only local environment report. Does not install packages or download models."""
import importlib.metadata, json, platform, shutil
report={'python':platform.python_version(),'platform':platform.platform(),'free_disk_bytes':shutil.disk_usage('.').free,'packages':{}}
for package in ['torch','transformers','peft','trl','diffusers','sentence-transformers','scikit-learn','numpy']:
    try:report['packages'][package]=importlib.metadata.version(package)
    except importlib.metadata.PackageNotFoundError:report['packages'][package]=None
if report['packages']['torch']:
    import torch
    report['cuda_available']=torch.cuda.is_available()
    if torch.cuda.is_available():report['gpu']={'name':torch.cuda.get_device_name(0),'vram_bytes':torch.cuda.get_device_properties(0).total_memory,'bf16':torch.cuda.is_bf16_supported()}
print(json.dumps(report,indent=2))
