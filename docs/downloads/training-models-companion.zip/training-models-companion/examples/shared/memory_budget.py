"""Arithmetic worksheet, not a GPU fit predictor. Python standard library only."""
import argparse, json
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--parameters',type=int,required=True)
p.add_argument('--weight-bytes',type=float,default=4)
p.add_argument('--gradient-bytes',type=float,default=4)
p.add_argument('--optimizer-bytes',type=float,default=8)
p.add_argument('--master-bytes',type=float,default=0)
a=p.parse_args()
if a.parameters<0 or min(a.weight_bytes,a.gradient_bytes,a.optimizer_bytes,a.master_bytes)<0:p.error('values must be nonnegative')
parts={name:a.parameters*getattr(a,name+'_bytes') for name in ['weight','gradient','optimizer','master']}
total=sum(parts.values())
print(json.dumps({'assumptions':vars(a),'bytes_by_component':parts,'total_GB':total/1e9,'total_GiB':total/1024**3,'excluded':'activations, temporary buffers, quantization metadata, allocator and framework overhead; not a fit guarantee'},indent=2))
