"""Tiny U-Net-like semantic segmenter, PyTorch 2.8.0 API target.
Syntax-checked only by book authors; no PyTorch/GPU execution in author environment.
"""
import argparse
import json
import random
import time
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
from mask_metrics import mask_scores


class Shapes(Dataset):
    def __init__(self, root, split, augment=False):
        self.root = Path(root) / split
        self.files = sorted((self.root / "images").glob("*.png"))
        if not self.files:
            raise ValueError(f"No PNG files in {self.root}")
        self.augment = augment

    def __len__(self):
        return len(self.files)

    def __getitem__(self, i):
        path = self.files[i]
        x = np.asarray(Image.open(path).convert("RGB"), dtype=np.float32) / 255.
        y = (np.asarray(Image.open(self.root / "masks" / path.name)) > 127).astype(np.float32)
        if self.augment:
            # Every spatial transform must also be applied to the mask.
            if random.random() < .5:
                x, y = x[:, ::-1], y[:, ::-1]
            k = random.randrange(4)
            x, y = np.rot90(x, k), np.rot90(y, k)
        return torch.from_numpy(x.copy().transpose(2, 0, 1)), torch.from_numpy(y.copy()[None])


def block(cin, cout):
    return nn.Sequential(nn.Conv2d(cin, cout, 3, padding=1), nn.ReLU(),
                         nn.Conv2d(cout, cout, 3, padding=1), nn.ReLU())


class TinyUNet(nn.Module):
    def __init__(self, width=16):
        super().__init__()
        self.enc1, self.enc2 = block(3, width), block(width, width*2)
        self.middle = block(width*2, width*4)
        self.dec2, self.dec1 = block(width*6, width*2), block(width*3, width)
        self.pool = nn.MaxPool2d(2)
        self.head = nn.Conv2d(width, 1, 1)

    def forward(self, x):
        a = self.enc1(x); b = self.enc2(self.pool(a)); c = self.middle(self.pool(b))
        c = nn.functional.interpolate(c, size=b.shape[-2:], mode="bilinear", align_corners=False)
        d = self.dec2(torch.cat([c, b], 1))
        d = nn.functional.interpolate(d, size=a.shape[-2:], mode="bilinear", align_corners=False)
        return self.head(self.dec1(torch.cat([d, a], 1)))


def objective(logits, y):
    bce = nn.functional.binary_cross_entropy_with_logits(logits, y)
    p = logits.sigmoid().float()  # Accumulate Dice reductions in FP32 under AMP.
    intersection = (p*y).sum((1, 2, 3))
    # One Dice term per image; smoothing handles tiny or empty foreground safely.
    dice_loss = 1 - ((2*intersection + 1) / (p.sum((1, 2, 3)) + y.sum((1, 2, 3)) + 1)).mean()
    return bce + dice_loss


@torch.no_grad()
def evaluate(model, loader, device, threshold=.5):
    model.eval()
    losses, scores, samples = [], [], []
    for x, y in loader:
        logits = model(x.to(device))
        losses.append(float(objective(logits, y.to(device))) * len(x))
        probs = logits.sigmoid().cpu().numpy()[:, 0]
        for p, t in zip(probs, y.numpy()[:, 0]):
            scores.append(mask_scores(p >= threshold, t > .5))
        if len(samples) < 8:
            samples.extend([(xx.numpy(), p, t.numpy()[0]) for xx, p, t in zip(x, probs, y)])
    return {"loss": sum(losses)/len(loader.dataset),
            "mean_image_iou": float(np.mean([s["iou"] for s in scores])),
            "mean_image_boundary_f1_tol2": float(np.mean([s["boundary_f1"] for s in scores]))}, samples[:8]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/shapes")
    ap.add_argument("--out", default="runs/segmenter")
    ap.add_argument("--epochs", type=int, default=15)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--width", type=int, default=16)
    ap.add_argument("--lr", type=float, default=.001)
    ap.add_argument("--weight-decay", type=float, default=.0001)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    ap.add_argument("--amp", action="store_true", help="CUDA FP16 autocast with GradScaler")
    a = ap.parse_args()
    if a.epochs < 1 or a.batch_size < 1 or a.width < 1:
        ap.error("epochs, batch-size, and width must be positive")
    if a.amp and a.device != "cuda":
        ap.error("--amp requires --device cuda")
    random.seed(a.seed); np.random.seed(a.seed); torch.manual_seed(a.seed)
    if a.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable; choose --device cpu or install a compatible build")
    device = torch.device(a.device)
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    loaders = {s: DataLoader(Shapes(a.data, s, s == "train"), batch_size=a.batch_size,
                            shuffle=(s == "train"), num_workers=0) for s in ["train", "val", "test"]}
    model = TinyUNet(a.width).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=a.weight_decay)
    scaler = torch.amp.GradScaler("cuda", enabled=a.amp)
    best, history = float("inf"), []
    start = time.perf_counter()
    for epoch in range(a.epochs):
        model.train(); total = 0.
        for x, y in loaders["train"]:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=a.amp):
                loss = objective(model(x), y)
            if not torch.isfinite(loss):
                raise RuntimeError("Non-finite loss; inspect data, learning rate, and AMP")
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            nn.utils.clip_grad_norm_(model.parameters(), 1.)
            scaler.step(optimizer); scaler.update()
            total += float(loss.detach()) * len(x)
        metrics, _ = evaluate(model, loaders["val"], device)
        row = {"epoch": epoch + 1, "train_loss": total / len(loaders["train"].dataset), **metrics}
        history.append(row); print(json.dumps(row))
        if metrics["loss"] < best:
            best = metrics["loss"]
            torch.save({"state_dict": model.state_dict(), "width": a.width}, out / "best.pt")
    checkpoint = torch.load(out / "best.pt", map_location=device, weights_only=True)
    model.load_state_dict(checkpoint["state_dict"])
    # Fixed .5 threshold; tuning any postprocess must use validation, never test.
    test, samples = evaluate(model, loaders["test"], device)
    for i, (x, p, y) in enumerate(samples):
        Image.fromarray((x.transpose(1, 2, 0)*255).astype(np.uint8)).save(out / f"{i:02d}_input.png")
        Image.fromarray((p*255).astype(np.uint8)).save(out / f"{i:02d}_probability.png")
        Image.fromarray(((p >= .5)*255).astype(np.uint8)).save(out / f"{i:02d}_prediction.png")
        Image.fromarray((y*255).astype(np.uint8)).save(out / f"{i:02d}_target.png")
    result = {"config": vars(a), "torch": torch.__version__, "parameters": sum(p.numel() for p in model.parameters()),
              "seconds": time.perf_counter()-start, "test": test, "history": history,
              "cuda_peak_allocated_bytes": torch.cuda.max_memory_allocated() if device.type == "cuda" else None,
              "synthetic_only": True}
    (out / "metrics.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result["test"], indent=2))

if __name__ == "__main__":
    main()
