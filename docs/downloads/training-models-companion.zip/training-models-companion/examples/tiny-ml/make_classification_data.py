"""Original circle/square/triangle RGB fixture for the first neural image lab."""
import argparse, json
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw


def draw_shape(rng, name, size=96):
    background=tuple(int(v) for v in rng.integers(15,70,3))
    foreground=tuple(int(v) for v in rng.integers(120,240,3))
    im=Image.new('RGB',(size,size),background);d=ImageDraw.Draw(im)
    x=int(rng.integers(8,25));y=int(rng.integers(8,25));span=int(rng.integers(40,64))
    if name=='circle':d.ellipse((x,y,x+span,y+span),fill=foreground)
    elif name=='square':d.rectangle((x,y,x+span,y+span),fill=foreground)
    elif name=='triangle':d.polygon([(x+span//2,y),(x,y+span),(x+span,y+span)],fill=foreground)
    else:raise ValueError(name)
    return im


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--train',type=int,default=24);p.add_argument('--val',type=int,default=8);p.add_argument('--test',type=int,default=8)
    a=p.parse_args()
    if min(a.train,a.val,a.test)<1:p.error('split counts per class must be positive')
    if a.out.exists() and any(a.out.iterdir()):p.error('use an empty output directory')
    classes=['circle','square','triangle']
    for j,(split,n) in enumerate([('train',a.train),('val',a.val),('test',a.test)]):
        rng=np.random.default_rng(800+j)
        for cls in classes:
            folder=a.out/split/cls;folder.mkdir(parents=True,exist_ok=True)
            for i in range(n):draw_shape(rng,cls).save(folder/f'{i:04d}.png')
    draw_shape(np.random.default_rng(900),'circle').save(a.out/'fresh-circle.png')
    (a.out/'fixture.json').write_text(json.dumps({'classes':classes,'independent_seeds':[800,801,802],'fresh_seed':900,'purpose':'synthetic plumbing test; not real defect detection'},indent=2))
    print(a.out)
if __name__=='__main__':main()
