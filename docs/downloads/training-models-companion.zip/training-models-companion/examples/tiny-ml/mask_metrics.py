"""Per-image IoU and symmetric boundary F1 with Chebyshev pixel tolerance.
These are not the paper's Boundary IoU metric. Empty/empty => 1; one empty => 0.
"""
import numpy as np
from scipy.ndimage import binary_dilation, binary_erosion


def mask_scores(pred, target, tolerance=2):
    p, t = np.asarray(pred, dtype=bool), np.asarray(target, dtype=bool)
    if p.shape != t.shape:
        raise ValueError("Mask shapes differ")
    if tolerance < 0:
        raise ValueError("Tolerance cannot be negative")
    union = np.logical_or(p, t).sum()
    iou = float(np.logical_and(p, t).sum() / union) if union else 1.
    structure = np.ones((3, 3), bool)
    pb = p ^ binary_erosion(p, structure=structure, border_value=0)
    tb = t ^ binary_erosion(t, structure=structure, border_value=0)
    if not pb.any() and not tb.any():
        return {"iou": iou, "boundary_f1": 1.}
    if not pb.any() or not tb.any():
        return {"iou": iou, "boundary_f1": 0.}
    pd = binary_dilation(pb, structure=structure, iterations=tolerance) if tolerance else pb
    td = binary_dilation(tb, structure=structure, iterations=tolerance) if tolerance else tb
    precision = float((pb & td).sum() / pb.sum())
    recall = float((tb & pd).sum() / tb.sum())
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.
    return {"iou": iou, "boundary_f1": f1}

if __name__ == "__main__":
    a = np.zeros((32, 32), bool); a[8:24, 8:24] = True
    assert mask_scores(a, a) == {"iou": 1., "boundary_f1": 1.}
    assert mask_scores(a, ~a)["iou"] == 0.
    assert mask_scores(a, np.zeros_like(a))["boundary_f1"] == 0.
    assert mask_scores(np.zeros_like(a), np.zeros_like(a))["iou"] == 1.
    shifted = np.roll(a, 1, axis=1)
    assert mask_scores(shifted, a, 1)["boundary_f1"] == 1.
    assert mask_scores(shifted, a, 0)["boundary_f1"] < 1.
    print("mask metric tests passed")
