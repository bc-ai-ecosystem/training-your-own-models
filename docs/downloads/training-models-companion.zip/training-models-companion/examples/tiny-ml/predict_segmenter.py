"""Predict one RGB image using a trusted locally trained checkpoint.
No resize is performed: output coordinates are the original pixel coordinates.
"""
import argparse
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from train_segmenter import TinyUNet
ap = argparse.ArgumentParser()
ap.add_argument("checkpoint")
ap.add_argument("image")
ap.add_argument("--out", default="prediction")
ap.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
ap.add_argument("--threshold", type=float, default=.5)
a = ap.parse_args()
if a.device == "cuda" and not torch.cuda.is_available():
    ap.error("CUDA unavailable")
if not 0 <= a.threshold <= 1:
    ap.error("threshold must lie in [0,1]")
ckpt = torch.load(a.checkpoint, map_location="cpu", weights_only=True)
model = TinyUNet(ckpt["width"]); model.load_state_dict(ckpt["state_dict"]); model.to(a.device).eval()
x = np.asarray(Image.open(a.image).convert("RGB"), dtype=np.float32)/255.
if min(x.shape[:2]) < 4:
    ap.error("image dimensions must be at least 4")
with torch.inference_mode():
    p = model(torch.from_numpy(x.transpose(2, 0, 1).copy())[None].to(a.device)).sigmoid()[0, 0].cpu().numpy()
out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
Image.fromarray((p*255).astype(np.uint8)).save(out / "probability.png")
Image.fromarray(((p >= a.threshold)*255).astype(np.uint8)).save(out / "mask.png")
print(out)
