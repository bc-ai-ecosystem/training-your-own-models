"""Original synthetic RGB/semantic-mask pairs. No downloads or third-party images."""
import argparse
import json
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw


def make_pair(rng, size, max_objects=4, empty_probability=0.10):
    mask = Image.new("L", (size, size), 0)
    draw = ImageDraw.Draw(mask)
    count = 0 if rng.random() < empty_probability else int(rng.integers(1, max_objects + 1))
    for _ in range(count):
        cx, cy = rng.uniform(.15, .85, 2) * size
        radius = rng.uniform(.07, .20) * size
        angles = np.linspace(0, 2 * np.pi, 12, endpoint=False)
        radii = radius * rng.uniform(.7, 1.3, len(angles))
        points = [(cx + r * np.cos(a), cy + r * np.sin(a)) for r, a in zip(radii, angles)]
        draw.polygon(points, fill=255)
        # Some targets have real holes. Postprocessing must not blindly fill them.
        if rng.random() < .20:
            r = .25 * radius
            draw.ellipse((cx-r, cy-r, cx+r, cy+r), fill=0)
    m = np.asarray(mask) > 0
    yy, xx = np.mgrid[:size, :size]
    illumination = rng.uniform(-.15, .15) * xx / size + rng.uniform(-.15, .15) * yy / size
    base = rng.uniform(.12, .35, 3)
    rgb = base + illumination[..., None] + rng.normal(0, .055, (size, size, 3))
    # Foreground has a learnable color cue, with independent brightness and noise.
    color = np.array([.30, .65, .58]) + rng.normal(0, .06, 3)
    rgb[m] = color + illumination[m, None] + rng.normal(0, .08, (m.sum(), 3))
    image = Image.fromarray((np.clip(rgb, 0, 1) * 255).astype(np.uint8))
    return image, mask


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data/shapes")
    ap.add_argument("--size", type=int, default=128)
    ap.add_argument("--train", type=int, default=256)
    ap.add_argument("--val", type=int, default=64)
    ap.add_argument("--test", type=int, default=64)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--max-objects", type=int, default=4)
    ap.add_argument("--empty-probability", type=float, default=0.10)
    a = ap.parse_args()
    if a.size < 32 or a.size % 4:
        ap.error("size must be >=32 and divisible by 4")
    if a.max_objects < 1 or not 0 <= a.empty_probability <= 1:
        ap.error("max-objects must be positive and empty-probability in [0,1]")
    root = Path(a.out)
    if root.exists() and any(root.iterdir()):
        ap.error("output must be empty; keep prior data immutable")
    for offset, (split, n) in enumerate([("train", a.train), ("val", a.val), ("test", a.test)]):
        rng = np.random.default_rng(a.seed + 10000 * offset)
        for folder in ["images", "masks"]:
            (root / split / folder).mkdir(parents=True, exist_ok=True)
        for i in range(n):
            image, mask = make_pair(rng, a.size, a.max_objects, a.empty_probability)
            image.save(root / split / "images" / f"{i:05d}.png")
            mask.save(root / split / "masks" / f"{i:05d}.png")
    (root / "manifest.json").write_text(json.dumps(vars(a) | {"synthetic": True, "mask_values": [0, 255]}, indent=2))
    print(root)

if __name__ == "__main__":
    main()
