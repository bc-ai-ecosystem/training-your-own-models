"""Load a trusted saved detector and return a box in original image coordinates."""
import argparse,json
from pathlib import Path
import torch
from PIL import Image,ImageDraw
from train_detector import Detector,image_tensor
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('run',type=Path);p.add_argument('image',type=Path)
p.add_argument('--device',choices=['cpu','cuda'],default='cpu');p.add_argument('--overlay',type=Path)
a=p.parse_args()
if a.device=='cuda' and not torch.cuda.is_available():p.error('CUDA requested but unavailable')
c=json.loads((a.run/'config.json').read_text())
if c['architecture']!='original_single_object_cnn_v1' or c['input_size']!=[96,96]:raise ValueError('unsupported artifact')
m=Detector().to(a.device);m.load_state_dict(torch.load(a.run/'best.pt',map_location=a.device,weights_only=True));m.eval()
with Image.open(a.image) as im:
 im=im.convert('RGB');w,h=im.size
 with torch.inference_mode():logit,box=m(image_tensor(im).unsqueeze(0).to(a.device))
 probability=logit.sigmoid().item();normalized=box[0].cpu().tolist()
 pixel=[normalized[0]*w,normalized[1]*h,normalized[2]*w,normalized[3]*h]
 detected=probability>=c['threshold']
 result={'detected':detected,'probability':probability,'threshold':c['threshold'],'class':c['class_names'][0] if detected else None,
         'box_xyxy_original_pixels':pixel if detected else None,'image_size':[w,h]}
 if a.overlay:
  if detected:ImageDraw.Draw(im).rectangle(pixel,outline='red',width=2)
  a.overlay.parent.mkdir(parents=True,exist_ok=True);im.save(a.overlay)
 print(json.dumps(result,indent=2))
