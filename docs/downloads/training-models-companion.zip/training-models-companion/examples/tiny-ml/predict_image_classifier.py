"""Inference on an unseen owned image. Torch/vision API-targeted; not runtime-tested."""
import argparse
import json
from pathlib import Path
from PIL import Image
import torch
from torch import nn
from torchvision import transforms
from torchvision.models import mobilenet_v3_small, MobileNet_V3_Small_Weights
from train_image_classifier import TinyCNN
ap = argparse.ArgumentParser()
ap.add_argument("run"); ap.add_argument("image")
ap.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
a = ap.parse_args(); root = Path(a.run)
if a.device == "cuda" and not torch.cuda.is_available():
    ap.error("CUDA unavailable")
metadata = json.loads((root / "metrics.json").read_text())
classes = metadata["class_to_idx"]; backbone = metadata["config"]["backbone"]
if backbone == "tiny":
    model = TinyCNN(len(classes))
    preprocess = transforms.Compose([transforms.Resize((96,96)), transforms.ToTensor()])
else:
    # Architecture only; the complete trained checkpoint supplies all weights.
    model = mobilenet_v3_small(weights=None)
    model.classifier[-1] = nn.Linear(model.classifier[-1].in_features, len(classes))
    preprocess = MobileNet_V3_Small_Weights.IMAGENET1K_V1.transforms()
model.load_state_dict(torch.load(root / "best.pt", map_location="cpu", weights_only=True))
model.to(a.device).eval()
x = preprocess(Image.open(a.image).convert("RGB")).unsqueeze(0).to(a.device)
with torch.inference_mode():
    probabilities = model(x).float().softmax(dim=1)[0].cpu().tolist()
result = {name: probabilities[index] for name, index in classes.items()}
print(json.dumps({"class_probabilities": result, "predicted_class": max(result, key=result.get)}, indent=2))
