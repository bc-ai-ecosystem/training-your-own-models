# Tiny supervised ML examples

Run commands from this directory. All data generators are original synthetic educational fixtures. Use separate output directories when comparing experiments.

## Environment

CPU-tested: Python 3.12.14, NumPy 2.3.5, scikit-learn 1.8.0, SciPy 1.17.0, joblib 1.5.3, Pillow 12.3.0. `requirements-cpu.txt` records these dependencies. These were already present in the author environment; no packages were installed as part of testing.

Neural API target: torch 2.8.0, torchvision 0.23.0. Choose the official torch wheel appropriate for your device/driver. PyTorch and torchvision were absent in authoring, so neural training and inference are syntax-checked only, not CPU/GPU executed. Do not interpret the source as a tested dependency lock or a 24 GB performance guarantee.

## CPU projects

```bash
python train_tabular.py --task classification --out runs/classification
python predict_tabular.py runs/classification/model.joblib --values 72 3.5 .9 36
python train_tabular.py --task regression --out runs/regression
python predict_tabular.py runs/regression/model.joblib --values 72 3.5 .9 36
```

The trained artifact is a trusted joblib bundle. Never load unknown pickle/joblib files. Group splits, selected thresholds, metrics, predictions, and package versions are saved beside it.

## Image classification

Use owned/licensed images split by physical object or collection session into `parts/{train,val,test}/{class_name}/...`. Every split must have the same class directories.

```bash
python train_image_classifier.py --data parts --backbone tiny --out runs/parts-tiny
python predict_image_classifier.py runs/parts-tiny new_part.jpg --device cpu
python predict_image_classifier.py runs/parts-tiny new_part.jpg --device cuda
```

`--backbone mobilenet` downloads pretrained ImageNet weights; review weight and data terms first. Inference loads the complete saved model without a new weight download. The feature extractor stays frozen in the head-only baseline.

## Segmentation

```bash
python make_shapes.py --out data/shapes --train 256 --val 64 --test 64
python mask_metrics.py
python train_segmenter.py --data data/shapes --out runs/segmenter --device cpu
# CUDA training alternative: --device cuda --amp
python predict_segmenter.py runs/segmenter/best.pt new_image.png --device cpu
# CUDA inference alternative: --device cuda
```

Optional `contours.py` uses OpenCV's classic findContours/approxPolyDP API and retains hole hierarchy. It needs a separately installed compatible OpenCV package. The author did not install or execute OpenCV. Do not combine arbitrary dependency pins without checking their NumPy requirements.

```bash
python contours.py prediction/mask.png --epsilon-px 1 --out prediction/contours.json
```

All neural outputs are decoded in FP32 in the inference companions. The segmentation script performs no input resizing; its coordinates are original-image pixels. Large inputs therefore need a separate memory assessment.

## Actual authoring tests

See `../TEST_STATUS.md`. Saved artifacts under `test-artifacts/` are from synthetic CPU checks only. They are not pretrained real-world models.
