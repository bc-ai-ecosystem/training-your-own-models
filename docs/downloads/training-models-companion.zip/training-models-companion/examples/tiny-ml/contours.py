"""Optional OpenCV 4.11.0.86 API-targeted recipe. Syntax-checked only, OpenCV not required by training.
Input must be the binary prediction PNG, not a probability map or a box.
"""
import argparse
import json
from pathlib import Path
import cv2
ap = argparse.ArgumentParser()
ap.add_argument("mask")
ap.add_argument("--out", default="contours.json")
ap.add_argument("--epsilon-px", type=float, default=1.)
a = ap.parse_args()
if a.epsilon_px < 0:
    ap.error("epsilon must be nonnegative")
m = cv2.imread(a.mask, cv2.IMREAD_GRAYSCALE)
if m is None:
    raise FileNotFoundError(a.mask)
_, m = cv2.threshold(m, 127, 255, cv2.THRESH_BINARY)
contours, hierarchy = cv2.findContours(m, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
items = []
for i, contour in enumerate(contours):
    poly = cv2.approxPolyDP(contour, a.epsilon_px, True)
    items.append({"xy": poly[:, 0].tolist(), "hierarchy_next_prev_child_parent": hierarchy[0, i].tolist()})
Path(a.out).write_text(json.dumps({"coordinate_system": "original mask pixels, x right, y down",
                                  "epsilon_pixels": a.epsilon_px, "contours": items}, indent=2))
