"""Load only a trusted model.joblib; pickle-derived formats can execute code."""
import argparse
import json
import joblib
import numpy as np
ap = argparse.ArgumentParser()
ap.add_argument("model")
ap.add_argument("--values", type=float, nargs=4, required=True, metavar=("TEMP", "VIBRATION", "LOAD", "AGE"))
a = ap.parse_args()
bundle = joblib.load(a.model)
x = np.asarray([a.values])
if bundle["task"] == "classification":
    p = float(bundle["model"].predict_proba(x)[0, 1])
    result = {"fault_probability": p, "threshold": bundle["threshold"], "alert": p >= bundle["threshold"]}
else:
    result = {"synthetic_remaining_hours": float(bundle["model"].predict(x)[0])}
print(json.dumps(result, indent=2))
