"""Synthetic grouped tabular classification/regression, scikit-learn 1.8.0.
Run: python train_tabular.py --task classification --out runs/classification
No external data, network, or GPU required. Load only your own joblib artifacts.
"""
import argparse
import csv
import json
import platform
from pathlib import Path
import joblib
import numpy as np
import sklearn
from sklearn.calibration import CalibratedClassifierCV, calibration_curve
from sklearn.dummy import DummyClassifier, DummyRegressor
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.frozen import FrozenEstimator
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import (average_precision_score, balanced_accuracy_score, brier_score_loss,
    confusion_matrix, f1_score, log_loss, mean_absolute_error, mean_squared_error,
    precision_score, r2_score, recall_score, roc_auc_score)
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

FEATURES = ["temperature_c", "vibration_mm_s", "load_fraction", "age_months"]


def generate(seed=42, machines=400, readings=5):
    rng = np.random.default_rng(seed)
    group = np.repeat(np.arange(machines), readings)
    wear = rng.normal(size=machines)[group]
    temp = 50 + 9 * rng.normal(size=len(group)) + 2 * wear
    vibration = np.exp(.6 + .45 * rng.normal(size=len(group)) + .25 * wear)
    load = rng.uniform(.1, 1., len(group))
    age = np.clip(24 + 14 * wear + rng.normal(0, 4, len(group)), 0, 80)
    X = np.column_stack([temp, vibration, load, age])
    risk_logit = -2.3 + .055 * (temp - 50) + .85 * (vibration - 2) + 1.6 * (load > .8) + .025 * age
    fault = rng.binomial(1, 1 / (1 + np.exp(-risk_logit)))
    # Deliberately synthetic outcome. Not a model of physical remaining life.
    hours = np.maximum(0, 300 - 2.5 * age - 20 * vibration - 30 * load + rng.normal(0, 20, len(group)))
    X[rng.random(X.shape) < .03] = np.nan
    order = rng.permutation(machines)
    sets = dict(zip(["train", "calibration", "validation", "test"],
                    np.split(order, [int(.60 * machines), int(.75 * machines), int(.85 * machines)])))
    splits = {name: np.flatnonzero(np.isin(group, ids)) for name, ids in sets.items()}
    for a, ia in sets.items():
        for b, ib in sets.items():
            if a != b:
                assert not set(ia) & set(ib)
    return X, fault, hours, group, splits


def cls_metrics(y, p, threshold):
    pred = p >= threshold
    frac, mean = calibration_curve(y, p, n_bins=8, strategy="quantile")
    return {"average_precision": float(average_precision_score(y, p)),
            "roc_auc": float(roc_auc_score(y, p)), "log_loss": float(log_loss(y, p)),
            "brier": float(brier_score_loss(y, p)), "balanced_accuracy": float(balanced_accuracy_score(y, pred)),
            "precision": float(precision_score(y, pred, zero_division=0)),
            "recall": float(recall_score(y, pred, zero_division=0)),
            "f1": float(f1_score(y, pred, zero_division=0)),
            "confusion_matrix_rows_true_columns_pred": confusion_matrix(y, pred).tolist(),
            "calibration_mean_probability": mean.tolist(), "calibration_observed_fraction": frac.tolist()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", choices=["classification", "regression"], default="classification")
    ap.add_argument("--out", default="runs/tabular")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--machines", type=int, default=400)
    args = ap.parse_args()
    if args.machines < 100:
        ap.error("Use at least 100 machines so holdouts are not trivially small")
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    X, yc, yr, groups, split = generate(args.seed, args.machines)
    y = yc if args.task == "classification" else yr
    tr, va, ca, te = [split[k] for k in ["train", "validation", "calibration", "test"]]
    impute_scale = lambda estimator: make_pipeline(SimpleImputer(strategy="median", add_indicator=True), StandardScaler(), estimator)
    if args.task == "classification":
        candidates = {"constant": impute_scale(DummyClassifier(strategy="prior")),
                      "logistic": impute_scale(LogisticRegression(C=1., max_iter=1000)),
                      "boosting": HistGradientBoostingClassifier(learning_rate=.06, max_iter=120, max_leaf_nodes=7,
                                      min_samples_leaf=25, l2_regularization=1., early_stopping=False, random_state=args.seed)}
    else:
        candidates = {"constant": impute_scale(DummyRegressor(strategy="mean")),
                      "ridge": impute_scale(Ridge(alpha=1.)),
                      "boosting": HistGradientBoostingRegressor(learning_rate=.06, max_iter=120, max_leaf_nodes=7,
                                      min_samples_leaf=25, l2_regularization=1., early_stopping=False, random_state=args.seed)}
    scores = {}
    for name, model in candidates.items():
        model.fit(X[tr], y[tr])
        scores[name] = float(average_precision_score(y[va], model.predict_proba(X[va])[:, 1]) if args.task == "classification"
                             else -mean_absolute_error(y[va], model.predict(X[va])))
    winner = max(scores, key=scores.get)
    model = candidates[winner]
    threshold = None
    if args.task == "classification":
        model = CalibratedClassifierCV(FrozenEstimator(model), method="sigmoid")
        model.fit(X[ca], y[ca])
        vp = model.predict_proba(X[va])[:, 1]
        thresholds = np.linspace(.05, .95, 91)
        threshold = float(max(thresholds, key=lambda t: f1_score(y[va], vp >= t, zero_division=0)))
        pred = model.predict_proba(X[te])[:, 1]
        metrics = cls_metrics(y[te], pred, threshold)
    else:
        pred = model.predict(X[te])
        metrics = {"mae_hours": float(mean_absolute_error(y[te], pred)),
                   "rmse_hours": float(np.sqrt(mean_squared_error(y[te], pred))),
                   "r2": float(r2_score(y[te], pred))}
    artifact = {"model": model, "task": args.task, "features": FEATURES, "threshold": threshold}
    joblib.dump(artifact, out / "model.joblib")
    # Reload equivalence, using only the trusted file this process just created.
    reloaded = joblib.load(out / "model.joblib")["model"]
    rp = reloaded.predict_proba(X[te])[:, 1] if args.task == "classification" else reloaded.predict(X[te])
    np.testing.assert_allclose(pred, rp)
    report = {"synthetic_only": True, "task": args.task, "seed": args.seed, "winner": winner,
              "validation_selection_scores": scores, "selection_metric": "AP" if args.task == "classification" else "negative_MAE",
              "threshold": threshold, "test_metrics": metrics, "split_rows": {k: len(v) for k, v in split.items()},
              "class_prevalence_by_split": {k: float(yc[v].mean()) for k, v in split.items()},
              "python": platform.python_version(), "numpy": np.__version__, "sklearn": sklearn.__version__,
              "feature_order": FEATURES, "reload_prediction_equivalence": True}
    (out / "metrics.json").write_text(json.dumps(report, indent=2))
    (out / "split_machine_ids.json").write_text(json.dumps({k: sorted(set(groups[v].tolist())) for k, v in split.items()}, indent=2))
    with (out / "test_predictions.csv").open("w") as f:
        w = csv.writer(f); w.writerow(["machine_id", *FEATURES, "target", "prediction"])
        w.writerows([[int(groups[i]), *X[i].tolist(), float(y[i]), float(p)] for i, p in zip(te, pred)])
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
