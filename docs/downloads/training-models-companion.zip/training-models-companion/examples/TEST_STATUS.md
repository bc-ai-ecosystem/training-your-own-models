# Verification status of tiny-ML and embedding examples

Verified 2026-10-02 in the authoring CPU environment. No packages installed, no pretrained weights downloaded, no GPU training run, and no phone deployment tested.

## Executed successfully

- `tiny-ml/train_tabular.py --task classification` with default seed/machine count: selected boosting; held-out AP 0.69313780696, ROC-AUC 0.78822751323, F1 0.63333333333, threshold 0.31
- `tiny-ml/train_tabular.py --task regression`: selected boosting; held-out MAE 15.76655343, RMSE 20.10116158, R-squared 0.87142786407
- Both training scripts reload their own saved trusted joblib models and assert prediction equivalence
- `tiny-ml/predict_tabular.py` on `[72, 3.5, 0.9, 36]`: classification probability 0.88497037326 and alert true
- `tiny-ml/make_shapes.py --train 8 --val 4 --test 4`: generated readable RGB PNGs and binary masks; representative pixels inspected
- `tiny-ml/mask_metrics.py`: exact match, disjoint match, empty conventions, and boundary tolerance checks passed
- Additional boundary test: 96×96 square shifted one pixel horizontally gave IoU 0.97938144330 and exact-pixel boundary F1 0.5
- `embeddings/make_retrieval_data.py`: wrote 60 documents, 108 training pairs, and 180 queries with independent product split groups
- `embeddings/lexical_baseline.py`: validation and test Recall@5 1.0, MRR@5 0.82129629630, nDCG@5 0.86552160403. The identical numbers reflect shared synthetic templates, not a generalization claim
- All Python sources compiled successfully with `compileall` after final edits
- Additional independent retrieval-metric and data-integrity assertions are recorded in `verification.json`

## Not executed

PyTorch, torchvision, Sentence Transformers, and Transformers were absent. Therefore CNN training/inference, segmentation training/inference, embedding adaptation/search, GPU memory estimates, and GPU numerical parity were not tested. OpenCV contour extraction was not executed. Syntax checks do not establish runtime API or dependency compatibility. Listed neural versions are a deliberately checked API target, not an empirically resolved lockfile.

## Environment

Python 3.12.14; NumPy 2.3.5; scikit-learn 1.8.0; SciPy 1.17.0; joblib 1.5.3; Pillow 12.3.0. CPU core-count introspection emitted a fallback warning during one inference command; prediction succeeded. Training commands used two OpenMP/BLAS threads to avoid unnecessary parallelism.
