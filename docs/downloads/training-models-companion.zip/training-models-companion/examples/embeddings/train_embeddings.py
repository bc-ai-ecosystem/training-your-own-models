"""Qwen3-Embedding-0.6B full adaptation; source-reviewed, NOT GPU/runtime tested.
API target: torch 2.8.0, sentence-transformers 5.1.1, transformers 4.57.1.
FP32 model/optimizer state; optional CUDA BF16 autocast; short batches by default.
"""
import argparse
import gc
import json
import math
import random
from pathlib import Path
import numpy as np
import torch
from sentence_transformers import SentenceTransformer, losses
from retrieval_common import read_jsonl, retrieval_metrics
from embedding_contract import (MODEL_ID, MODEL_REVISION, DEFAULT_INSTRUCTION,
                                format_query, model_fingerprint, sha256_file)


def configure_model(model, max_length):
    model.max_seq_length = max_length
    model.tokenizer.padding_side = "left"
    model.default_prompt_name = None  # Query formatting is explicit in every path.
    backbone = model[0].auto_model
    backbone.config.use_cache = False
    if not getattr(model[1], "pooling_mode_lasttoken", False):
        raise ValueError("Expected the verified Qwen last-token pooling configuration")
    if model.get_sentence_embedding_dimension() != 1024:
        raise ValueError("Expected 1024-dimensional Qwen embedding output")
    return backbone


@torch.no_grad()
def evaluate(model, corpus, queries, max_batch, instruction):
    model.eval()
    # prompt="" prevents implicit model prompts; queries already contain one.
    docs = model.encode([d["text"] for d in corpus], batch_size=max_batch, prompt="",
                        normalize_embeddings=True, convert_to_numpy=True, show_progress_bar=False)
    qs = model.encode([format_query(q["text"], instruction) for q in queries],
                      batch_size=max_batch, prompt="", normalize_embeddings=True,
                      convert_to_numpy=True, show_progress_bar=False)
    docs, qs = np.asarray(docs, dtype=np.float32), np.asarray(qs, dtype=np.float32)
    return (*retrieval_metrics(qs @ docs.T, corpus, queries), docs)


def batches_one_positive_per_doc(rows, batch_size, rng):
    by_doc = {}
    for row in rows:
        by_doc.setdefault(row["doc_id"], []).append(row)
    chosen = [rng.choice(group) for group in by_doc.values()]
    rng.shuffle(chosen)
    for start in range(0, len(chosen), batch_size):
        batch = chosen[start:start+batch_size]
        if len(batch) >= 2:  # Singleton contrastive batches contain no negatives.
            yield batch


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/retrieval")
    ap.add_argument("--out", default="runs/qwen3-embedding")
    ap.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--batch-size", type=int, default=2)
    ap.add_argument("--max-length", type=int, default=128)
    ap.add_argument("--lr", type=float, default=1e-5)
    ap.add_argument("--weight-decay", type=float, default=.01)
    ap.add_argument("--scale", type=float, default=20.)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--instruction", default=DEFAULT_INSTRUCTION)
    ap.add_argument("--amp-bf16", action="store_true", help="CUDA BF16 autocast; FP32 master parameters")
    ap.add_argument("--max-steps", type=int, default=0, help="0=no cap; 1=one-update smoke experiment")
    ap.add_argument("--eval-only", action="store_true", help="Save/index the unmodified model; no optimizer")
    a = ap.parse_args()
    if a.batch_size < 2 or a.epochs < 1 or not 32 <= a.max_length <= 32768:
        ap.error("batch-size >=2, epochs >=1, max-length between 32 and 32768 required")
    if not all(math.isfinite(x) for x in [a.lr, a.weight_decay, a.scale]) or a.lr <= 0 or a.weight_decay < 0 or a.scale <= 0 or a.max_steps < 0:
        ap.error("lr/scale must be positive; weight-decay/max-steps nonnegative")
    if not a.instruction.strip():
        ap.error("instruction must be nonempty")
    if a.device == "cuda" and not torch.cuda.is_available():
        ap.error("CUDA unavailable; verify your driver and selected torch wheel")
    if a.amp_bf16 and (a.device != "cuda" or not torch.cuda.is_bf16_supported()):
        ap.error("--amp-bf16 requires a BF16-capable CUDA GPU; otherwise omit it")
    random.seed(a.seed); np.random.seed(a.seed); torch.manual_seed(a.seed)
    root, out = Path(a.data), Path(a.out)
    if out.exists() and any(out.iterdir()):
        ap.error("Use a new empty --out directory so prior model/index files cannot mix")
    out.mkdir(parents=True, exist_ok=True)
    corpus, queries, rows = [read_jsonl(root / f"{n}.jsonl") for n in ["corpus", "queries", "train_pairs"]]
    if len({d["doc_id"] for d in corpus}) != len(corpus):
        raise ValueError("Corpus doc_id values must be unique")
    group_splits = {}
    for d in corpus:
        group_splits.setdefault(d["group"], set()).add(d["split"])
    if any(len(splits) != 1 for splits in group_splits.values()):
        raise ValueError("A corpus group occurs in more than one split")
    doc_splits = {d["doc_id"]: d["split"] for d in corpus}
    query_splits = {}
    for q in queries:
        if not q["relevant_doc_ids"] or any(doc_splits.get(doc_id) != q["split"] for doc_id in q["relevant_doc_ids"]):
            raise ValueError("Each query needs known positives in its assigned document split")
        query_splits.setdefault(q["text"], set()).add(q["split"])
    if any(len(splits) != 1 for splits in query_splits.values()):
        raise ValueError("Identical query text occurs across splits")
    train_docs = {d["doc_id"]: d["text"] for d in corpus if d["split"] == "train"}
    if not all(r["doc_id"] in train_docs and r["positive"] == train_docs[r["doc_id"]] for r in rows):
        raise ValueError("Training pair must match a training corpus document")
    if len({r["doc_id"] for r in rows}) < 2:
        raise ValueError("Need at least two distinct positive documents")
    if len({r["positive"] for r in rows}) != len({r["doc_id"] for r in rows}):
        raise ValueError("Duplicate positives require regrouping")
    # No chat template, generation head, device_map='auto', or remote executable code.
    model = SentenceTransformer(MODEL_ID, revision=MODEL_REVISION, device=a.device,
                               trust_remote_code=False,
                               model_kwargs={"torch_dtype": torch.float32, "attn_implementation": "sdpa"},
                               tokenizer_kwargs={"padding_side": "left"})
    backbone = configure_model(model, a.max_length)
    parameter_count = sum(p.numel() for p in model.parameters())
    if parameter_count > 1_000_000_000:
        raise ValueError("This full-fine-tuning lab is bounded to <=1B parameters")
    print(json.dumps({"model": MODEL_ID, "revision": MODEL_REVISION, "actual_parameter_count": parameter_count}))
    val = [q for q in queries if q["split"] == "val"]
    before, _, _ = evaluate(model, corpus, val, a.batch_size, a.instruction)
    model.save_pretrained(str(out / "best"))
    best, selected_epoch = before["mrr@5"], 0
    history, global_step = [], 0
    if not a.eval_only:
        # Non-reentrant checkpointing recomputes activations during backward.
        backbone.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
        loss_fn = losses.MultipleNegativesRankingLoss(model, scale=a.scale)
        optimizer = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=a.weight_decay, foreach=False)
        rng = random.Random(a.seed)
        for epoch in range(a.epochs):
            model.train(); total = 0.; steps = 0
            for batch in batches_one_positive_per_doc(rows, a.batch_size, rng):
                positive = [row["positive"] for row in batch]
                anchor = [format_query(row["query"], a.instruction) for row in batch]
                if len(set(positive)) != len(positive) or len(set(anchor)) != len(anchor):
                    raise ValueError("Duplicate in contrastive batch")
                features = [{k: v.to(a.device) for k, v in model.tokenize(texts).items()} for texts in [anchor, positive]]
                optimizer.zero_grad(set_to_none=True)
                with torch.autocast(device_type=a.device, dtype=torch.bfloat16, enabled=a.amp_bf16):
                    loss = loss_fn(features, torch.empty(0, device=a.device))
                if not torch.isfinite(loss):
                    raise RuntimeError("Non-finite contrastive loss")
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
                optimizer.step(); total += float(loss.detach()); steps += 1; global_step += 1
                if a.max_steps and global_step >= a.max_steps:
                    break
            if not steps:
                raise ValueError("No usable contrastive batch")
            metrics, _, _ = evaluate(model, corpus, val, a.batch_size, a.instruction)
            history.append({"epoch": epoch+1, "loss": total/steps, "steps": steps, **metrics})
            print(json.dumps(history[-1]))
            if metrics["mrr@5"] > best:
                best, selected_epoch = metrics["mrr@5"], epoch+1
                model.save_pretrained(str(out / "best"))
            if a.max_steps and global_step >= a.max_steps:
                break
        del optimizer, loss_fn, features, loss
    # Release the optimizer and original model BEFORE loading the selected model.
    del backbone, model
    gc.collect()
    if a.device == "cuda":
        torch.cuda.empty_cache()
    selected = SentenceTransformer(str(out / "best"), device=a.device, trust_remote_code=False,
                                   model_kwargs={"torch_dtype": torch.float32, "attn_implementation": "sdpa"},
                                   tokenizer_kwargs={"padding_side": "left"})
    configure_model(selected, a.max_length)
    final, rankings, doc_vectors = evaluate(selected, corpus, val, a.batch_size, a.instruction)
    np.save(out / "corpus_embeddings.npy", doc_vectors)
    (out / "corpus_ids.json").write_text(json.dumps([d["doc_id"] for d in corpus]))
    (out / "validation_rankings.json").write_text(json.dumps(rankings, indent=2))
    contract = {"model_id": MODEL_ID, "source_revision": MODEL_REVISION, "instruction": a.instruction,
                "query_format": "Instruct: {instruction}\\nQuery:{query}", "document_prompt": "",
                "pooling": "last_nonpadding_token", "padding_side": "left", "max_length": a.max_length,
                "dimension": int(doc_vectors.shape[1]), "normalization": "L2", "similarity": "dot",
                "model_files_sha256": model_fingerprint(out / "best"),
                "corpus_sha256": sha256_file(root / "corpus.jsonl"),
                "vectors_sha256": sha256_file(out / "corpus_embeddings.npy"),
                "ids_sha256": sha256_file(out / "corpus_ids.json")}
    (out / "index_contract.json").write_text(json.dumps(contract, indent=2))
    report = {"config": vars(a), "model_id": MODEL_ID, "source_revision": MODEL_REVISION,
              "actual_parameter_count": parameter_count, "selected_epoch": selected_epoch,
              "validation_before": before, "history": history, "selected_validation": final,
              "data_sha256": {p.name: sha256_file(p) for p in root.glob("*.jsonl")},
              "torch": torch.__version__, "master_dtype": "float32",
              "peak_cuda_allocated_bytes": torch.cuda.max_memory_allocated() if a.device == "cuda" else None,
              "peak_cuda_reserved_bytes": torch.cuda.max_memory_reserved() if a.device == "cuda" else None}
    (out / "metrics.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(final, indent=2))

if __name__ == "__main__":
    main()
