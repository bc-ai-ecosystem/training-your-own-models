"""Search with the saved Qwen model, exact query instruction and matching index.
CPU/GPU FP32 inference; source-reviewed/syntax-checked, not neural runtime-tested.
"""
import argparse
import json
from pathlib import Path
import numpy as np
import torch
from sentence_transformers import SentenceTransformer
from embedding_contract import format_query, model_fingerprint, sha256_file


def load_bundle(root, device):
    root = Path(root)
    contract = json.loads((root / "index_contract.json").read_text())
    if model_fingerprint(root / "best") != contract["model_files_sha256"]:
        raise ValueError("Model/tokenizer/config changed: rebuild the index")
    if sha256_file(root / "corpus_embeddings.npy") != contract["vectors_sha256"] or sha256_file(root / "corpus_ids.json") != contract["ids_sha256"]:
        raise ValueError("Index files changed or were mixed across runs")
    model = SentenceTransformer(str(root / "best"), device=device, trust_remote_code=False,
                               model_kwargs={"torch_dtype": torch.float32, "attn_implementation": "sdpa"},
                               tokenizer_kwargs={"padding_side": "left"})
    model.max_seq_length = contract["max_length"]
    model.default_prompt_name = None
    model[0].auto_model.config.use_cache = False
    model.eval()
    ids = json.loads((root / "corpus_ids.json").read_text())
    vectors = np.load(root / "corpus_embeddings.npy", allow_pickle=False)
    if vectors.shape != (len(ids), contract["dimension"]):
        raise ValueError("Index shape does not match its contract")
    return model, vectors, ids, contract


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run"); ap.add_argument("query")
    ap.add_argument("--k", type=int, default=5)
    ap.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    a = ap.parse_args(); root = Path(a.run)
    if a.k < 1 or not a.query.strip():
        ap.error("k must be positive and query nonempty")
    if a.device == "cuda" and not torch.cuda.is_available():
        ap.error("CUDA unavailable")
    model, vectors, ids, contract = load_bundle(root, a.device)
    query = model.encode([format_query(a.query, contract["instruction"])], prompt="",
                         normalize_embeddings=True, convert_to_numpy=True)[0].astype(np.float32)
    scores = vectors @ query
    for i in np.argsort(-scores, kind="stable")[:a.k]:
        print(json.dumps({"doc_id": ids[i], "cosine_similarity": float(scores[i])}))

if __name__ == "__main__":
    main()
