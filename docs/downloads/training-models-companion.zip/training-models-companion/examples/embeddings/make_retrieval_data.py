"""Original fictional support catalog: a wiring fixture, not a retrieval benchmark."""
import argparse
import json
from pathlib import Path

PRODUCTS = ["Aster", "Birch", "Cedar", "Dahlia", "Elm", "Fir", "Ginkgo", "Hazel", "Iris", "Juniper"]
INTENTS = [
    ("password", "change the password", "update my secret login phrase", "Open Account then Security and choose Change password."),
    ("invoice", "download an invoice", "get a receipt for payment", "Open Billing then Invoice history and select Download PDF."),
    ("cancel", "cancel a subscription", "stop future renewals", "Open Billing then Subscription and choose Cancel renewal."),
    ("export", "export my data", "take a copy of my records", "Open Workspace then Data and choose Export archive."),
    ("invite", "invite a teammate", "give a colleague workspace access", "Open Members, select Invite, and enter the colleague's work address."),
    ("dark", "enable dark mode", "use the darker display theme", "Open Preferences then Appearance and select Dark."),
]

def build():
    corpus, queries, pairs = [], [], []
    for i, product in enumerate(PRODUCTS):
        split = "train" if i < 6 else "val" if i < 8 else "test"
        for intent, exact, alternate, answer in INTENTS:
            doc_id = f"{product.lower()}-{intent}"
            corpus.append({"doc_id": doc_id, "text": f"{product}: How to {exact}. {answer}", "group": product, "split": split})
            variants = [f"How do I {exact} in {product}?", f"In {product}, I need to {alternate}.",
                        f"Please help me {exact} for my {product} account."]
            for j, query in enumerate(variants):
                queries.append({"query_id": f"{doc_id}-q{j}", "text": query, "relevant_doc_ids": [doc_id], "split": split})
                if split == "train":
                    pairs.append({"query": query, "positive": corpus[-1]["text"], "doc_id": doc_id, "group": product})
    return corpus, queries, pairs


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default="data/retrieval"); a = ap.parse_args()
    root = Path(a.out)
    if root.exists() and any(root.iterdir()):
        ap.error("output must be empty")
    root.mkdir(parents=True, exist_ok=True)
    for name, rows in zip(["corpus", "queries", "train_pairs"], build()):
        (root / f"{name}.jsonl").write_text("".join(json.dumps(x) + "\n" for x in rows))
    (root / "README.txt").write_text("Fictional original examples. Generated templates shared across splits; not evidence of real-world generalization. Product groups do not overlap. Corpus is an inference-time database containing all documents, including held-out ones.\n")
    print(root)

if __name__ == "__main__":
    main()
