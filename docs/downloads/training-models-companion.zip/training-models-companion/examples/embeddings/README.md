# Current compact embeddings: Qwen3-Embedding-0.6B

The lexical baseline runs first; the primary neural project adapts Qwen3-Embedding-0.6B, not an older MiniLM recipe. Fixed official revision: `97b0c614be4d77ee51c0cef4e5f07c00f9eb65b3`. Model card: https://huggingface.co/Qwen/Qwen3-Embedding-0.6B . It is public and marked Apache-2.0 at source review. Review applicable weight/data rights before use.

## Fresh terminal: CPU baseline first

Linux/macOS shell, with Python 3.12 installed. Start at the downloaded book directory, then:

```bash
cd examples/embeddings
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements-cpu.txt
python -c "import numpy, sklearn; print(numpy.__version__, sklearn.__version__)"
python make_retrieval_data.py --out data/retrieval
python lexical_baseline.py --data data/retrieval --out runs/lexical
```

On Windows PowerShell, use `py -3.12 -m venv .venv`, then `.venv\Scripts\Activate.ps1`; the remaining `python -m pip` and Python commands are the same. Follow local execution policy rather than bypassing security controls. If a data/output folder already exists, use a new name; do not mix artifacts across experiments.

The fictional fixture contains 60 corpus documents, 108 training pairs from 36 unique positive documents, and 36 validation plus 36 test queries. Product groups are disjoint but wording templates are shared. It is a wiring exercise, not evidence of real-world retrieval performance.

## Install the neural requirements BEFORE importing them

Choose exactly one PyTorch installation route in the activated environment. Official matching wheel instructions: https://pytorch.org/get-started/previous-versions/#v280 . These are pinned reproducible API versions, not a claim that they are the newest releases.

Linux/Windows NVIDIA route, for a driver/GPU compatible with the official CUDA 12.8 wheel:

```bash
python -m pip install torch==2.8.0 --index-url https://download.pytorch.org/whl/cu128
python -m pip install -r requirements-neural.txt
python -m pip check
python -c "import torch, transformers, sentence_transformers; print(torch.__version__, transformers.__version__, sentence_transformers.__version__); print('CUDA:', torch.cuda.is_available()); print('BF16:', torch.cuda.is_available() and torch.cuda.is_bf16_supported())"
```

CPU-only Linux/Windows alternative: replace the first install command with:

```bash
python -m pip install torch==2.8.0 --index-url https://download.pytorch.org/whl/cpu
```

macOS CPU alternative: `python -m pip install torch==2.8.0`, then the same requirements, pip-check, and import-check commands. This project does not implement an MPS route. A CPU wheel does not gain CUDA support by changing `--device`. If a new GPU is unsupported by the pinned wheel, use the official compatible environment and revalidate, rather than forcing this wheel.

No fresh install or neural execution was performed during authoring. CPU baseline/contract tests used existing packages. Neural code and pinned APIs were source-reviewed and syntax-checked only; installing successfully is not a training result. The first model load downloads approximately 1.2 GB of weights plus tokenizer/configuration; FP32 trained checkpoints are larger. Allow generous disk/RAM headroom.

## One-update smoke run, then adaptation

For a BF16-capable 24 GB NVIDIA GPU:

```bash
python train_embeddings.py --data data/retrieval --out runs/qwen3-smoke \
  --device cuda --amp-bf16 --batch-size 2 --max-length 128 \
  --epochs 1 --max-steps 1
python train_embeddings.py --data data/retrieval --out runs/qwen3-adapted \
  --device cuda --amp-bf16 --batch-size 2 --max-length 128 \
  --epochs 3 --lr 0.00001 --weight-decay 0.01 --scale 20
```

The CPU training path is executable too, but full 0.6B backpropagation is slow and needs substantial RAM. For a CPU smoke experiment replace `--device cuda --amp-bf16` with `--device cpu`. CPU users can first save and index the frozen baseline without optimizer state:

```bash
python train_embeddings.py --data data/retrieval --out runs/qwen3-baseline \
  --device cpu --eval-only --batch-size 2 --max-length 128
```

No 24 GB fit/throughput is claimed as measured. FP32 parameters, gradients and two Adam moments alone are approximately 8.88 GiB for the config-derived 595,776,512 parameters, before activations/workspaces/allocator overhead. The script reports actual loaded parameter count and peak CUDA allocated/reserved bytes. It uses short batches, SDPA, gradient checkpointing, no KV cache, and `foreach=False`. BF16 autocast affects selected computations, not the FP32 master/optimizer storage. Reduce input/batch or use a separately validated parameter-efficient method if the representative smoke run does not fit; batch must stay at least two for this in-batch-negative objective.

## CPU and GPU inference

```bash
python search.py runs/qwen3-adapted \
  "In Iris, I need to stop future renewals." --device cpu --k 5
python search.py runs/qwen3-adapted \
  "In Iris, I need to stop future renewals." --device cuda --k 5
```

For the frozen run, substitute `runs/qwen3-baseline`. Both inference paths load FP32 and use the same saved tokenizer, last-nonpadding-token pooling, left padding, maximum sequence length, query instruction, and L2 normalization. The exact NumPy index remains on CPU. Scores are cosine similarities, not probabilities. Search checks SHA-256 identities for model/config/tokenizer and index files; this adds startup I/O but prevents silently mixing versions.

The shared query format is `Instruct: {task description}\nQuery:{query}`. Documents receive no instruction. The tokenizer's native EOS behavior is retained; no chat template or manual duplicate EOS is added. Model-generated default prompts are disabled in the explicit paths so the instruction appears exactly once. The selected 1024-dimensional vectors are not truncated.

The unmodified model remains eligible if training does not improve validation MRR@5. `selected_epoch=0` means it won. Adaptation updates all encoder parameters; this is fine-tuning, not scratch pretraining or a reproduction of Qwen's original training. Three default epochs give 54 updates on this tiny fixture. No adaptation gain is claimed.

Output: `best/`, `index_contract.json`, `corpus_embeddings.npy`, `corpus_ids.json`, `validation_rankings.json`, `metrics.json`. Any change to weights, tokenizer, instruction, pooling, normalization, document segmentation, or corpus requires a corresponding new index and evaluation.

## Explicit final test, after tuning

Baseline, smoke, adaptation, and the default lexical command evaluate validation only. Once every selection is fixed:

```bash
python evaluate_saved.py runs/qwen3-adapted --data data/retrieval --split test --device cuda --batch-size 2
python lexical_baseline.py --data data/retrieval --out runs/lexical-final --split test
```

Use `--device cpu` for CPU scoring or the baseline run directory if that is the selected system. `evaluate_saved.py` defaults to validation if `--split` is omitted. Do not use final test labels for further tuning.

This short trainer saves selected weights for inference, not optimizer state or resumable training position. Reloading `best/` is not resuming an interrupted experiment. The complete three-file JSONL schema and group/split contract are shown in the book chapter.
