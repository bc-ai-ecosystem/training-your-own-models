"""Evaluate one saved model/index. Use --split test only after all tuning is done."""
import argparse
import json
from pathlib import Path
import numpy as np
import torch
from search import load_bundle
from embedding_contract import format_query, sha256_file
from retrieval_common import read_jsonl, retrieval_metrics


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run")
    ap.add_argument("--data", default="data/retrieval")
    ap.add_argument("--split", choices=["val", "test"], default="val")
    ap.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    ap.add_argument("--batch-size", type=int, default=2)
    a = ap.parse_args(); root, data = Path(a.run), Path(a.data)
    if a.batch_size < 1:
        ap.error("batch-size must be positive")
    if a.device == "cuda" and not torch.cuda.is_available():
        ap.error("CUDA unavailable")
    model, vectors, ids, contract = load_bundle(root, a.device)
    if sha256_file(data / "corpus.jsonl") != contract["corpus_sha256"]:
        raise ValueError("Evaluation corpus differs from the indexed corpus")
    corpus = read_jsonl(data / "corpus.jsonl")
    if [d["doc_id"] for d in corpus] != ids:
        raise ValueError("Corpus row IDs differ from the index")
    queries = [q for q in read_jsonl(data / "queries.jsonl") if q["split"] == a.split]
    if not queries:
        raise ValueError("No queries in chosen split")
    encoded = model.encode([format_query(q["text"], contract["instruction"]) for q in queries],
                           prompt="", batch_size=a.batch_size, normalize_embeddings=True,
                           convert_to_numpy=True, show_progress_bar=False).astype(np.float32)
    metrics, rankings = retrieval_metrics(encoded @ vectors.T, corpus, queries)
    (root / f"{a.split}_metrics.json").write_text(json.dumps(metrics, indent=2))
    (root / f"{a.split}_rankings.json").write_text(json.dumps(rankings, indent=2))
    print(json.dumps({"split": a.split, **metrics}, indent=2))

if __name__ == "__main__":
    main()
