"""Load the first-model JSON and predict one two-number input."""
import argparse
import json
from pathlib import Path
from train import sigmoid

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("model", type=Path)
p.add_argument("x1", type=float)
p.add_argument("x2", type=float)
a = p.parse_args()
m = json.loads(a.model.read_text(encoding="utf-8"))
probability = sigmoid(m["weights"][0] * a.x1 + m["weights"][1] * a.x2 + m["bias"])
print(json.dumps({"probability": probability, "class": int(probability >= m["threshold"])}))
