"""Train a two-feature binary classifier using only Python's standard library.
Educational synthetic task. No downloads, GPU, or third-party dependencies.
Python 3.10+. Run: python train.py --steps 400 --output run
"""
import argparse
import json
import math
import random
from pathlib import Path


def sigmoid(z):
    if z >= 0:
        return 1.0 / (1.0 + math.exp(-z))
    e = math.exp(z)
    return e / (1.0 + e)


def make_data(seed, n):
    rng = random.Random(seed)
    rows = []
    for _ in range(n):
        x1 = rng.uniform(-1.0, 1.0)
        x2 = rng.uniform(-1.0, 1.0)
        # Label rule known only because this is an educational synthetic task.
        y = int(1.8 * x1 - 1.2 * x2 + 0.15 > 0)
        rows.append(([x1, x2], y))
    return rows


def metrics(rows, weights, bias):
    loss = 0.0
    correct = 0
    for x, y in rows:
        z = sum(w * v for w, v in zip(weights, x)) + bias
        # Stable binary cross entropy from a logit.
        loss += max(z, 0.0) - z * y + math.log1p(math.exp(-abs(z)))
        correct += int((sigmoid(z) >= 0.5) == bool(y))
    return {"loss": loss / len(rows), "accuracy": correct / len(rows)}


def train(rows, steps, lr):
    weights, bias = [0.0, 0.0], 0.0
    history = []
    for step in range(steps):
        gw, gb = [0.0, 0.0], 0.0
        for x, y in rows:
            p = sigmoid(sum(w * v for w, v in zip(weights, x)) + bias)
            error = p - y
            for j in range(2):
                gw[j] += error * x[j]
            gb += error
        for j in range(2):
            weights[j] -= lr * gw[j] / len(rows)
        bias -= lr * gb / len(rows)
        if (step + 1) % 50 == 0 or step + 1 == steps:
            history.append({"step": step + 1, **metrics(rows, weights, bias)})
    return weights, bias, history


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--steps", type=int, default=400)
    p.add_argument("--learning-rate", type=float, default=0.5)
    p.add_argument("--output", type=Path, default=Path("run"))
    args = p.parse_args()
    if args.steps < 1 or args.learning_rate <= 0:
        p.error("steps and learning-rate must be positive")
    if args.output.exists() and any(args.output.iterdir()):
        p.error("output directory is not empty; choose a new run directory")
    args.output.mkdir(parents=True, exist_ok=True)
    train_rows = make_data(101, 200)
    validation_rows = make_data(202, 100)
    test_rows = make_data(303, 200)
    before = metrics(validation_rows, [0.0, 0.0], 0.0)
    weights, bias, history = train(train_rows, args.steps, args.learning_rate)
    artifact = {"features": ["x1", "x2"], "weights": weights, "bias": bias,
                "threshold": 0.5, "task": "synthetic linear boundary",
                "steps": args.steps, "learning_rate": args.learning_rate,
                "data_seeds": {"train": 101, "validation": 202, "test": 303}}
    model_path = args.output / "model.json"
    model_path.write_text(json.dumps(artifact, indent=2) + "\n", encoding="utf-8")
    restored = json.loads(model_path.read_text(encoding="utf-8"))
    after = metrics(validation_rows, restored["weights"], restored["bias"])
    result = {"validation_before": before, "validation_after": after,
              "test_once_after_fixed_training": metrics(test_rows, weights, bias),
              "history": history, "model_path": str(model_path)}
    (args.output / "metrics.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    assert all(math.isfinite(v) for v in weights + [bias])
    assert after["loss"] < before["loss"], "loss did not improve"
    assert after == metrics(validation_rows, weights, bias), "reload mismatch"
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
