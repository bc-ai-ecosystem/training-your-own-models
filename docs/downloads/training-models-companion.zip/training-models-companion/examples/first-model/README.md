# Your first trained model

Python standard library only, Python 3.10+. From this directory:

```bash
python train.py --output run
python predict.py run/model.json 0.8 -0.4
```

The two-feature classifier learns three parameters from 200 synthetic training examples, checks separate validation examples, writes a JSON artifact, reloads it and evaluates a fixed final test set. The default executed result was validation loss 0.1342458695, validation accuracy 0.96, test accuracy 0.985. These are toy-data results only.

Use a new output directory for a new experiment. `--steps` controls full-batch updates and `--learning-rate` controls update scale. The saved feature order is x1 then x2. The standard-library implementation intentionally has no GPU backend. It is a complete CPU inference path for a problem this small.
