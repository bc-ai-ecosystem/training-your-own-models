"""Create original, synthetic text with entity-separated train/validation/test sets."""
import argparse
import hashlib
import json
import random
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--output", type=Path, default=Path("data/tiny-text"))
a = p.parse_args()
if a.output.exists() and any(a.output.iterdir()):
    p.error("output is not empty; choose a new directory")
a.output.mkdir(parents=True, exist_ok=True)
colors = ["red", "blue", "green", "white", "black"]
objects = ["lamp", "clock", "radio", "fan"]
rooms = ["kitchen", "office", "studio", "hall"]
manifest = {"source": "original procedural examples", "encoding": "UTF-8 bytes",
            "split_unit": "entity identifier", "splits": {}}
for split, first, count, seed in [("train", 0, 800, 401), ("validation", 800, 100, 402),
                                  ("test", 900, 100, 403)]:
    rng = random.Random(seed)
    lines = []
    for i in range(first, first + count):
        color, obj, room = rng.choice(colors), rng.choice(objects), rng.choice(rooms)
        status = rng.choice(["on", "off"])
        entity = f"item{i:04d}"
        lines.append(f"Record {entity}: the {color} {obj} is in the {room}. Its switch is {status}.\n")
        lines.append(f"Question: Where is {entity}? Answer: the {room}.\n")
        lines.append(f"Question: What color is {entity}? Answer: {color}.\n\n")
    raw = "".join(lines).encode("utf-8")
    (a.output / f"{split}.txt").write_bytes(raw)
    manifest["splits"][split] = {"entities": count, "first_entity": first,
        "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "seed": seed}
(a.output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps(manifest, indent=2))
