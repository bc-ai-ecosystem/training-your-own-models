"""Run on a machine with torch installed. No downloads and no GPU needed."""
import tempfile
from pathlib import Path
import torch
from model import Config, ByteTransformer

torch.manual_seed(7)
m = ByteTransformer(Config(context=16, width=32, layers=2, heads=4, dropout=0.0))
x = torch.randint(256, (2, 16))
m.eval()
a = m(x).detach()
changed = x.clone()
changed[:, 8:] = (changed[:, 8:] + 1) % 256
b = m(changed).detach()
assert torch.allclose(a[:, :8], b[:, :8], atol=1e-6), "future tokens leaked"
m.train()
opt = torch.optim.AdamW(m.parameters(), lr=1e-3, foreach=False)
before = m.token.weight.detach().clone()
loss = torch.nn.functional.cross_entropy(m(x).reshape(-1, 256), x.roll(-1, 1).reshape(-1))
loss.backward()
assert m.token.weight.grad is not None and torch.isfinite(m.token.weight.grad).all()
opt.step()
assert not torch.equal(before, m.token.weight), "parameters did not update"
m.eval()
expected = m(x).detach()
with tempfile.TemporaryDirectory() as d:
    path = Path(d) / "weights.pt"
    torch.save(m.state_dict(), path)
    restored = ByteTransformer(m.config)
    restored.load_state_dict(torch.load(path, weights_only=True))
    restored.eval()
    assert torch.allclose(expected, restored(x), atol=1e-6), "reload changed output"
print("PASS shapes, causal isolation, finite gradients, parameter update, reload")
