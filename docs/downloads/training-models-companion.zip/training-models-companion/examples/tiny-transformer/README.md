# Tiny byte transformer

This original educational implementation trains from random weights. It uses Python 3.11 and the PyTorch 2.8.0 API. It is not a Qwen/Gemma/Granite implementation and is not intended as a production serving engine.

## Setup and first check

Create a separate virtual environment. Install the official torch 2.8.0 CPU wheel, or the official CUDA build compatible with your GPU/driver. Do not install both into the same environment. See https://pytorch.org/get-started/previous-versions/ .

From the companion root:

```bash
python examples/tiny-transformer/make_data.py --output data/tiny-text
python examples/tiny-transformer/check_model.py
python examples/tiny-transformer/train.py \
  --data data/tiny-text --output runs/byte-smoke \
  --device cpu --steps 20 --warmup 2 \
  --width 32 --layers 2 --heads 4 \
  --context 32 --batch-size 2 --eval-every 10
```

The model check tests shape, future-token isolation, finite gradients, a parameter update, and save/load equivalence. The data generator is standard-library-only. The model and trainer require PyTorch.

## GPU experiment

```bash
python examples/tiny-transformer/train.py \
  --data data/tiny-text --output runs/byte-gpu \
  --device cuda --steps 1000 --warmup 50 \
  --context 128 --width 128 --layers 4 --heads 4 \
  --batch-size 8 --accumulation 2 --eval-every 100
```

Only add `--bf16` when the actual device supports it. Parameters and AdamW states remain FP32; the flag enables BF16 autocast for selected operations. The default architecture has approximately 0.84M parameters. The generated corpus is intentionally tiny and synthetic; repeated exposure does not create general language capability.

## Load on CPU or GPU

```bash
python examples/tiny-transformer/use_model.py \
  runs/byte-gpu/checkpoint.pt --device cpu --prompt "Record item9999:"
python examples/tiny-transformer/use_model.py \
  runs/byte-gpu/checkpoint.pt --device cuda --prompt "Record item9999:"
```

The same architecture and weights are reconstructed on either device. The script crops to the trained context, has no optimized KV cache, and decodes invalid UTF-8 with replacement characters. CPU/GPU samples need not match exactly even with the same seed.

## Evaluate and resume

Select the procedure using validation data before evaluating the final test file:

```bash
python examples/tiny-transformer/use_model.py \
  runs/byte-gpu/checkpoint.pt --device cpu \
  --evaluate-file data/tiny-text/test.txt
```

To resume an interrupted run, repeat its original training command and add `--resume runs/byte-gpu/checkpoint.pt`. Keep the original total steps, architecture, training hyperparameters, numeric policy, device, and data files. The program checks material settings and data hashes. A deliberate extension with a different learning-rate schedule is a new experiment, not this exact-resume path.

## Verification boundary

The data generator was executed; generated file hashes and sizes were recorded. All Python files passed syntax compilation and independent static review. The authoring environment did not contain PyTorch, so `check_model.py`, training, inference, optimizer recovery, CPU/GPU numerical parity and GPU memory were not executed there. Run those acceptance checks locally before a longer experiment.
