# Verification record

Date: 2 October 2026

## Passed in the preparation environment

Commands:

```
python make_toy_data.py
python test_numerics.py
python -m py_compile decision_pointer.py make_toy_data.py test_numerics.py
python decision_pointer.py --help
```

Observed result: all commands exited with status 0. The numerical test printed:

```
PASS: 30 toy records, split isolation, indexes, option remapping, rejection, probabilities, metrics, masks, cache arithmetic
Pointer toy probabilities: [0.575975, 0.283995, 0.140029]
Loss when middle option is correct: 1.258797
```

The fake tokenizer in the numerical test checks bookkeeping only. It is not a substitute for Qwen tokenizer tests.

## Not run

- Dependency installation or model-weight downloads
- PyTorch CPU forward/backward or optimizer updates
- PyTorch CUDA forward/backward or memory-fit measurements
- Actual training, calibration fitting on model outputs, or evaluation quality
- Save/reload numerical parity on real weights
- CPU/GPU probability and threshold parity
- Throughput or latency benchmarks

Reason: PyTorch and Transformers were absent. No GPU training claim is made.

## Real-device acceptance checks before deployment

1. Load the pinned Qwen3-0.6B revision and confirm fewer than one billion total parameters
2. Log one encoded record, its token count, option indexes, and target after shuffling
3. Run one forward/backward/update and assert nonzero finite gradients in the head and backbone in full mode
4. Confirm no backbone gradients and nonzero head gradients in head-only mode
5. Overfit a tiny training-only subset as a debugging check, then return to independent splits
6. Save/reload and compare logits in the same dtype/device and eval mode
7. Run calibration only on calibration groups; confirm a calibration file from another run is refused
8. Evaluate on untouched test groups and inspect error slices, option-order sensitivity, missing evidence, and out-of-domain inputs
9. Compare CPU fp32 and supported CUDA bf16 probabilities, top-1 choices, and abstention-threshold crossings
10. Measure peak allocated/reserved GPU memory and cold/warm inference latency on the actual machine

A failed acceptance check is a debugging result, not evidence of successful training.
