"""Dependency-free data, math and formatting tests. Does not validate torch execution."""
import math
from pathlib import Path
import random
from decision_pointer import read_rows, assert_disjoint, encode, stable_probs, summarize, shuffled_options

class ToyTokenizer:
    def encode(self, text, add_special_tokens=False):
        # Only validates index bookkeeping, not the real tokenizer's segmentation.
        return list(range(1, len(text.split()) + 1))

root = Path(__file__).resolve().parent / "data"
all_groups = []
for split in ("train", "dev", "calibration", "test"):
    rows = read_rows(root / f"{split}.jsonl")
    assert_disjoint(rows, all_groups)
    all_groups.extend(r["group"] for r in rows)
    for r in rows:
        ids, ends, decision, target = encode(r, ToyTokenizer(), 256)
        assert len(ends) == 3 and max(ends) < decision == len(ids) - 1
        shuffled = shuffled_options(r, random.Random(13))
        _, _, _, y = encode(shuffled, ToyTokenizer(), 256)
        assert shuffled["options"][y]["id"] == r["label"]
try:
    encode(rows[0], ToyTokenizer(), 1)
    raise AssertionError("overlength input was accepted")
except ValueError:
    pass
try:
    assert_disjoint(rows, [rows[0]["group"]])
    raise AssertionError("leakage was accepted")
except ValueError:
    pass
z = [1 / math.sqrt(2), 0, -1 / math.sqrt(2)]
p = stable_probs(z)
assert abs(sum(p) - 1) < 1e-12
assert max(range(3), key=p.__getitem__) == max(range(3), key=stable_probs(z, 3).__getitem__)
assert stable_probs(z, 3)[0] < p[0]
metric = summarize([{"logits": [0.0, 0.0], "target": 0}])
assert abs(metric["nll"] - math.log(2)) < 1e-12
assert abs(metric["brier_sum_over_classes"] - 0.5) < 1e-12
assert metric["error_rate_at_p90"] is None
assert summarize([{"logits": [10000.0, -10000.0], "target": 1}])["nll"] == 20000.0
# Seven-token block-causal graph from the chapter.
seg = [0, 0, 0, 1, 1, 2, 2]
allowed = [[j <= i and (seg[j] == 0 or seg[i] == seg[j]) for j in range(7)] for i in range(7)]
assert allowed[6] == [True, True, True, False, False, True, True]
assert allowed[4] == [True, True, True, True, True, False, False]
cache_bytes = 2 * 28 * 1 * 2048 * 8 * 128 * 2
assert cache_bytes / (1024**2) == 224
print("PASS: 30 toy records, split isolation, indexes, option remapping, rejection, probabilities, metrics, masks, cache arithmetic")
print("Pointer toy probabilities:", [round(v, 6) for v in p])
print("Loss when middle option is correct:", round(-math.log(p[1]), 6))
