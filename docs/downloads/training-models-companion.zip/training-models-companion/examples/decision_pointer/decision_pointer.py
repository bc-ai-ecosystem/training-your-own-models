#!/usr/bin/env python3
"""Educational full-weight Qwen3 decision conversion. No text generation.

Status: syntax and dependency-free tests checked; GPU training is unmeasured.
Use --help. Keep train, dev, calibration, and test groups independent.
"""
import argparse
import copy
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import random
import sys

FORMAT_VERSION = "plain-parts-option-end-v1"


def read_rows(path, labeled=True):
    rows = []
    for line_no, line in enumerate(Path(path).read_text().splitlines(), 1):
        if not line.strip():
            continue
        row = json.loads(line)
        for key in ("id", "group", "state", "question", "options") + (("label",) if labeled else ()):
            if key not in row:
                raise ValueError(f"{path}:{line_no}: missing {key}")
        if not all(isinstance(row[k], str) and row[k] for k in ("id", "group", "state", "question")):
            raise ValueError("id/group/state/question must be nonempty strings")
        opts = row["options"]
        if not isinstance(opts, list) or not 2 <= len(opts) <= 32:
            raise ValueError("this educational program allows 2..32 options")
        if any(not isinstance(o, dict) or not isinstance(o.get("id"), str) or
               not o["id"] or not isinstance(o.get("text"), str) or not o["text"] for o in opts):
            raise ValueError("each option needs nonempty string id and text")
        names = [o["id"] for o in opts]
        if len(set(names)) != len(names) or (labeled and row["label"] not in names):
            raise ValueError("option IDs must be unique and label must name an option")
        rows.append(row)
    if not rows or len({r["id"] for r in rows}) != len(rows):
        raise ValueError("empty file or repeated example IDs")
    return rows


def signature(path, rows):
    return {"sha256": hashlib.sha256(Path(path).read_bytes()).hexdigest(),
            "groups": sorted({r["group"] for r in rows}), "examples": len(rows)}


def assert_disjoint(rows, other_groups):
    overlap = {r["group"] for r in rows} & set(other_groups)
    if overlap:
        raise ValueError(f"data leakage: repeated split groups {sorted(overlap)[:5]}")


def shuffled_options(row, rng):
    row = copy.deepcopy(row)
    rng.shuffle(row["options"])
    # The label is an ID, so its numerical index is recomputed after shuffling.
    return row


def encode(row, tokenizer, max_length):
    """Tokenize parts separately; this exact convention is the checkpoint contract."""
    ids, ends = [], []

    def add(text):
        part = tokenizer.encode(text, add_special_tokens=False)
        if not part:
            raise ValueError("tokenizer returned no tokens for a nonempty part")
        ids.extend(part)

    # No chat template: training and inference use this supervised feature format.
    add("State:\n" + row["state"] + "\nQuestion:\n" + row["question"] + "\n")
    for i, option in enumerate(row["options"]):
        add(f"Option {i}: " + option["text"] + "\nEnd of option.\n")
        ends.append(len(ids) - 1)
    add("Decision:")
    if len(ids) > max_length:
        raise ValueError(f"{row['id']}: {len(ids)} tokens exceeds {max_length}; no silent truncation")
    target = [o["id"] for o in row["options"]].index(row["label"]) if "label" in row else 0
    assert all(0 <= i < len(ids) - 1 for i in ends)
    return ids, ends, len(ids) - 1, target


def stable_probs(logits, temperature=1.0):
    if not math.isfinite(temperature) or temperature <= 0:
        raise ValueError("temperature must be finite and positive")
    if not logits or not all(math.isfinite(v) for v in logits):
        raise ValueError("logits must be a nonempty finite sequence")
    z = [v / temperature for v in logits]
    m = max(z)
    exp = [math.exp(v - m) for v in z]
    return [v / sum(exp) for v in exp]


def summarize(predictions, temperature=1.0):
    n = len(predictions)
    if not n:
        raise ValueError("no predictions")
    correct = nll = brier = accepted = accepted_wrong = 0.0
    bins = [{"count": 0, "confidence_sum": 0.0, "correct": 0} for _ in range(10)]
    for item in predictions:
        p = stable_probs(item["logits"], temperature)
        y = item["target"]
        k = max(range(len(p)), key=p.__getitem__)
        hit = int(k == y)
        correct += hit
        z = [v / temperature for v in item["logits"]]
        m = max(z)
        nll += m + math.log(sum(math.exp(v - m) for v in z)) - z[y]
        brier += sum((v - int(i == y)) ** 2 for i, v in enumerate(p))
        b = bins[min(9, int(max(p) * 10))]
        b["count"] += 1
        b["confidence_sum"] += max(p)
        b["correct"] += hit
        if max(p) >= 0.9:
            accepted += 1
            accepted_wrong += 1 - hit
    reliability = []
    for i, b in enumerate(bins):
        count = b["count"]
        reliability.append({"range": [i / 10, (i + 1) / 10], "count": count,
                            "mean_confidence": b["confidence_sum"] / count if count else None,
                            "accuracy": b["correct"] / count if count else None})
    return {"examples": n, "accuracy": correct / n, "nll": nll / n,
            "brier_sum_over_classes": brier / n, "temperature": temperature,
            "coverage_at_p90": accepted / n,
            "error_rate_at_p90": accepted_wrong / accepted if accepted else None,
            "reliability": reliability}


def dependencies():
    import torch
    from transformers import AutoConfig, AutoModel, AutoTokenizer
    return torch, AutoConfig, AutoModel, AutoTokenizer


def make_model(backbone, torch, width):
    class OptionPointer(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.backbone = backbone
            d = backbone.config.hidden_size
            self.query = torch.nn.Linear(d, width)
            self.key = torch.nn.Linear(d, width)

        def forward(self, encoded):
            ids, ends, decision, _ = encoded
            device = next(self.parameters()).device
            input_ids = torch.tensor([ids], dtype=torch.long, device=device)
            # One question per row: ordinary causal attention is enough.
            h = self.backbone(input_ids=input_ids, use_cache=False).last_hidden_state[0]
            q = self.query(h[decision]).float()
            k = self.key(h[ends]).float()
            return (k * q).sum(-1) / math.sqrt(width)
    return OptionPointer()


def context(torch, device, precision):
    if precision == "bf16":
        if device != "cuda" or not torch.cuda.is_bf16_supported():
            raise ValueError("bf16 requires a supported CUDA GPU; use --precision fp32 otherwise")
        return torch.autocast("cuda", dtype=torch.bfloat16)
    from contextlib import nullcontext
    return nullcontext()


def collect(model, rows, tokenizer, max_length, torch, device, precision):
    model.eval()
    predictions = []
    with torch.inference_mode():
        for row in rows:
            enc = encode(row, tokenizer, max_length)
            with context(torch, device, precision):
                z = model(enc)
            predictions.append({"id": row["id"], "target": enc[-1],
                                "option_ids": [o["id"] for o in row["options"]],
                                "logits": z.float().cpu().tolist()})
    return predictions


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n")


def train(args):
    torch, AutoConfig, AutoModel, AutoTokenizer = dependencies()
    if args.device == "cuda" and not torch.cuda.is_available():
        raise ValueError("CUDA unavailable; GPU training was requested")
    train_rows, dev_rows = read_rows(args.train), read_rows(args.dev)
    assert_disjoint(dev_rows, [r["group"] for r in train_rows])
    run = Path(args.run)
    run.mkdir(parents=True, exist_ok=False)  # Refuse to overwrite a previous run.
    random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    cfg = AutoConfig.from_pretrained(args.model, revision=args.revision)
    if cfg.model_type != "qwen3":
        raise ValueError("this reference supports attention-only Qwen3, not Qwen3.5/hybrid models")
    # Count the architecture with meta tensors before downloading large weights.
    with torch.device("meta"):
        shape_model = AutoModel.from_config(cfg, attn_implementation="sdpa")
    estimate = sum(p.numel() for p in shape_model.parameters()) + 2 * (cfg.hidden_size + 1) * args.pointer_width
    del shape_model
    if estimate > 1_000_000_000:
        raise ValueError(f"{estimate} architectural parameters exceeds this exercise's one-billion ceiling")
    resolved = getattr(cfg, "_commit_hash", None) or args.revision
    tokenizer = AutoTokenizer.from_pretrained(args.model, revision=resolved)
    # FP32 parameters and Adam state; autocast reduces many activation/matmul costs.
    backbone = AutoModel.from_pretrained(args.model, revision=resolved,
                                        torch_dtype=torch.float32, attn_implementation="sdpa")
    backbone.config.use_cache = False
    if args.mode == "head":
        backbone.requires_grad_(False)
    elif args.checkpointing:
        backbone.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    model = make_model(backbone, torch, args.pointer_width)
    count = sum(p.numel() for p in model.parameters())
    if count > 1_000_000_000:
        raise ValueError(f"{count} parameters exceeds this exercise's one-billion ceiling")
    model = model.to(args.device)
    body = [p for p in model.backbone.parameters() if p.requires_grad]
    head = list(model.query.parameters()) + list(model.key.parameters())
    groups = [{"params": head, "lr": args.head_lr, "base_lr": args.head_lr}]
    if body:
        groups.append({"params": body, "lr": args.backbone_lr, "base_lr": args.backbone_lr})
    optimizer = torch.optim.AdamW(groups, weight_decay=args.weight_decay, foreach=False)
    # Validate all lengths before spending an epoch on the GPU.
    for r in train_rows + dev_rows:
        encode(r, tokenizer, args.max_length)
    config = {"format": FORMAT_VERSION, "model": args.model, "revision": resolved,
              "pointer_width": args.pointer_width, "max_length": args.max_length,
              "parameters": count, "trainable_parameters": sum(p.numel() for p in model.parameters() if p.requires_grad),
              "mode": args.mode, "seed": args.seed, "train": signature(args.train, train_rows),
              "dev": signature(args.dev, dev_rows), "command": sys.argv,
              "versions": {p: importlib.metadata.version(p) for p in ("torch", "transformers", "tokenizers")}}
    dump(run / "config.json", config)
    tokenizer.save_pretrained(run / "tokenizer")
    before = collect(model, dev_rows, tokenizer, args.max_length, torch, args.device, args.precision)
    dump(run / "untrained_head_dev.json", summarize(before))
    best, history, step = math.inf, [], 0
    total_steps = args.epochs * math.ceil(len(train_rows) / args.accum)
    warmup = max(1, round(total_steps * args.warmup_fraction))
    rng = random.Random(args.seed)
    if args.device == "cuda":
        torch.cuda.reset_peak_memory_stats()
    for epoch in range(args.epochs):
        order = list(train_rows)
        rng.shuffle(order)
        epoch_losses = []
        model.train()
        if args.mode == "head":
            model.backbone.eval()
        for start in range(0, len(order), args.accum):
            chunk = order[start:start + args.accum]
            optimizer.zero_grad(set_to_none=True)
            for row in chunk:
                enc = encode(shuffled_options(row, rng), tokenizer, args.max_length)
                with context(torch, args.device, args.precision):
                    logits = model(enc)
                    target = torch.tensor([enc[-1]], dtype=torch.long, device=args.device)
                    loss = torch.nn.functional.cross_entropy(logits[None, :], target)
                if not torch.isfinite(loss):
                    raise FloatingPointError("nonfinite loss; stop and inspect data/precision/lr")
                epoch_losses.append(loss.item())
                (loss / len(chunk)).backward()  # Correct denominator for the final partial chunk.
            torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], args.clip, error_if_nonfinite=True)
            step += 1
            factor = min(step / warmup, (total_steps - step + 1) / max(1, total_steps - warmup + 1))
            for group in optimizer.param_groups:
                group["lr"] = group["base_lr"] * factor
            optimizer.step()
        predictions = collect(model, dev_rows, tokenizer, args.max_length, torch, args.device, args.precision)
        metrics = summarize(predictions)
        metrics.update(epoch=epoch + 1, mean_train_loss=sum(epoch_losses) / len(epoch_losses), optimizer_steps=step)
        history.append(metrics)
        print(json.dumps({k: metrics[k] for k in ("epoch", "mean_train_loss", "nll", "accuracy")}), flush=True)
        if metrics["nll"] < best:
            best = metrics["nll"]
            model.backbone.save_pretrained(run / "backbone", safe_serialization=True)
            torch.save({"query": model.query.state_dict(), "key": model.key.state_dict()}, run / "head.pt")
            checkpoint_record = dict(metrics)
            identity = hashlib.sha256((run / "head.pt").read_bytes())
            identity.update(json.dumps(config, sort_keys=True).encode())
            identity.update(str(epoch + 1).encode())
            checkpoint_record["checkpoint_id"] = identity.hexdigest()
            dump(run / "best_dev.json", checkpoint_record)
        dump(run / "history.json", history)
    if args.device == "cuda":
        dump(run / "memory.json", {"peak_allocated_bytes": torch.cuda.max_memory_allocated(),
                                   "peak_reserved_bytes": torch.cuda.max_memory_reserved()})
    print("Saved best development-NLL checkpoint. Calibration and untouched test evaluation are separate steps.")


def load_run(args):
    torch, _, AutoModel, AutoTokenizer = dependencies()
    run = Path(args.run)
    cfg = json.loads((run / "config.json").read_text())
    cfg["checkpoint_id"] = json.loads((run / "best_dev.json").read_text())["checkpoint_id"]
    if cfg["format"] != FORMAT_VERSION:
        raise ValueError("format version mismatch")
    tokenizer = AutoTokenizer.from_pretrained(run / "tokenizer", local_files_only=True)
    backbone = AutoModel.from_pretrained(run / "backbone", local_files_only=True,
                                        torch_dtype=torch.float32, attn_implementation="sdpa")
    model = make_model(backbone, torch, cfg["pointer_width"])
    head = torch.load(run / "head.pt", map_location="cpu", weights_only=True)
    model.query.load_state_dict(head["query"])
    model.key.load_state_dict(head["key"])
    return model.to(args.device), tokenizer, cfg, torch


def measure(args):
    rows = read_rows(args.data, labeled=args.action != "predict")
    model, tokenizer, cfg, torch = load_run(args)
    forbidden = cfg["train"]["groups"] + cfg["dev"]["groups"]
    temperature = 1.0
    if args.calibration:
        calibration = json.loads(Path(args.calibration).read_text())
        if calibration.get("checkpoint_id") != cfg["checkpoint_id"]:
            raise ValueError("calibration belongs to a different checkpoint")
        temperature = calibration["temperature"]
        forbidden += calibration["data"]["groups"]
    if args.action != "predict":
        assert_disjoint(rows, forbidden)
    predictions = collect(model, rows, tokenizer, cfg["max_length"], torch, args.device, args.precision)
    if args.action == "calibrate":
        if args.calibration:
            raise ValueError("calibrate fits from raw logits; do not pass --calibration")
        # Bounded log-temperature grid. This is transparent, not a claim of an exact optimum.
        candidates = [math.exp(math.log(0.1) + i * math.log(100) / 200) for i in range(201)]
        temperature = min(candidates, key=lambda t: summarize(predictions, t)["nll"])
        result = {"temperature": temperature, "checkpoint_id": cfg["checkpoint_id"],
                  "data": signature(args.data, rows),
                  "search": {"min": 0.1, "max": 10.0, "points": 201},
                  "raw": summarize(predictions), "calibrated": summarize(predictions, temperature)}
    elif args.action == "predict":
        result = []
        for r, p in zip(rows, predictions):
            probabilities = stable_probs(p["logits"], temperature)
            i = max(range(len(probabilities)), key=probabilities.__getitem__)
            result.append({"id": r["id"], "choice": p["option_ids"][i],
                           "probabilities": dict(zip(p["option_ids"], probabilities))})
    else:
        result = summarize(predictions, temperature)
    dump(args.output, result)
    print(json.dumps(result, indent=2))


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="action", required=True)
    t = sub.add_parser("train")
    t.add_argument("--train", required=True)
    t.add_argument("--dev", required=True)
    t.add_argument("--run", required=True)
    t.add_argument("--model", default="Qwen/Qwen3-0.6B")
    t.add_argument("--revision", default="main", help="Prefer an immutable Hub commit; resolved hash is recorded")
    t.add_argument("--mode", choices=["full", "head"], default="full")
    t.add_argument("--epochs", type=int, default=3)
    t.add_argument("--accum", type=int, default=8)
    t.add_argument("--max-length", type=int, default=256)
    t.add_argument("--pointer-width", type=int, default=256)
    t.add_argument("--backbone-lr", type=float, default=2e-5)
    t.add_argument("--head-lr", type=float, default=1e-3)
    t.add_argument("--weight-decay", type=float, default=0.01)
    t.add_argument("--warmup-fraction", type=float, default=0.1)
    t.add_argument("--clip", type=float, default=1.0)
    t.add_argument("--seed", type=int, default=42)
    t.add_argument("--checkpointing", action=argparse.BooleanOptionalAction, default=True)
    for name in ("calibrate", "evaluate", "predict"):
        q = sub.add_parser(name)
        q.add_argument("--run", required=True)
        q.add_argument("--data", required=True)
        q.add_argument("--calibration")
        q.add_argument("--output", required=True)
    for q in [t] + [sub.choices[n] for n in ("calibrate", "evaluate", "predict")]:
        q.add_argument("--device", choices=["cuda", "cpu"], default="cuda")
        q.add_argument("--precision", choices=["bf16", "fp32"], default="bf16")
    return p


if __name__ == "__main__":
    args = parser().parse_args()
    if args.action == "train":
        if min(args.epochs, args.accum, args.max_length, args.pointer_width) < 1:
            raise ValueError("counts must be positive")
        if min(args.backbone_lr, args.head_lr, args.clip) <= 0 or args.weight_decay < 0:
            raise ValueError("learning rates and clipping must be positive; decay must be nonnegative")
        if not 0 <= args.warmup_fraction <= 1:
            raise ValueError("warmup fraction must lie between zero and one")
        train(args)
    else:
        measure(args)
