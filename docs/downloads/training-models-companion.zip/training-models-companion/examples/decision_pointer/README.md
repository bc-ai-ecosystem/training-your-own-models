# Qwen3 option-pointer capstone

This is an original educational conversion, inspired by the open decision-model pattern. It is not Jev, a reproduction of RLCD, the Kev checkpoint, or a CLM checkpoint.

It uses a pretrained Qwen3-0.6B decoder as a feature backbone. It does not call generate(). A learned pointer scores input-provided options. The default `full` mode updates the entire backbone plus the new head. `head` freezes the backbone for a cheaper comparison. A strict one-billion-parameter check prevents accidentally loading a much larger training exercise.

## What is actually verified

- Python syntax compilation: passed
- Dependency-free tests: passed for 30 toy records, group isolation, index construction, shuffled labels, overlength rejection, stable softmax/NLL, Brier score, branch-mask arithmetic, and KV-size arithmetic
- PyTorch, Transformers, model download, forward/backward, reload, GPU memory, speed, and quality: not executed in this environment

The environment did not contain PyTorch/Transformers. This is a source-reviewed reference implementation requiring a real-device smoke test. No package installation or training was performed. Use a supported official PyTorch build for the target NVIDIA driver and a Transformers release supporting Qwen3. Record exact installed versions; config.json does this for the run. Do not interpret an unpinned current package install as a tested compatibility lock.

## Files and data contract

- decision_pointer.py: train, calibrate, evaluate, and predict commands
- make_toy_data.py: writes original fictional support examples
- test_numerics.py: dependency-free checks
- data/train.jsonl: 12 toy examples
- data/dev.jsonl: 6 model-selection examples
- data/calibration.jsonl: 6 calibration examples
- data/test.jsonl: 6 test examples

Every labeled JSONL line has id, group, state, question, options, and label. options is a list of objects with string id and text. label is an option ID, not a fixed integer. The numerical target is recomputed after option shuffling. For predict only, label can be omitted. A group identifies a source conversation or document; all related examples must share it and stay in one split. The code checks exact group overlap, not semantic near-duplicates. You still need deduplication and an independent dataset audit.

The tokenizer encodes each explicitly constructed text part separately. That exact formatting is used in both training and inference. The option's final delimiter-token position supplies its vector; the last Decision token supplies the query vector. Plain-text delimiters require no new vocabulary rows, but this simple format is not a robust adversarial-input protocol. A production system needs formatting/prompt-injection tests.

Thirty simple records only exercise the plumbing. Six calibration examples cannot establish real calibration, and six test examples cannot establish deployment quality. Replace these files with enough independent, representative labeled groups for the actual workload. Never claim that toy-data training creates broad Jev-like intelligence.

## Run the tests first

From this directory:

```
python make_toy_data.py
python test_numerics.py
python -m py_compile decision_pointer.py
```

Expected last lines include PASS and pointer probabilities [0.575975, 0.283995, 0.140029]. The middle-option loss is about 1.258797.

## Full-weight training on one NVIDIA GPU

Set up an isolated environment with supported torch, transformers, safetensors, and tokenizer dependencies. Do not use device_map=auto as a training-memory strategy. The model is deliberately placed on one device.

Run a first-epoch smoke test with short inputs before making a larger dataset:

```
python decision_pointer.py train --train data/train.jsonl --dev data/dev.jsonl --run runs/full-smoke --epochs 1 --mode full --max-length 256 --accum 8 --device cuda --precision bf16
```

Prefer adding --revision with a verified immutable Qwen/Qwen3-0.6B commit. If main is used, the resolved Hub commit is recorded when available. The program refuses an existing run directory rather than overwriting it.

For a comparison, use a different new directory and --mode head. A random new head's initial dev results are saved as untrained_head_dev.json. That is a plumbing reference, not a strong zero-shot baseline; also compare a fixed-label model or restricted-logit LM on the same split when making quality claims.

### Parameters and why they exist

- --epochs: full traversals of the training records; more can overfit
- --accum: number of one-example microbatches per optimizer update; the final partial group uses its actual size
- --max-length: hard token limit including state, question, options, and readout; overlength raises an error
- --pointer-width: projection dimension, default 256; controls head capacity
- --backbone-lr: original pretrained-weight update rate, default 2e-5
- --head-lr: new-head update rate, default 1e-3; a proposed starting point, not an optimized recipe
- --weight-decay: AdamW parameter decay, default 0.01
- --warmup-fraction: fraction of optimizer steps used to ramp the rate; followed by decay
- --clip: gradient-norm cap, default 1.0
- --seed: initialization and shuffling seed; exact cross-device determinism is not promised
- --checkpointing: recompute intermediate activations during backward to save memory
- --mode full/head: update all parameters or only the new query/key projections
- --precision bf16/fp32: CUDA bf16 autocast when supported, or full fp32 arithmetic

The weights and Adam buffers are fp32 in this reference. bf16 refers to autocast operations, not all stored parameters. This matters when budgeting VRAM. It does not enable fp16 or use a GradScaler. CPU mode requires --precision fp32 and can be very slow for full training.

## Selection, calibration, and final test

The program chooses the checkpoint with lowest development NLL, writes backbone safetensors, tokenizer files, head.pt containing tensor state dictionaries, configuration, history, and best-development metrics. head.pt is loaded with weights_only=True. Never load arbitrary untrusted pickle checkpoints.

A training restart/resume optimizer checkpoint is deliberately not implemented. This program is for short experiments; rerunning starts a new run. Long training needs optimizer/scheduler/random-state recovery added and tested.

Fit a positive temperature on the calibration split:

```
python decision_pointer.py calibrate --run runs/full-smoke --data data/calibration.jsonl --output runs/full-smoke/calibration.json --device cuda --precision bf16
```

This searches 201 log-spaced values from 0.1 to 10 to minimize calibration NLL. It is a bounded transparent grid, not a proof of a globally optimal temperature. A boundary result warrants inspection. Do not fit again after seeing final-test results. Each calibration file records a checkpoint identity; the program rejects cross-checkpoint reuse. Keep the complete saved run together and do not edit weights behind that identity.

Then evaluate the untouched test file:

```
python decision_pointer.py evaluate --run runs/full-smoke --data data/test.jsonl --calibration runs/full-smoke/calibration.json --output runs/full-smoke/test.json --device cuda --precision bf16
```

Reports include accuracy, NLL, Brier (sum over classes, mean over examples), reliability bins with counts, coverage at p >= 0.9, and error rate among accepted examples. A threshold of 0.9 is a reporting example, not a deployment recommendation. This exercise does not implement a learned act/escalate head.

## Reload for CPU inference

```
python decision_pointer.py predict --run runs/full-smoke --data data/test.jsonl --calibration runs/full-smoke/calibration.json --output runs/full-smoke/cpu-predictions.json --device cpu --precision fp32
```

Labels are ignored for prediction and may be omitted from new prediction records. The same saved tokenizer, formatting, backbone, pointer weights, and temperature are used on CPU. No CUDA cache or optimizer state is needed. CPU fp32 may differ slightly from CUDA bf16. Compare maximum probability difference, top-1 agreement, NLL, and threshold crossings on a held-out set; a prediction near the decision boundary can change with small numerical differences. Measure latency after warm-up and disclose model-loading time separately.

The generic Hugging Face text-generation pipeline does not know this custom head. Run this program or write a server around the same forward function. Do not assume a base-model GGUF export includes the pointer projections.

## Failure checks

If loss is nonfinite, stop and inspect learning rate, precision, input lengths, and labels. If training loss drops but dev NLL worsens, suspect overfitting. If predictions track option order, inspect label remapping and train-time shuffling. If every result is confident, test missing-evidence and out-of-domain examples. If an overlength error appears, design a documented truncation or retrieval policy rather than deleting the validation.

No assertion here establishes that the model is safe to act autonomously. Return suggestions first, retain evidence, and keep permissions and high-impact decisions outside the learned confidence mechanism.
