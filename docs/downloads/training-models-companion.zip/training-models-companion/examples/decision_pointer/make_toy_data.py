"""Write small original toy fixtures, not a realistic training corpus."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent / "data"
EXAMPLES = {
 "train": [
  ("billing", "The invoice charged me twice for one order."),
  ("delivery", "The parcel was left at a different building."),
  ("access", "My password reset link has expired."),
  ("billing", "The total on my payment receipt is wrong."),
  ("delivery", "Tracking says delivered but the package is missing."),
  ("access", "I cannot sign in after changing my email address."),
  ("billing", "Please explain this unexpected subscription charge."),
  ("delivery", "The courier has not collected the shipment."),
  ("access", "My account is locked after several failed sign-ins."),
  ("billing", "I need a copy of the invoice for yesterday's purchase."),
  ("delivery", "Please check why the delivery is late."),
  ("access", "The login verification code never arrives.")],
 "dev": [
  ("billing", "I see two identical card charges from your shop."),
  ("delivery", "My package is still at the depot after five days."),
  ("access", "The sign-in page says my account does not exist."),
  ("billing", "The tax amount on the bill looks incorrect."),
  ("delivery", "The driver delivered my box to my neighbor."),
  ("access", "I lost access to the phone used for login verification.")],
 "calibration": [
  ("billing", "Can you correct the company name on my invoice?"),
  ("delivery", "Where is the shipment that should have arrived Monday?"),
  ("access", "The password recovery page keeps rejecting my email."),
  ("billing", "Your payment page debited my card but showed an error."),
  ("delivery", "The tracking number has not changed since dispatch."),
  ("access", "My new password works on the web but not in the app.")],
 "test": [
  ("billing", "The receipt lists a higher price than the checkout did."),
  ("delivery", "The courier marked an unsuccessful delivery while I was home."),
  ("access", "I cannot get past the two-factor sign-in screen."),
  ("billing", "Please help reconcile an extra debit on my statement."),
  ("delivery", "My order is travelling to the wrong town."),
  ("access", "The authentication link logs me out immediately.")]
}
OPTIONS = [{"id": "billing", "text": "Payments, receipts, invoices, or unexpected charges"},
           {"id": "delivery", "text": "Shipment tracking, couriers, late or missing parcels"},
           {"id": "access", "text": "Signing in, passwords, locked accounts, or verification"}]
ROOT.mkdir(exist_ok=True)
for split, items in EXAMPLES.items():
    rows = [{"id": f"{split}-{i:03}", "group": f"independent-{split}-{i:03}",
             "state": text, "question": "Which support team should handle this request?",
             "options": OPTIONS, "label": label} for i, (label, text) in enumerate(items)]
    (ROOT / f"{split}.jsonl").write_text("".join(json.dumps(r) + "\n" for r in rows))
print("Wrote 12 train + 6 dev + 6 calibration + 6 test toy records")
