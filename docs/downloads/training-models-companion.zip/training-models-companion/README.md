# Training Your Own Models on One 24 GB GPU

This companion accompanies the complete PDF and Markdown textbook. Start with the first-model project. Use the chapter's stated working directory and the README beside each project. The Markdown book and assets are included here so its figures and local links can be opened together.

## Start without installing anything beyond Python

From this directory:

```bash
python --version
python examples/first-model/train.py --output runs/first
python examples/first-model/predict.py runs/first/model.json 0.8 -0.4
```

This trains a three-parameter model from scratch, evaluates it, writes a JSON model, reloads it, and predicts a fresh input. Python 3.10 or newer is the reference for this dependency-free example.

## Project map

- `examples/first-model`: standard-library gradient-descent classifier
- `examples/tiny-ml`: CPU tabular classification/regression, tiny CNN, image transfer comparison, one-object detection, segmentation and contours
- `examples/tiny-transformer`: original causal byte transformer, data generator, training/checkpoint recovery, CPU/GPU inference and mask tests
- `examples/embeddings`: lexical retrieval baseline, neural adaptation, saved index and search
- `examples/llm`: small-model full fine-tuning, LoRA, QLoRA, continued pretraining, structured-output scoring and CPU/GPU generation
- `examples/decision_pointer`: dynamic candidate scoring from a small pretrained Qwen backbone, calibration and evaluation
- `examples/asr`: current small-model speech recognition, audio/transcript validation, WER/CER, training and CPU/GPU transcription
- `examples/diffusion`: image adaptation and tiny waveform diffusion
- `examples/architecture_lab`: original CPU-only routing and memory arithmetic for the concluding architecture studies
- `examples/shared`: memory arithmetic and read-only environment inspection
- `templates`: a prediction contract, experiment plan, data card and model card to copy for your own work

## Keep environments separate

There is deliberately no global install-everything command. Read each project's requirements and the corresponding book chapter. Install only official packages and model assets from the verified links. Choose an official PyTorch wheel compatible with your operating system, GPU and driver. Do not merge unrelated version pins into one environment.

Exact neural-package versions in these projects are inspected reference targets. They were not all installed together during preparation. Run the local smoke tests, resolve any platform-specific incompatibility deliberately, and save the actual resolved environment after it passes.

## Honest verification

The dependency-free classifier, CPU tabular models, lexical retrieval, data generators, numeric diagnostics, parsing tests, and syntax checks were executed as documented. Neural training and inference paths were source-reviewed and syntax-checked but were not executed with PyTorch or a GPU in the authoring environment. A script that parses is not a tested GPU training recipe. Complete the local forward/backward/update, save/reload, recovery where implemented, maximum-shape, and CPU/GPU inference checks before starting a long run.

Per-project verification files and the book's verification appendix identify what was actually checked. Educational synthetic scores describe only the supplied fixtures. No consumer GPU speed, memory peak, or model-quality result is implied by an unexecuted recipe.

## Artifacts and safety

Use a new output directory for a new experiment. Keep original raw data separate from processed data. Do not train on material you lack rights or appropriate consent to use. Do not put credentials in code, configs, model cards, or logs. Review external reporting and upload defaults before running downloaded scripts.

Load only trusted serialized checkpoints. Keep action execution separate from model proposals. Validate schemas, permissions and state in deterministic code. These teaching projects do not authorize a model to take consequential actions.

No pretrained model weights, third-party repository source trees, or external training datasets are bundled. The small generated fixtures and original teaching implementations are supplied for the projects. Referenced libraries, repositories, models, datasets, and services retain their own licenses and access conditions.
