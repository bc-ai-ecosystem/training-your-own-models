# Dataset card

## Purpose and scope
Task, intended users, deployment population, and unsupported uses.

## Provenance and permissions
Sources, collection dates, ownership or license, consent when required, redistribution rules, and retention/deletion needs. Do not include credentials.

## Representation and labels
Schema, units, encoding, label policy, annotator instructions, uncertainty policy, transformations and augmentation assumptions.

## Splits and leakage controls
Independent grouping unit, train/validation/calibration/test roles, chronological or source boundaries, exact and near-duplicate checks, learned preprocessing fitted only on training data.

## Coverage
Counts of independent units and examples, target distribution, input-length or duration distribution, important slices, missing regimes and known biases.

## Quality checks
Schema validation, manual sample review, label agreement, corruption checks, privacy minimization, and processed-data inspection.

## Version
Dataset version, transformation code revision, hashes of every split, and changes from the previous version.
