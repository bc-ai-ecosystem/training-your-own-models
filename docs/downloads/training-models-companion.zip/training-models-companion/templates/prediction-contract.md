# Prediction contract

## Job
What useful decision, estimate, ranking, mask, text, image, or audio output should the system produce?

## Inputs
List exact fields, units, file formats, sample rates or tokenization assumptions. State when each input becomes available. Identify missing values and unsupported inputs.

## Outputs
Define types, allowed values, schema, coordinate system, or generated-output constraints. Separate a model score from an application action.

## Targets
Define correctness and ambiguous cases. Provide a positive example, easy negative, hard negative, and abstention case.

## Architecture and data relationship
Explain how the model representation and objective can learn the desired mapping from the available labels. State what information is absent or what dependencies exceed its context.

## Evaluation
Name the baseline, primary metric, guardrails, slices, split unit, and final held-out test. Define acceptable error consequences and an abstention policy.

## Deployment
Name the CPU/GPU runtime, input-size limits, preprocessing, output validation, permissions, monitoring, and rollback path.
