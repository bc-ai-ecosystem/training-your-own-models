# Model card

## Purpose
Intended task, application boundary, supported input/output contract, and unsupported uses.

## Architecture and starting point
Model class, total and trainable parameter counts, base repository and immutable revision, tokenizer/processor, output head, context/resolution/duration limits.

## Training
From-scratch, full fine-tuning, head-only, adapter or other method; data-card link; optimizer, numeric policy, batch/accumulation, learning-rate schedule, steps and token/sample budget.

## Evaluation
Baseline, held-out split method, primary metric, guardrails, counts, slice results, calibration/abstention policy, and representative failures.

## Measured resources
Hardware, actual environment, peak memory, throughput, total time and storage. Distinguish measured values from estimates or untested expectations.

## Inference and export
Required files, CPU and GPU commands, preprocessing, dtype/runtime support, decoding, export equivalence tests, quantization changes and known limitations.

## Rights and security
Model/code/data licenses, access restrictions, consent needs, trusted-loading requirements, external reporting behavior and action-permission boundary.

## Maintenance
Version, owner/contact if desired, monitoring, update criteria, rollback artifact and retirement plan.
